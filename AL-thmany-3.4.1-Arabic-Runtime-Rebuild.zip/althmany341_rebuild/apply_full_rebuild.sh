#!/usr/bin/env bash
set -uo pipefail

REPO="${1:-/workspaces/Bb}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BRANCH="feat/full-features-3.4.1"

say() { printf '\n===== %s =====\n' "$1"; }
fail() { echo "ERROR: $*"; echo "الطرفية ستبقى مفتوحة لأن هذا السكربت يعمل داخل bash فرعي."; exit 1; }

cd "$REPO" || fail "لم أجد المستودع: $REPO"

say "1/8 — فتح الفرع الصحيح"
git checkout "$BRANCH" || fail "تعذر فتح $BRANCH"
git pull --ff-only origin "$BRANCH" || fail "تعذر تحديث الفرع"
echo "Branch: $(git branch --show-current)"
echo "Head before: $(git rev-parse --short HEAD)"

say "2/8 — TDD RED: إثبات أن المتطلبات الجديدة غير مكتملة قبل التعديل"
if python3 "$PKG_DIR/patch/validate_341_runtime_rebuild.py" "$REPO"; then
  echo "ملاحظة: العقد الجديد موجود بالفعل؛ سيتم تطبيق التحديث بصورة idempotent ثم إعادة التحقق."
else
  echo "RED CONFIRMED: الاختبار كشف المتطلبات المفقودة كما هو متوقع."
fi

say "3/8 — تطبيق إعادة البناء"
python3 "$PKG_DIR/apply_patch.py" "$REPO" || fail "فشل تطبيق التعديلات"

say "4/8 — TDD GREEN: فحص عقد 3.4.1 الجديد"
python3 scripts/validate_341_runtime_rebuild.py "$REPO" || fail "فشل عقد إعادة البناء"

say "5/8 — فحوصات المشروع الحالية"
python3 scripts/validate_source.py || fail "validate_source.py فشل"
python3 scripts/validate_integrated_extractor.py || fail "validate_integrated_extractor.py فشل"
if [ -x scripts/run_stability_4_0_checks.sh ]; then
  bash scripts/run_stability_4_0_checks.sh || fail "فحص الاستقرار فشل"
fi

git diff --check || fail "git diff --check وجد مشكلة تنسيق"

echo "SOURCE CONTRACTS: PASS"

say "6/8 — البناء الحقيقي: Unit Tests + Lint + APK"
chmod +x ./gradlew 2>/dev/null || true
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug || fail "Gradle build failed — لم يتم عمل commit أو push"

APK="app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || fail "Gradle انتهى ولكن app-debug.apk غير موجود"
echo "BUILD PASS"
echo "APK: $APK"
ls -lh "$APK"
sha256sum "$APK" | tee /tmp/althmany-341-apk.sha256

say "7/8 — Commit"
git add \
  app/src/main/java/com/althmany/extractor/ExtractorApp.kt \
  app/src/main/java/com/althmany/extractor/MainActivity.kt \
  app/src/main/java/com/althmany/extractor/engine/OriginalJoinController.kt \
  app/src/main/java/com/althmany/extractor/engine/RuntimeDiagnosticsController.kt \
  app/src/main/java/com/althmany/extractor/engine/ScanController.kt \
  app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt \
  app/src/main/java/com/althmany/extractor/ui/Screens.kt \
  app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt \
  scripts/validate_341_runtime_rebuild.py \
  docs/superpowers/specs/2026-09-16-al-thmany-3.4.1-arabic-runtime-rebuild-design.md \
  docs/superpowers/plans/2026-09-16-al-thmany-3.4.1-arabic-runtime-rebuild.md

if git diff --cached --quiet; then
  echo "لا توجد تغييرات جديدة للـcommit."
else
  git commit -m "feat: rebuild Arabic join scan diagnostics workspace" || fail "commit failed"
fi

echo "Commit: $(git rev-parse --short HEAD)"

say "8/8 — Push وتشغيل GitHub Actions"
git push origin "$BRANCH" || fail "push failed"

echo
printf '%s\n' "=============================================================="
printf '%s\n' "LOCAL VERIFICATION: PASS"
printf '%s\n' "Branch: $(git branch --show-current)"
printf '%s\n' "Commit: $(git rev-parse --short HEAD)"
printf '%s\n' "APK: $APK"
printf '%s\n' "SHA256: $(cut -d' ' -f1 /tmp/althmany-341-apk.sha256)"
printf '%s\n' "تم رفع التعديل؛ GitHub Actions سيعمل كفحص مستقل ثانٍ."
printf '%s\n' "=============================================================="
