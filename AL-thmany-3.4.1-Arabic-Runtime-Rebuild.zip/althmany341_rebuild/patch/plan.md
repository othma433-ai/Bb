# AL-thmany Sender 3.4.1 Arabic Runtime Rebuild — Implementation Plan

1. Add a failing source-contract validator for original Join, scan-only safety, RTL, expandable inputs, member count, diagnostics and launcher.
2. Add `OriginalJoinController` and initialize it from `ExtractorFeatureRuntime`.
3. Add `RuntimeDiagnosticsController` and diagnostics screen.
4. Rewire `AppViewModel` global controls and Join start to the original Sender runtime.
5. Force `ScanController` into classifier-only mode and guard both Accessibility and Shizuku action paths.
6. Replace Join/Scan Compose screens with RTL Arabic responsive versions and four-line expandable inputs.
7. Route Diagnostics from Home; export/copy the real report.
8. Run rebuild validator, existing validators, unit tests, lint and debug APK assembly.
9. Commit/push only after local verification succeeds; GitHub Actions becomes the independent second build gate.
