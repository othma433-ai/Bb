# AL-thmany Sender 3.4.1 Arabic Runtime Rebuild — Design

## Goal
A real Arabic RTL workspace with responsive sizing, original Sender Join runtime, read-only classification Scan, four-line expandable link inputs, real WhatsApp target binding, and live diagnostics.

## Architecture
- `com.althmany.extractor.MainActivity` remains launcher.
- RTL is provided above the entire workspace scaffold so the bottom bar and content share Arabic direction.
- `OriginalJoinController` is a bridge to the original disk-backed Sender runtime; it does not duplicate join logic.
- Join executes through `QuickJoinAccessibilityService` or `ShizukuAutomationService`, selected by `NativeProfileEngineRouter`.
- Scan is classifier-only. Its controller is forced to `SCAN_ONLY`; membership click functions have a runtime guard.
- Existing `RuntimeOperationCoordinator` remains the only UI ownership authority: SENDER / EXTRACTION / SCAN / PUBLISH.
- Scan persists group name, member-count text, invite kind, confidence and signal code when WhatsApp exposes them; no number is invented.
- `RuntimeDiagnosticsController` aggregates actual Accessibility/Shizuku/network/profile/owner/health/journal evidence.

## UI contract
- Arabic RTL everywhere.
- Link editors show four lines collapsed, `عرض المزيد (N)`, then `عرض أقل`.
- Join screen exposes original-engine state and pause/resume/final stop.
- Scan screen shows direct/no-approval, moderator approval, invalid, already-member, pending, full, removed/error/unknown plus group/member metadata.
- Home links to diagnostics; advanced settings remain available.

## Verification
A rebuild contract validator runs RED before installation and GREEN after it. Existing source/integration validators run next, followed by `testDebugUnitTest`, `lintDebug`, and `assembleDebug`. No completion claim is valid until these pass.
