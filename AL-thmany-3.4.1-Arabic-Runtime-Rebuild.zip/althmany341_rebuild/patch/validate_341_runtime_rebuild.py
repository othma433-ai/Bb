#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
errors = []

def read(rel):
    p = ROOT / rel
    if not p.exists():
        errors.append(f"missing: {rel}")
        return ""
    return p.read_text(encoding="utf-8", errors="ignore")

manifest = read("app/src/main/AndroidManifest.xml")
main = read("app/src/main/java/com/althmany/extractor/MainActivity.kt")
vm = read("app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt")
screens = read("app/src/main/java/com/althmany/extractor/ui/Screens.kt")
v341 = read("app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt")
scan = read("app/src/main/java/com/althmany/extractor/engine/ScanController.kt")
feature = read("app/src/main/java/com/althmany/extractor/ExtractorApp.kt")
join = read("app/src/main/java/com/althmany/extractor/engine/OriginalJoinController.kt")
diag = read("app/src/main/java/com/althmany/extractor/engine/RuntimeDiagnosticsController.kt")
build = read("app/build.gradle.kts")

checks = {
    "3.4.1 version": 'versionName = "3.4.1"' in build,
    "new workspace launcher": 'android:name="com.althmany.extractor.MainActivity"' in manifest and re.search(r'com\.althmany\.extractor\.MainActivity[\s\S]{0,400}android\.intent\.action\.MAIN', manifest) is not None,
    "global Arabic RTL": 'CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl)' in main and 'AlThmanyTheme' in main,
    "original join controller": all(t in join for t in ["QuickJoinAccessibilityService", "ShizukuAutomationService", "startAccessibilityBatch", "WhatsAppLinkParser.extract", "RuntimeOperation.SENDER"]),
    "join runtime initialized": "OriginalJoinController.initialize" in feature and "RuntimeDiagnosticsController.initialize" in feature,
    "viewmodel uses original join": "val joinState" in vm and "startJoinWithInput" in vm and "OriginalJoinController.start" in vm,
    "scan is forced read-only": "SCAN_ONLY" in scan and "SCAN_READ_ONLY_GUARD" in scan,
    "scan screen has no membership mode": '"تصنيف فقط — بدون انضمام"' in v341 and "onAction: (ScanActionMode)" not in re.search(r'fun V341ScanScreen[\s\S]*?(?=@Composable\nfun V341PublishScreen)', v341).group(0) if re.search(r'fun V341ScanScreen[\s\S]*?(?=@Composable\nfun V341PublishScreen)', v341) else False,
    "four-line expandable input": all(t in v341 for t in ["VExpandableLinkInput", "maxLines = if (expanded) 16 else 4", "عرض المزيد", "عرض أقل"]),
    "scan shows member count": "عدد الأعضاء غير متاح" in v341 and "memberCountText" in v341,
    "diagnostics controller": all(t in diag for t in ["RuntimeDiagnosticStore", "RuntimeHealthMonitor", "AccessibilityStatus", "ShizukuBridge", "RuntimeOperationCoordinator"]),
    "diagnostics screen": "V341DiagnosticsScreen" in v341 and "AppScreen.DIAGNOSTICS" in main and "DIAGNOSTICS" in screens,
    "single owner still present": "RuntimeOperationCoordinator" in join and "RuntimeOperation.SENDER" in join,
}
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
    if not ok: errors.append(name)

if errors:
    print(f"\nAL-thmany 3.4.1 rebuild contract: FAIL ({len(errors)})")
    sys.exit(1)
print("\nAL-thmany 3.4.1 rebuild contract: PASS")
