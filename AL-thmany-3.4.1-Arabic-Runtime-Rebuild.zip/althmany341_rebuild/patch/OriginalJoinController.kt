package com.althmany.extractor.engine

import android.content.Context
import android.os.Process
import com.althmany.extractor.profile.WhatsAppInstanceRegistry
import com.althmany.groupmanager.GroupManagerApp
import com.althmany.groupmanager.accessibility.AccessibilityStatus
import com.althmany.groupmanager.accessibility.QuickJoinAccessibilityService
import com.althmany.groupmanager.domain.AutomationPolicy
import com.althmany.groupmanager.domain.AutomationStopReason
import com.althmany.groupmanager.domain.NativeEngineSetupAction
import com.althmany.groupmanager.domain.RestrictionHandlingMode
import com.althmany.groupmanager.domain.RuntimeSpeedProfilePolicy
import com.althmany.groupmanager.domain.WhatsAppLinkParser
import com.althmany.groupmanager.model.AutomationBackend
import com.althmany.groupmanager.model.LinkResultCode
import com.althmany.groupmanager.model.LinkSource
import com.althmany.groupmanager.model.LinkStatus
import com.althmany.groupmanager.model.PreferredTarget
import com.althmany.groupmanager.shizuku.ShizukuAutomationService
import com.althmany.groupmanager.util.AutomationScreenAwakeGuard
import com.althmany.groupmanager.util.LaunchDestination
import com.althmany.groupmanager.util.NativeProfileEngineRouter
import com.althmany.groupmanager.util.RuntimeDiagnosticStore
import com.althmany.groupmanager.util.WhatsAppLauncher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Presentation bridge for the proven original Sender runtime.
 *
 * IMPORTANT: this is not a second join engine. It prepares the original disk-backed Sender
 * session and then delegates execution to QuickJoinAccessibilityService / ShizukuAutomationService.
 */
data class OriginalJoinUiState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val total: Int = 0,
    val joined: Int = 0,
    val requested: Int = 0,
    val skipped: Int = 0,
    val failed: Int = 0,
    val remaining: Int = 0,
    val progressPercent: Int = 0,
    val currentPosition: Int = 0,
    val currentUrl: String? = null,
    val targetPackage: String? = null,
    val backend: String = "—",
    val stage: String = "IDLE",
    val message: String = "جاهز",
    val lastAction: String? = null,
    val error: String? = null
)

object OriginalJoinController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(OriginalJoinUiState())
    val state: StateFlow<OriginalJoinUiState> = _state.asStateFlow()

    private lateinit var appContext: Context
    private lateinit var app: GroupManagerApp
    @Volatile private var initialized = false
    private var pollJob: Job? = null
    private var startJob: Job? = null

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        appContext = context.applicationContext
        app = appContext as GroupManagerApp
        initialized = true
        pollJob = scope.launch {
            while (isActive) {
                refreshNow()
                delay(500L)
            }
        }
    }

    fun isRunning(): Boolean = initialized && app.preferences.accessibilityBatchRunning

    fun start(rawText: String, selectedPackage: String?) {
        check(initialized) { "OriginalJoinController not initialized" }
        if (startJob?.isActive == true) return
        startJob = scope.launch { startInternal(rawText, selectedPackage) }
    }

    private suspend fun startInternal(rawText: String, selectedPackage: String?) {
        if (app.preferences.accessibilityBatchRunning) {
            _state.value = _state.value.copy(message = "جلسة الانضمام الأصلية تعمل بالفعل")
            return
        }
        val owner = RuntimeOperationCoordinator.current()
        if (owner != null && owner != RuntimeOperation.SENDER) {
            setError("لا يمكن بدء الانضمام أثناء تشغيل ${owner.labelAr}")
            return
        }
        val cleanPackage = selectedPackage?.trim().orEmpty()
        if (cleanPackage.isBlank()) {
            setError("اختر نسخة واتساب المستهدفة أولاً")
            return
        }
        if (rawText.isBlank()) {
            setError("أدخل روابط الدعوة أو استوردها أولاً")
            return
        }

        _state.value = _state.value.copy(error = null, message = "تحليل الروابط وتجهيز محرك الانضمام الأصلي…")
        val report = withContext(Dispatchers.Default) { WhatsAppLinkParser.extract(rawText) }
        if (report.accepted.isEmpty()) {
            setError("لم يتم العثور على روابط دعوة واتساب صالحة")
            return
        }

        // The new workspace selection is explicit. It deliberately overrides a stale remote target;
        // remote Work/Secure targets are selected again from the original advanced settings.
        if (app.preferences.hasValidRemoteSecureTarget()) app.preferences.clearRemoteSecureTarget()
        val validation = WhatsAppLauncher.validateTarget(
            appContext,
            PreferredTarget.AUTO,
            cleanPackage
        )
        if (!validation.valid || validation.packageName.isNullOrBlank()) {
            setError("تعذر ربط نسخة واتساب: ${validation.diagnostic}")
            return
        }

        val engineDecision = NativeProfileEngineRouter
            .inspect(appContext, app.preferences.automationBackend)
            .decision
        if (!engineDecision.runnable || engineDecision.backend == null) {
            val setup = when (engineDecision.setupAction) {
                NativeEngineSetupAction.ENABLE_LOCAL_ACCESSIBILITY -> "فعّل Accessibility الخاصة بالتطبيق"
                NativeEngineSetupAction.START_OR_AUTHORIZE_SHIZUKU -> "شغّل Shizuku وامنح التطبيق الإذن"
                NativeEngineSetupAction.APPLY_WORK_ACCESSIBILITY_POLICY -> "فعّل سياسة Accessibility داخل Work Profile"
                NativeEngineSetupAction.BLOCKED_BY_PROFILE_POLICY -> "ملف Android الحالي يمنع محرك التحكم"
                NativeEngineSetupAction.NONE -> engineDecision.reasonCode
            }
            setError("بيئة التشغيل غير جاهزة: $setup")
            return
        }
        val backend = engineDecision.backend

        val snapshot = withContext(Dispatchers.IO) {
            app.repository.createSession(report, LinkSource.PASTE, "واجهة الانضمام 3.4.1")
        }
        val packageName = validation.packageName
        app.preferences.selectedWhatsAppPackage = packageName
        app.preferences.selectedWhatsAppLabel = WhatsAppInstanceRegistry.labelFor(packageName)
        app.preferences.preferredTarget = PreferredTarget.AUTO
        app.preferences.runtimeShadowMode = false
        app.preferences.fastHandsFreeMode = RuntimeSpeedProfilePolicy.isFast(app.preferences.runtimeSpeedMode)
        app.preferences.restrictionHandlingMode = RestrictionHandlingMode.SKIP_AND_CONTINUE
        app.preferences.autoPauseOutsideWhatsApp = true
        app.preferences.autoResumeCurrentRun = false
        app.preferences.keepScreenAwake = true
        app.preferences.interLinkDelayMs = app.preferences.runtimeSpeedProfile().interLinkDelayMs.toInt()
        app.preferences.accessibilityActionTimeoutSeconds = AutomationPolicy.FAST_ACTION_TIMEOUT_SECONDS
        app.preferences.runtimeAutomationBackend = backend
        app.preferences.accessibilityQuickJoin = backend == AutomationBackend.ACCESSIBILITY
        app.preferences.autoAdvance = true
        app.preferences.lockRuntimeTarget(packageName, validation.profileKey)
        if (!app.preferences.lockRuntimeAndroidUserId(Process.myUid() / 100_000)) {
            setError("تعذر تثبيت Android User للجلسة الحالية")
            return
        }

        if (!app.preferences.startAccessibilityBatch(snapshot.sessionId)) {
            setError("واجهة واتساب مستخدمة الآن بواسطة عملية أخرى")
            return
        }
        RuntimeDiagnosticStore.append(
            appContext,
            "JOIN_BRIDGE_START",
            "backend=${backend.name}; package=$packageName; profile=${validation.profileKey}; links=${snapshot.stats.total}"
        )
        AutomationScreenAwakeGuard.sync(appContext, true)

        if (backend == AutomationBackend.SHIZUKU) {
            ShizukuAutomationService.start(appContext)
            _state.value = _state.value.copy(message = "بدأ محرك الانضمام الأصلي عبر Shizuku")
        } else {
            if (!AccessibilityStatus.isQuickJoinServiceConnectedLocally(appContext)) {
                app.preferences.stopAccessibilityBatch(
                    AutomationStopReason.SERVICE_DISABLED,
                    "Original Join bridge requires the profile-local Accessibility service"
                )
                setError("Accessibility مفعّلة لكن الخدمة غير متصلة بهذا الملف")
                return
            }
            openFirstAccessibilityLink(snapshot.sessionId)
        }
        refreshNow()
    }

    private suspend fun openFirstAccessibilityLink(sessionId: String) {
        val next = withContext(Dispatchers.IO) { app.repository.loadAutomationNext(sessionId) }
        if (next == null) {
            app.preferences.completeAccessibilityBatch(
                AutomationStopReason.SESSION_COMPLETE,
                "No actionable invitation links"
            )
            return
        }
        val opened = withContext(Dispatchers.IO) { app.repository.markOpened(next.id) } ?: run {
            app.preferences.stopAccessibilityBatch(
                AutomationStopReason.OPEN_FAILED,
                "Could not mark first invitation as opened"
            )
            setError("تعذر تجهيز أول رابط")
            return
        }
        val destination = withContext(Dispatchers.Main.immediate) {
            WhatsAppLauncher.launch(
                appContext,
                opened.url,
                app.preferences.preferredTarget,
                app.preferences.runtimeLockedWhatsAppPackage ?: app.preferences.selectedWhatsAppPackage,
                strictProfileTarget = app.preferences.strictProfileTargeting,
                expectedProfileKey = app.preferences.runtimeLockedProfileKey
            )
        }
        val supported = destination in setOf(
            LaunchDestination.PERSONAL,
            LaunchDestination.BUSINESS,
            LaunchDestination.CLONED,
            LaunchDestination.SELECTED,
            LaunchDestination.DUAL_CHOOSER
        )
        if (!supported) {
            withContext(Dispatchers.IO) {
                app.repository.markStatus(
                    opened.id,
                    LinkStatus.FAILED,
                    if (destination == LaunchDestination.BROWSER) LinkResultCode.BROWSER_FALLBACK else LinkResultCode.OPEN_FAILED,
                    "Original Join bridge could not open the selected WhatsApp target"
                )
            }
            app.preferences.stopAccessibilityBatch(
                if (destination == LaunchDestination.BROWSER) AutomationStopReason.BROWSER_FALLBACK else AutomationStopReason.OPEN_FAILED,
                "Selected WhatsApp could not open the invitation"
            )
            setError("تعذر فتح الرابط داخل نسخة واتساب المحددة")
            return
        }
        app.preferences.markAutomationLaunched()
        QuickJoinAccessibilityService.requestImmediateScan()
        _state.value = _state.value.copy(message = "تم فتح أول رابط — المحرك الأصلي يتحقق وينتقل تلقائيًا")
    }

    fun pause() {
        if (!initialized || !app.preferences.accessibilityBatchRunning || app.preferences.accessibilityPaused) return
        app.preferences.pauseAccessibilityBatch("Paused from Arabic 3.4.1 Join screen")
        AutomationScreenAwakeGuard.release()
        scope.launch { refreshNow() }
    }

    fun resume() {
        if (!initialized || !app.preferences.accessibilityBatchRunning || !app.preferences.accessibilityPaused) return
        app.preferences.resumeAccessibilityBatch("Resumed from Arabic 3.4.1 Join screen")
        AutomationScreenAwakeGuard.sync(appContext, app.preferences.keepScreenAwake)
        if (app.preferences.runtimeAutomationBackend == AutomationBackend.SHIZUKU) {
            ShizukuAutomationService.start(appContext)
        } else {
            QuickJoinAccessibilityService.requestImmediateScan()
        }
        scope.launch { refreshNow() }
    }

    fun stop() {
        if (!initialized) return
        startJob?.cancel()
        startJob = null
        ShizukuAutomationService.stop(appContext)
        app.preferences.stopAccessibilityBatch(
            AutomationStopReason.USER_STOPPED,
            "Stopped from Arabic 3.4.1 Join screen"
        )
        AutomationScreenAwakeGuard.release()
        scope.launch { refreshNow() }
    }

    fun clearSession() {
        if (!initialized) return
        stop()
        scope.launch(Dispatchers.IO) {
            app.repository.clearCurrentSession()
            withContext(Dispatchers.Main.immediate) {
                _state.value = OriginalJoinUiState(message = "تم مسح جلسة الانضمام")
            }
        }
    }

    fun refresh() {
        if (!initialized) return
        scope.launch { refreshNow() }
    }

    private suspend fun refreshNow() {
        if (!initialized) return
        val prefs = app.preferences
        val snapshot = withContext(Dispatchers.IO) { app.repository.loadActiveDashboardSnapshot(48) }
        val stats = snapshot?.stats
        val current = snapshot?.links?.firstOrNull { it.status == LinkStatus.OPENED }
            ?: snapshot?.links?.firstOrNull { it.status == LinkStatus.PENDING }
        val running = prefs.accessibilityBatchRunning
        val paused = prefs.accessibilityPaused
        val stopReason = prefs.automationStopReason
        val derivedError = if (!running && stopReason !in setOf(
                AutomationStopReason.NONE,
                AutomationStopReason.USER_STOPPED,
                AutomationStopReason.SESSION_COMPLETE
            )
        ) prefs.automationDiagnostic.ifBlank { stopReason.name } else null
        val message = when {
            paused -> "الانضمام متوقف مؤقتًا — يمكنك الاستكمال من نفس الرابط"
            running -> prefs.automationDiagnostic.ifBlank { "محرك الانضمام الأصلي يعمل" }
            stopReason == AutomationStopReason.SESSION_COMPLETE -> "اكتملت جلسة الانضمام"
            derivedError != null -> derivedError
            snapshot != null && (stats?.remaining ?: 0) > 0 -> "جلسة محفوظة — جاهزة للاستكمال أو البدء من جديد"
            else -> _state.value.message.ifBlank { "جاهز" }
        }
        _state.value = OriginalJoinUiState(
            running = running,
            paused = paused,
            total = stats?.total ?: 0,
            joined = stats?.joined ?: 0,
            requested = stats?.requested ?: 0,
            skipped = stats?.skipped ?: 0,
            failed = stats?.failed ?: 0,
            remaining = stats?.remaining ?: 0,
            progressPercent = stats?.progressPercent ?: 0,
            currentPosition = current?.position?.plus(1) ?: 0,
            currentUrl = current?.url ?: prefs.runtimeCurrentLinkUrl,
            targetPackage = prefs.runtimeLockedWhatsAppPackage ?: prefs.selectedWhatsAppPackage,
            backend = prefs.runtimeAutomationBackend.name,
            stage = prefs.automationStage.name,
            message = message,
            lastAction = prefs.runtimeActionExecuted,
            error = derivedError ?: _state.value.error?.takeIf { !running }
        )
    }

    private fun setError(message: String) {
        RuntimeDiagnosticStore.append(appContext, "JOIN_BRIDGE_ERROR", message)
        _state.value = _state.value.copy(running = false, paused = false, message = message, error = message)
    }
}
