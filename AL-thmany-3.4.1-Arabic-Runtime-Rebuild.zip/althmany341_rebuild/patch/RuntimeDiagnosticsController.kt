package com.althmany.extractor.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.althmany.groupmanager.GroupManagerApp
import com.althmany.groupmanager.accessibility.AccessibilityStatus
import com.althmany.groupmanager.shizuku.ShizukuBridge
import com.althmany.groupmanager.util.ProfileEnvironment
import com.althmany.groupmanager.util.RuntimeDiagnosticStore
import com.althmany.groupmanager.util.RuntimeHealthMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Real runtime diagnostics assembled only from live/persisted engine evidence. */
data class RuntimeDiagnosticsSnapshot(
    val capturedAt: Long = 0L,
    val networkValidated: Boolean = false,
    val senderAccessibilityEnabled: Boolean = false,
    val senderAccessibilityConnected: Boolean = false,
    val extractorAccessibilityConnected: Boolean = false,
    val shizukuBinderAlive: Boolean = false,
    val shizukuPermissionGranted: Boolean = false,
    val shizukuReady: Boolean = false,
    val profileKey: String = "—",
    val profileKind: String = "—",
    val operation: String = "لا توجد عملية",
    val targetPackage: String = "—",
    val backend: String = "—",
    val currentLink: String = "—",
    val stage: String = "—",
    val lastAction: String = "—",
    val diagnostic: String = "—",
    val healthDirective: String = "—",
    val healthAction: String = "—",
    val healthConfidence: String = "—",
    val watchdog: String = "—",
    val journal: String = ""
) {
    fun asText(): String = buildString {
        appendLine("AL-thmany 3.4.1 Runtime Diagnostics")
        appendLine("capturedAt=$capturedAt")
        appendLine("networkValidated=$networkValidated")
        appendLine("operation=$operation")
        appendLine("profile=$profileKey ($profileKind)")
        appendLine("targetPackage=$targetPackage")
        appendLine("backend=$backend")
        appendLine("senderAccessibilityEnabled=$senderAccessibilityEnabled")
        appendLine("senderAccessibilityConnected=$senderAccessibilityConnected")
        appendLine("extractorAccessibilityConnected=$extractorAccessibilityConnected")
        appendLine("shizukuBinderAlive=$shizukuBinderAlive")
        appendLine("shizukuPermissionGranted=$shizukuPermissionGranted")
        appendLine("shizukuReady=$shizukuReady")
        appendLine("currentLink=$currentLink")
        appendLine("stage=$stage")
        appendLine("lastAction=$lastAction")
        appendLine("diagnostic=$diagnostic")
        appendLine("healthDirective=$healthDirective")
        appendLine("healthAction=$healthAction")
        appendLine("healthConfidence=$healthConfidence")
        appendLine("watchdog=$watchdog")
        appendLine()
        appendLine("--- recent runtime journal ---")
        append(journal.ifBlank { "لا توجد سجلات بعد" })
    }
}

object RuntimeDiagnosticsController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(RuntimeDiagnosticsSnapshot())
    val state: StateFlow<RuntimeDiagnosticsSnapshot> = _state.asStateFlow()

    private lateinit var appContext: Context
    private lateinit var app: GroupManagerApp
    @Volatile private var initialized = false
    private var pollJob: Job? = null

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        appContext = context.applicationContext
        app = appContext as GroupManagerApp
        initialized = true
        pollJob = scope.launch {
            while (isActive) {
                refreshNow()
                delay(750L)
            }
        }
    }

    fun refresh() {
        if (!initialized) return
        scope.launch { refreshNow() }
    }

    fun clearJournal() {
        if (!initialized) return
        RuntimeDiagnosticStore.clear(appContext)
        refresh()
    }

    private fun validatedNetwork(): Boolean {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun refreshNow() {
        if (!initialized) return
        val prefs = app.preferences
        val accessibility = AccessibilityStatus.readiness(appContext)
        val shizuku = runCatching { ShizukuBridge.status() }.getOrNull()
        val profile = ProfileEnvironment.current(appContext)
        val health = RuntimeHealthMonitor.snapshot()
        val operation = RuntimeOperationCoordinator.current()
        val extractor = ExtractionController.state.value
        val scan = ScanController.state.value
        val publish = PublishController.state.value
        val operationDiagnostic = when (operation) {
            RuntimeOperation.SENDER -> prefs.automationDiagnostic
            RuntimeOperation.EXTRACTION -> extractor.message
            RuntimeOperation.SCAN -> scan.message
            RuntimeOperation.PUBLISH -> publish.info
            null -> prefs.automationDiagnostic
        }.ifBlank { "—" }
        _state.value = RuntimeDiagnosticsSnapshot(
            capturedAt = System.currentTimeMillis(),
            networkValidated = validatedNetwork(),
            senderAccessibilityEnabled = accessibility.systemEnabled,
            senderAccessibilityConnected = accessibility.localServiceConnected,
            extractorAccessibilityConnected = extractor.serviceConnected,
            shizukuBinderAlive = shizuku?.binderAlive == true,
            shizukuPermissionGranted = shizuku?.permissionGranted == true,
            shizukuReady = shizuku?.ready == true,
            profileKey = profile.profileKey,
            profileKind = profile.kind.name,
            operation = operation?.let { "${it.labelAr} (${it.name})" } ?: "لا توجد عملية",
            targetPackage = prefs.runtimeLockedWhatsAppPackage
                ?: extractor.selectedWhatsAppPackage
                ?: prefs.selectedWhatsAppPackage
                ?: "—",
            backend = if (operation == RuntimeOperation.SENDER) prefs.runtimeAutomationBackend.name else operation?.name ?: "—",
            currentLink = prefs.runtimeCurrentLinkUrl ?: scan.currentUrl ?: "—",
            stage = if (operation == RuntimeOperation.SENDER) prefs.automationStage.name else when (operation) {
                RuntimeOperation.EXTRACTION -> extractor.status.name
                RuntimeOperation.SCAN -> scan.status.name
                RuntimeOperation.PUBLISH -> publish.status.name
                else -> prefs.automationStage.name
            },
            lastAction = prefs.runtimeActionExecuted ?: "—",
            diagnostic = operationDiagnostic,
            healthDirective = health?.directive ?: "—",
            healthAction = health?.action ?: "—",
            healthConfidence = health?.confidence?.let { "$it% ${health.confidenceBand.orEmpty()}" } ?: "—",
            watchdog = health?.watchdog ?: "—",
            journal = RuntimeDiagnosticStore.readRecent(appContext, 14_000)
        )
    }
}
