# AL-thmany Sender 3.4.1 — Arabic Runtime Rebuild

هذه الحزمة تطبق إعادة بناء تنفيذية على الفرع `feat/full-features-3.4.1`.

تشمل:
- RTL عربي على كامل واجهة Compose بما فيها شريط التنقل.
- ربط شاشة الانضمام بمحرك Sender الأصلي (`QuickJoinAccessibilityService` / Shizuku).
- جعل الفحص تصنيفًا فقط بدون Join/Request/Confirm.
- مربعات الروابط 4 أسطر افتراضيًا مع عرض المزيد/عرض أقل.
- عرض اسم القروب وعدد الأعضاء عند توفرهما، وإظهار «غير متاح» بدون اختلاق بيانات.
- لوحة تشخيص حقيقية من Runtime/Accessibility/Shizuku/network/profile/journal.
- Runtime owner واحد فقط.
- TDD RED/GREEN ثم validators ثم Unit Tests + Lint + assembleDebug قبل commit/push.

## التشغيل
من داخل Codespaces وبعد وضع هذه الحزمة خارج مجلد المستودع أو فكها في `/tmp`:

```bash
bash /tmp/althmany341_rebuild/apply_full_rebuild.sh /workspaces/Bb
```

إذا كانت الحزمة مفكوكة داخل المستودع أيضًا يمكن تشغيل المسار المباشر لها. السكربت يعمل داخل Bash فرعي، لذلك `exit` داخله لا يغلق طرفية Codespaces.
