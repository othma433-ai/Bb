#!/usr/bin/env python3
from pathlib import Path
import re
import shutil
import sys

REPO = Path(sys.argv[1] if len(sys.argv) > 1 else "/workspaces/Bb").resolve()
PKG = Path(__file__).resolve().parent
PATCH = PKG / "patch"


def path(rel: str) -> Path:
    return REPO / rel


def read(rel: str) -> str:
    p = path(rel)
    if not p.exists():
        raise SystemExit(f"Missing required file: {rel}")
    return p.read_text(encoding="utf-8")


def write(rel: str, text: str) -> None:
    p = path(rel)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    print(f"UPDATED {rel}")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        print(f"SKIP already applied: {label}")
        return text
    if old not in text:
        raise SystemExit(f"Patch anchor not found: {label}")
    return text.replace(old, new, 1)


def replace_regex(text: str, pattern: str, repl: str, label: str, flags=re.S) -> str:
    if re.search(pattern, text, flags) is None:
        raise SystemExit(f"Regex patch anchor not found: {label}")
    out, n = re.subn(pattern, repl, text, count=1, flags=flags)
    if n != 1:
        raise SystemExit(f"Regex patch count {n} for {label}")
    return out


def copy_new(src_name: str, rel: str) -> None:
    dst = path(rel)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(PATCH / src_name, dst)
    print(f"CREATED {rel}")


# New production controllers + validator/docs.
copy_new("OriginalJoinController.kt", "app/src/main/java/com/althmany/extractor/engine/OriginalJoinController.kt")
copy_new("RuntimeDiagnosticsController.kt", "app/src/main/java/com/althmany/extractor/engine/RuntimeDiagnosticsController.kt")
copy_new("validate_341_runtime_rebuild.py", "scripts/validate_341_runtime_rebuild.py")
copy_new("design.md", "docs/superpowers/specs/2026-09-16-al-thmany-3.4.1-arabic-runtime-rebuild-design.md")
copy_new("plan.md", "docs/superpowers/plans/2026-09-16-al-thmany-3.4.1-arabic-runtime-rebuild.md")

# Initialize controllers with the embedded Extractor runtime.
rel = "app/src/main/java/com/althmany/extractor/ExtractorApp.kt"
s = read(rel)
s = replace_once(
    s,
    "import com.althmany.extractor.engine.PublishController\nimport com.althmany.extractor.engine.ScanController",
    "import com.althmany.extractor.engine.PublishController\nimport com.althmany.extractor.engine.ScanController\nimport com.althmany.extractor.engine.OriginalJoinController\nimport com.althmany.extractor.engine.RuntimeDiagnosticsController",
    "ExtractorApp imports"
)
s = replace_once(
    s,
    "        ScanController.initialize(appContext, repository)\n        PublishController.initialize(appContext, repository)\n        initialized = true",
    "        ScanController.initialize(appContext, repository)\n        PublishController.initialize(appContext, repository)\n        OriginalJoinController.initialize(appContext)\n        RuntimeDiagnosticsController.initialize(appContext)\n        initialized = true",
    "ExtractorApp initialization"
)
write(rel, s)

# Add DIAGNOSTICS route.
rel = "app/src/main/java/com/althmany/extractor/ui/Screens.kt"
s = read(rel)
s = replace_once(
    s,
    "enum class AppScreen { HOME, JOIN, EXTRACT, SCAN, PUBLISH, GROUPS, RESULTS, LOGS, SETTINGS }",
    "enum class AppScreen { HOME, JOIN, EXTRACT, SCAN, PUBLISH, GROUPS, RESULTS, LOGS, DIAGNOSTICS, SETTINGS }",
    "AppScreen diagnostics"
)
write(rel, s)

# Rewire the ViewModel to original Join and diagnostics; force Scan read-only.
rel = "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt"
s = read(rel)
s = replace_once(
    s,
    "import com.althmany.extractor.engine.ScanController\nimport com.althmany.extractor.engine.PublishController",
    "import com.althmany.extractor.engine.ScanController\nimport com.althmany.extractor.engine.PublishController\nimport com.althmany.extractor.engine.OriginalJoinController\nimport com.althmany.extractor.engine.RuntimeDiagnosticsController",
    "AppViewModel controller imports"
)
s = replace_once(
    s,
    "    val scanState: StateFlow<ScanUiState> = ScanController.state\n    val publishState: StateFlow<PublishUiState> = PublishController.state",
    "    val scanState: StateFlow<ScanUiState> = ScanController.state\n    val publishState: StateFlow<PublishUiState> = PublishController.state\n    val joinState = OriginalJoinController.state\n    val diagnosticsState = RuntimeDiagnosticsController.state",
    "AppViewModel state flows"
)
anchor = "    fun startExtractionSmart() {\n"
if "fun startJoinWithInput(" not in s:
    block = '''    fun startJoinWithInput(input: String) {
        val raw = input.trim().ifBlank {
            _scanItems.value
                .filter { it.normalizedUrl.isNotBlank() }
                .joinToString("\\n") { it.normalizedUrl }
        }
        OriginalJoinController.start(raw, engineState.value.selectedWhatsAppPackage)
    }

    fun pauseJoin() = OriginalJoinController.pause()
    fun resumeJoin() = OriginalJoinController.resume()
    fun stopJoin() = OriginalJoinController.stop()
    fun clearJoin() = OriginalJoinController.clearSession()
    fun refreshDiagnostics() = RuntimeDiagnosticsController.refresh()
    fun clearDiagnostics() = RuntimeDiagnosticsController.clearJournal()

'''
    if anchor not in s:
        raise SystemExit("Patch anchor not found: AppViewModel startExtractionSmart")
    s = s.replace(anchor, block + anchor, 1)

# Start Scan only after hard-setting read-only mode.
s = replace_once(
    s,
    "            if (!prepareExplicitOperation(\"SCAN\")) return@launch\n            ScanController.start()",
    "            if (!prepareExplicitOperation(\"SCAN\")) return@launch\n            ScanController.setActionMode(ScanActionMode.SCAN_ONLY)\n            ScanController.setRequestToJoinEnabled(false)\n            ScanController.start()",
    "AppViewModel scan-only start"
)
# Pipeline must also be classification-only.
s = s.replace(
    '                _message.value = "3/4 • بدء الفحص${if (scanState.value.actionMode == ScanActionMode.SCAN_AND_JOIN) " + الانضمام" else ""} • جديد $imported"\n                ScanController.start()',
    '                _message.value = "3/4 • بدء الفحص والتصنيف فقط • جديد $imported"\n                ScanController.setActionMode(ScanActionMode.SCAN_ONLY)\n                ScanController.setRequestToJoinEnabled(false)\n                ScanController.start()'
)
# Global controls include original Join.
s = replace_once(
    s,
    "    fun pauseActiveOperation() {\n        when {\n            publishState.value.running && !publishState.value.paused -> PublishController.pause()",
    "    fun pauseActiveOperation() {\n        when {\n            joinState.value.running && !joinState.value.paused -> OriginalJoinController.pause()\n            publishState.value.running && !publishState.value.paused -> PublishController.pause()",
    "global pause includes join"
)
s = replace_once(
    s,
    "    fun resumeActiveOperation() {\n        when {\n            publishState.value.paused -> PublishController.resume()",
    "    fun resumeActiveOperation() {\n        when {\n            joinState.value.paused -> OriginalJoinController.resume()\n            publishState.value.paused -> PublishController.resume()",
    "global resume includes join"
)
s = replace_once(
    s,
    "        globalJob = null\n        ExtractionController.stop()",
    "        globalJob = null\n        OriginalJoinController.stop()\n        ExtractionController.stop()",
    "global stop includes join"
)
# Ensure clearAll also stops original join (only if not already there in that block).
s = s.replace(
    "        viewModelScope.launch {\n            ExtractionController.stop()\n            ScanController.stop()\n            PublishController.stop()\n            repo.clearAll()",
    "        viewModelScope.launch {\n            OriginalJoinController.stop()\n            ExtractionController.stop()\n            ScanController.stop()\n            PublishController.stop()\n            repo.clearAll()"
)
write(rel, s)

# Make ScanController classifier-only, including persisted settings and both action backends.
rel = "app/src/main/java/com/althmany/extractor/engine/ScanController.kt"
s = read(rel)
# Override persisted action settings after initialization state load.
init_anchor = "        refreshStats()\n    }\n\n    fun attachService"
if "SCAN_READ_ONLY_INIT" not in s:
    init_block = '''        // SCAN_READ_ONLY_INIT: scanning is classification-only in 3.4.1.
        settingsStore.saveActionMode(ScanActionMode.SCAN_ONLY)
        settingsStore.saveRequestToJoinEnabled(false)
        _state.value = _state.value.copy(
            actionMode = ScanActionMode.SCAN_ONLY,
            requestToJoinEnabled = false
        )
        refreshStats()
    }

    fun attachService'''
    if init_anchor not in s:
        raise SystemExit("Patch anchor not found: ScanController initialize")
    s = s.replace(init_anchor, init_block, 1)

s = replace_regex(
    s,
    r"    fun setActionMode\(value: ScanActionMode\) \{.*?\n    \}\n\n    fun setRequestToJoinEnabled\(value: Boolean\) \{.*?\n    \}",
    '''    fun setActionMode(value: ScanActionMode) {
        if (isRunning()) return
        // Scan is intentionally read-only. Join is owned exclusively by OriginalJoinController.
        settingsStore.saveActionMode(ScanActionMode.SCAN_ONLY)
        _state.value = _state.value.copy(actionMode = ScanActionMode.SCAN_ONLY)
    }

    fun setRequestToJoinEnabled(value: Boolean) {
        if (isRunning()) return
        settingsStore.saveRequestToJoinEnabled(false)
        _state.value = _state.value.copy(requestToJoinEnabled = false)
    }''',
    "Scan setters read-only"
)
# Hard guard immediately before any Accessibility membership action.
needle = "    private suspend fun maybeApplyMembershipAction(\n        decision: InviteScanDecision,\n        speed: ScanSpeedProfile,\n        packageName: String\n    ): InviteScanDecision {\n"
if "SCAN_READ_ONLY_GUARD" not in s:
    if needle not in s:
        raise SystemExit("Patch anchor not found: maybeApplyMembershipAction")
    s = s.replace(needle, needle + "        // SCAN_READ_ONLY_GUARD: Scan must never click Join/Request/Confirm.\n        if (RuntimeOperationCoordinator.current() == RuntimeOperation.SCAN) return decision\n", 1)
needle2 = "    private suspend fun maybeApplyMembershipActionShizuku(decision: InviteScanDecision, speed: ScanSpeedProfile, packageName: String): InviteScanDecision {\n"
if needle2 in s and "SCAN_READ_ONLY_SHIZUKU_GUARD" not in s:
    s = s.replace(needle2, needle2 + "        // SCAN_READ_ONLY_SHIZUKU_GUARD\n        if (RuntimeOperationCoordinator.current() == RuntimeOperation.SCAN) return decision\n", 1)
write(rel, s)

# Rebuild the visible 3.4.1 Compose screens without touching extraction/publish internals.
rel = "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"
s = read(rel)
# Responsive outer padding helper.
if "private fun vOuterPadding" not in s:
    s = replace_once(
        s,
        "private fun vBrush() = Brush.verticalGradient(listOf(VBg, VBg2, VBg))\n",
        '''private fun vBrush() = Brush.verticalGradient(listOf(VBg, VBg2, VBg))

@Composable
private fun vOuterPadding(): androidx.compose.ui.unit.Dp = when {
    androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 840 -> 28.dp
    androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 600 -> 18.dp
    else -> 10.dp
}
''',
        "responsive padding helper"
    )
# Use responsive content padding throughout new V341 lazy screens.
s = s.replace("contentPadding = PaddingValues(10.dp)", "contentPadding = PaddingValues(horizontal = vOuterPadding(), vertical = 10.dp)")
# Bottom bar touch/label sizes.
s = s.replace("modifier = Modifier.height(64.dp)", "modifier = Modifier.height(70.dp)", 1)
s = s.replace("label = { Text(label, fontSize = 8.sp) }", "label = { Text(label, fontSize = 9.sp) }", 1)

# Shared expandable input inserted before Join.
join_marker = "@Composable\nfun V341JoinScreen("
if "private fun VExpandableLinkInput" not in s:
    idx = s.find(join_marker)
    if idx < 0:
        raise SystemExit("Patch anchor not found: V341JoinScreen")
    helper = r'''@Composable
private fun VExpandableLinkInput(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String
) {
    var expanded by remember { mutableStateOf(false) }
    val lineCount = remember(value) { value.lineSequence().count { it.isNotBlank() } }
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.take(64_000)) },
        modifier = Modifier.fillMaxWidth(),
        minLines = 4,
        maxLines = if (expanded) 16 else 4,
        placeholder = { Text(placeholder, color = VMuted, fontSize = 10.sp, textAlign = TextAlign.End) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = VCyan,
            unfocusedBorderColor = VLine,
            focusedTextColor = VText,
            unfocusedTextColor = VText,
            cursorColor = VCyan
        ),
        shape = RoundedCornerShape(14.dp)
    )
    if (lineCount > 4) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { expanded = !expanded }) {
                Text(
                    if (expanded) "عرض أقل" else "عرض المزيد (${lineCount - 4})",
                    color = VCyan,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

'''
    s = s[:idx] + helper + s[idx:]

home_new = r'''@Composable
fun V341HomeScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    join: OriginalJoinUiState,
    scan: ScanUiState,
    publish: PublishUiState,
    onExtract: () -> Unit,
    onScan: () -> Unit,
    onPublish: () -> Unit,
    onAutoJoin: () -> Unit,
    onDiagnostics: () -> Unit,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStopAll: () -> Unit,
    onSettings: () -> Unit
) {
    val running = join.running || extractionBusy(engine) || scan.running || publish.running
    val paused = join.paused || engine.status == EngineStatus.PAUSED || scan.paused || publish.paused

    LazyColumn(
        Modifier.fillMaxSize().background(vBrush()).padding(padding),
        contentPadding = PaddingValues(horizontal = vOuterPadding(), vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { VHeader("مرحباً بك", "إدارة واتساب باحتراف — انضمام، استخراج، فحص، نشر وتشخيص", engine, Icons.Default.Home) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VFeature("الانضمام", "محرك Sender الأصلي مع تحقق واستكمال", Icons.Default.Groups, VPurple, Modifier.weight(1f), onAutoJoin)
                VFeature("الاستخراج", "استخراج الروابط من القروبات", Icons.Default.Link, VBlue, Modifier.weight(1f), onExtract)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VFeature("الفحص", "تصنيف الروابط فقط بدون انضمام", Icons.Default.Shield, VGreen, Modifier.weight(1f), onScan)
                VFeature("النشر", "نشر الرسائل في المجموعات", Icons.Default.Send, VOrange, Modifier.weight(1f), onPublish)
            }
        }
        item {
            VTitle("ملخص الأداء", Icons.Default.BarChart)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                VStat("روابط مستخرجة", engine.stats.totalUniqueLinks.toString(), VBlue, Modifier.weight(1f))
                VStat("تم الانضمام", join.joined.toString(), VGreen, Modifier.weight(1f))
                VStat("طلب موافقة", join.requested.toString(), VOrange, Modifier.weight(1f))
                VStat("أخطاء", (join.failed + engine.stats.failedGroups + scan.stats.other + publish.stats.failed).toString(), VRed, Modifier.weight(1f))
            }
        }
        item { VControls(running, paused, engine.selectedWhatsAppPackage != null, onStart, onPause, onResume, onStopAll) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDiagnostics, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, VGreen)) {
                    Icon(Icons.Default.MonitorHeart, null, tint = VGreen)
                    Spacer(Modifier.width(5.dp))
                    Text("التشخيص", color = VText)
                }
                OutlinedButton(onClick = onSettings, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, VCyan)) {
                    Icon(Icons.Default.Settings, null, tint = VCyan)
                    Spacer(Modifier.width(5.dp))
                    Text("الإعدادات", color = VText)
                }
            }
        }
    }
}

'''
s = replace_regex(s, r"@Composable\nfun V341HomeScreen\(.*?(?=@Composable\nprivate fun VFeature)", home_new, "V341HomeScreen")

join_new = r'''@Composable
fun V341JoinScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    join: OriginalJoinUiState,
    stagedRecords: List<ScanRecord>,
    onTargetWhatsApp: (String) -> Unit,
    onImportExtraction: () -> Unit,
    onImportFile: () -> Unit,
    onStart: (String) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStopAll: () -> Unit,
    onClear: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    val stagedCount = stagedRecords.count { it.normalizedUrl.isNotBlank() }
    val startEnabled = (text.isNotBlank() || stagedCount > 0) && engine.selectedWhatsAppPackage != null && !join.running

    LazyColumn(
        Modifier.fillMaxSize().background(vBrush()).padding(padding),
        contentPadding = PaddingValues(horizontal = vOuterPadding(), vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { VHeader("الانضمام", "نفس محرك التطبيق الأصلي — فتح، ضغط، تحقق ثم انتقال تلقائي", engine, Icons.Default.Groups) }
        item {
            VCard {
                VTitle("نسخة واتساب المستهدفة", Icons.Default.Chat)
                Spacer(Modifier.height(7.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(engine.availableWhatsApp.filter { it.launchable && it.canHandleInvite }, key = { it.packageName }) { instance ->
                        VChoice(
                            "${instance.labelAr}\n${instance.packageName}",
                            engine.selectedWhatsAppPackage == instance.packageName,
                            VCyan,
                            Modifier.width(160.dp)
                        ) { onTargetWhatsApp(instance.packageName) }
                    }
                }
            }
        }
        item {
            VCard(accent = VCyan.copy(alpha = .6f)) {
                VTitle("روابط الدعوة", Icons.Default.Link)
                Spacer(Modifier.height(7.dp))
                VExpandableLinkInput(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = "ألصق روابط الدعوة هنا…\nرابط واحد في كل سطر"
                )
                if (stagedCount > 0) {
                    Text("روابط جاهزة من الاستيراد/الاستخراج: $stagedCount", color = VGreen, fontSize = 10.sp)
                }
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onImportFile, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, VBlue)) {
                        Icon(Icons.Default.UploadFile, null, tint = VBlue, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp)); Text("استيراد ملف", color = VText, fontSize = 10.sp)
                    }
                    OutlinedButton(onClick = onImportExtraction, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, VPurple)) {
                        Icon(Icons.Default.Download, null, tint = VPurple, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp)); Text("من الاستخراج", color = VText, fontSize = 10.sp)
                    }
                }
            }
        }
        item {
            VCard(accent = VPurple.copy(alpha = .6f)) {
                VTitle("المحرك الأصلي", Icons.Default.Memory, VPurple)
                Spacer(Modifier.height(7.dp))
                Text("Backend: ${join.backend}  •  Stage: ${join.stage}", color = VMuted, fontSize = 10.sp, textAlign = TextAlign.End)
                Text(join.message, color = if (join.error == null) VText else VRed, fontSize = 11.sp, textAlign = TextAlign.End)
                join.currentUrl?.let { Text("الرابط الحالي ${join.currentPosition}/${join.total}: $it", color = VCyan, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                join.lastAction?.let { Text("آخر إجراء: $it", color = VGreen, fontSize = 9.sp) }
            }
        }
        item {
            VTitle("نتائج الانضمام", Icons.Default.BarChart)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                VStat("تم الانضمام", join.joined.toString(), VGreen, Modifier.weight(1f))
                VStat("موافقة المشرف", join.requested.toString(), VOrange, Modifier.weight(1f))
                VStat("فشل", join.failed.toString(), VRed, Modifier.weight(1f))
                VStat("متبقي", join.remaining.toString(), VCyan, Modifier.weight(1f))
            }
        }
        item {
            Button(
                onClick = { val pending = text; text = ""; onStart(pending) },
                enabled = startEnabled,
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VCyan, contentColor = Color(0xFF00131A)),
                shape = RoundedCornerShape(17.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text("بدء الانضمام بالمحرك الأصلي", fontWeight = FontWeight.Bold)
            }
        }
        item { VControls(join.running, join.paused, startEnabled, { val pending = text; text = ""; onStart(pending) }, onPause, onResume, onStopAll) }
        item {
            OutlinedButton(onClick = onClear, enabled = !join.running, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, VRed)) {
                Icon(Icons.Default.Delete, null, tint = VRed); Spacer(Modifier.width(5.dp)); Text("مسح جلسة الانضمام", color = VRed)
            }
        }
    }
}

'''
s = replace_regex(s, r"@Composable\nfun V341JoinScreen\(.*?(?=@Composable\nfun V341ExtractionScreen)", join_new, "V341JoinScreen")

scan_new = r'''@Composable
fun V341ScanScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    scan: ScanUiState,
    records: List<ScanRecord>,
    onTargetWhatsApp: (String) -> Unit,
    onAddLinks: (String) -> Unit,
    onImportExtraction: () -> Unit,
    onImportFile: () -> Unit,
    onSpeed: (ScanSpeedProfile) -> Unit,
    onAttempts: (Int) -> Unit,
    onStart: (String) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStopAll: () -> Unit,
    onClear: () -> Unit,
    onExport: (ExportFormat) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val startEnabled = (records.isNotEmpty() || text.isNotBlank()) && engine.selectedWhatsAppPackage != null

    LazyColumn(
        Modifier.fillMaxSize().background(vBrush()).padding(padding),
        contentPadding = PaddingValues(horizontal = vOuterPadding(), vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { VHeader("الفحص", "يفتح الرابط ويقرأ واتساب ويصنف فقط — لا ينضم ولا يرسل طلباً", engine, Icons.Default.Shield) }
        item {
            VCard {
                VTitle("نسخة واتساب المستهدفة", Icons.Default.Chat)
                Spacer(Modifier.height(7.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(engine.availableWhatsApp.filter { it.launchable && it.canHandleInvite }, key = { it.packageName }) { instance ->
                        VChoice("${instance.labelAr}\n${instance.packageName}", engine.selectedWhatsAppPackage == instance.packageName, VGreen, Modifier.width(160.dp)) {
                            onTargetWhatsApp(instance.packageName)
                        }
                    }
                }
            }
        }
        item {
            VCard(accent = VGreen.copy(alpha = .6f)) {
                VTitle("روابط الفحص", Icons.Default.Link, VGreen)
                Spacer(Modifier.height(7.dp))
                VExpandableLinkInput(text, { text = it }, "ألصق روابط الدعوة للفحص…\nأول 4 روابط تظهر افتراضيًا")
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(
                        onClick = { if (text.isNotBlank()) { onAddLinks(text); text = "" } },
                        enabled = text.isNotBlank(),
                        modifier = Modifier.weight(1f), border = BorderStroke(1.dp, VGreen)
                    ) { Text("إضافة", color = VText) }
                    OutlinedButton(onClick = onImportFile, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, VBlue)) { Text("ملف", color = VText) }
                    OutlinedButton(onClick = onImportExtraction, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, VPurple)) { Text("الاستخراج", color = VText) }
                }
            }
        }
        item {
            VCard {
                VTitle("وضع الفحص الآمن", Icons.Default.VerifiedUser, VGreen)
                Spacer(Modifier.height(7.dp))
                VChoice("تصنيف فقط — بدون انضمام", true, VGreen, Modifier.fillMaxWidth()) { }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ScanSpeedProfile.entries.forEach { speed ->
                        VChoice(speed.labelAr, scan.speed == speed, VCyan, Modifier.weight(1f)) { onSpeed(speed) }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Text("عدد محاولات التحقق", color = VMuted, fontSize = 10.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..5).forEach { n -> VChoice(n.toString(), scan.maxAttempts == n, VCyan, Modifier.weight(1f)) { onAttempts(n) } }
                }
            }
        }
        item {
            VTitle("التصنيفات", Icons.Default.BarChart)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                VStat("بدون موافقة", scan.stats.direct.toString(), VGreen, Modifier.weight(1f))
                VStat("موافقة المشرف", scan.stats.approval.toString(), VPurple, Modifier.weight(1f))
                VStat("غير صالح", scan.stats.invalid.toString(), VRed, Modifier.weight(1f))
                VStat("غير مؤكد", scan.stats.unknown.toString(), VOrange, Modifier.weight(1f))
            }
        }
        if (records.isNotEmpty()) {
            item { VTitle("النتائج التفصيلية", Icons.Default.FactCheck) }
            items(records.take(40), key = { it.id }) { record -> VScanResultRow(record) }
        }
        item {
            Button(
                onClick = { val pending = text; text = ""; onStart(pending) },
                enabled = startEnabled && !scan.running,
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VGreen, contentColor = Color(0xFF001A12)),
                shape = RoundedCornerShape(17.dp)
            ) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(5.dp)); Text("بدء الفحص والتصنيف", fontWeight = FontWeight.Bold) }
        }
        item { VControls(scan.running, scan.paused, startEnabled, { val pending = text; text = ""; onStart(pending) }, onPause, onResume, onStopAll) }
        item {
            VCard {
                VTitle("تصدير النتائج", Icons.Default.Download)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(ExportFormat.CSV, ExportFormat.TXT, ExportFormat.JSON).forEach { format ->
                        OutlinedButton(onClick = { onExport(format) }, modifier = Modifier.weight(1f)) { Text(format.name) }
                    }
                }
            }
        }
        item { OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, VRed)) { Text("مسح نتائج الفحص", color = VRed) } }
    }
}

@Composable
private fun VScanResultRow(record: ScanRecord) {
    val tint = when (record.status) {
        ScanStatus.DIRECT -> VGreen
        ScanStatus.APPROVAL, ScanStatus.REQUEST_PENDING -> VPurple
        ScanStatus.ALREADY_MEMBER, ScanStatus.JOINED -> VBlue
        ScanStatus.INVALID, ScanStatus.FULL, ScanStatus.REMOVED, ScanStatus.ACCOUNT_LIMIT, ScanStatus.ERROR -> VRed
        ScanStatus.UNKNOWN, ScanStatus.ACTION_UNCERTAIN, ScanStatus.NETWORK_ERROR -> VOrange
        else -> VMuted
    }
    val status = when (record.status) {
        ScanStatus.DIRECT -> "بدون موافقة المشرف"
        ScanStatus.APPROVAL -> "موافقة المشرف مطلوبة"
        ScanStatus.INVALID -> "غير شغال / غير صالح"
        ScanStatus.FULL -> "القروب ممتلئ"
        ScanStatus.REMOVED -> "الدعوة/العضوية غير متاحة"
        ScanStatus.ALREADY_MEMBER -> "عضو مسبقًا"
        ScanStatus.REQUEST_PENDING -> "طلب انضمام قيد المراجعة"
        else -> record.status.labelAr
    }
    VCard(accent = tint.copy(alpha = .55f)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = tint.copy(alpha = .14f), border = BorderStroke(1.dp, tint.copy(alpha = .6f))) {
                Text("${record.confidence}%", modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = tint, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text(record.groupName ?: "اسم القروب غير متاح", color = VText, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                Text(status, color = tint, fontSize = 10.sp, textAlign = TextAlign.End)
                Text(record.memberCountText ?: "عدد الأعضاء غير متاح", color = VMuted, fontSize = 9.sp, textAlign = TextAlign.End)
                Text(record.normalizedUrl, color = VMuted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun V341DiagnosticsScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    join: OriginalJoinUiState,
    diagnostics: RuntimeDiagnosticsSnapshot,
    onRefresh: () -> Unit,
    onCopy: (String) -> Unit,
    onExport: (String) -> Unit,
    onClear: () -> Unit
) {
    val report = diagnostics.asText()
    LazyColumn(
        Modifier.fillMaxSize().background(vBrush()).padding(padding),
        contentPadding = PaddingValues(horizontal = vOuterPadding(), vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { VHeader("التشخيص الحقيقي", "حالة المحركات والبيئة والأخطاء من Runtime الفعلي", engine, Icons.Default.MonitorHeart) }
        item {
            VCard(accent = VGreen.copy(alpha = .55f)) {
                VTitle("جاهزية البيئة", Icons.Default.HealthAndSafety, VGreen)
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    VStatus("Accessibility Sender", if (diagnostics.senderAccessibilityConnected) "متصل" else if (diagnostics.senderAccessibilityEnabled) "مفعّل/غير مرتبط" else "غير مفعّل", diagnostics.senderAccessibilityConnected, Modifier.weight(1f))
                    VStatus("Shizuku", if (diagnostics.shizukuReady) "جاهز" else "غير جاهز", diagnostics.shizukuReady, Modifier.weight(1f))
                }
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    VStatus("Extractor Accessibility", if (diagnostics.extractorAccessibilityConnected) "متصل" else "غير متصل", diagnostics.extractorAccessibilityConnected, Modifier.weight(1f))
                    VStatus("الإنترنت", if (diagnostics.networkValidated) "متصل" else "غير متحقق", diagnostics.networkValidated, Modifier.weight(1f))
                }
            }
        }
        item {
            VCard {
                VTitle("Runtime", Icons.Default.Memory)
                Spacer(Modifier.height(6.dp))
                listOf(
                    "العملية" to diagnostics.operation,
                    "الهدف" to diagnostics.targetPackage,
                    "الملف" to "${diagnostics.profileKey} • ${diagnostics.profileKind}",
                    "المحرك" to diagnostics.backend,
                    "المرحلة" to diagnostics.stage,
                    "آخر إجراء" to diagnostics.lastAction,
                    "الصحة" to "${diagnostics.healthDirective} • ${diagnostics.healthAction} • ${diagnostics.healthConfidence} • ${diagnostics.watchdog}",
                    "الحالة" to diagnostics.diagnostic
                ).forEach { (label, value) ->
                    Text("$label: $value", color = VText, fontSize = 10.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(3.dp))
                }
                if (join.currentUrl != null) Text("الرابط الحالي: ${join.currentUrl}", color = VCyan, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        item {
            VCard {
                VTitle("آخر سجل تشخيصي", Icons.Default.Terminal)
                Spacer(Modifier.height(6.dp))
                Text(diagnostics.journal.ifBlank { "لا توجد سجلات بعد" }, color = VMuted, fontSize = 9.sp, maxLines = 18, overflow = TextOverflow.Ellipsis)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = onRefresh, modifier = Modifier.weight(1f)) { Text("تحديث") }
                OutlinedButton(onClick = { onCopy(report) }, modifier = Modifier.weight(1f)) { Text("نسخ التقرير") }
                OutlinedButton(onClick = { onExport(report) }, modifier = Modifier.weight(1f)) { Text("تصدير") }
            }
        }
        item { OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, VRed)) { Text("مسح سجل التشخيص", color = VRed) } }
    }
}

'''
s = replace_regex(s, r"@Composable\nfun V341ScanScreen\(.*?(?=@Composable\nfun V341PublishScreen)", scan_new, "V341ScanScreen")
write(rel, s)

# Main Activity: global RTL, original Join wiring, diagnostics route/export.
rel = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = read(rel)
s = replace_once(
    s,
    "import com.althmany.extractor.ui.V341ScanScreen\nimport com.althmany.extractor.ui.V341PublishScreen",
    "import com.althmany.extractor.ui.V341ScanScreen\nimport com.althmany.extractor.ui.V341PublishScreen\nimport com.althmany.extractor.ui.V341DiagnosticsScreen",
    "MainActivity diagnostics import"
)
s = replace_once(
    s,
    "        setContent {\n            AlThmanyTheme { ExtractorAppUi(viewModel) }\n        }",
    "        setContent {\n            AlThmanyTheme {\n                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {\n                    ExtractorAppUi(viewModel)\n                }\n            }\n        }",
    "global RTL provider"
)
s = replace_once(
    s,
    "    val publishState by viewModel.publishState.collectAsState()\n    val publishItems by viewModel.publishItems.collectAsState()",
    "    val publishState by viewModel.publishState.collectAsState()\n    val publishItems by viewModel.publishItems.collectAsState()\n    val joinState by viewModel.joinState.collectAsState()\n    val diagnostics by viewModel.diagnosticsState.collectAsState()",
    "MainActivity join/diagnostics state"
)
s = replace_once(
    s,
    "    var showHelp by remember { mutableStateOf(false) }",
    "    var showHelp by remember { mutableStateOf(false) }\n    var pendingDiagnosticsText by remember { mutableStateOf(\"\") }",
    "diagnostics pending text"
)
# Add diagnostics document launcher after publish launcher.
anchor = '''    val createPublishDocument = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        if (uri != null) runCatching { ExportManager.exportPublish(context.contentResolver, uri, pendingFormat, publishItems) }
    }
'''
if "createDiagnosticsDocument" not in s:
    addition = anchor + '''    val createDiagnosticsDocument = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingDiagnosticsText) }
        }
    }
'''
    if anchor not in s:
        raise SystemExit("Patch anchor not found: diagnostics document launcher")
    s = s.replace(anchor, addition, 1)

s = replace_once(
    s,
    "            val anyRunning = extractionRunning || scanState.running || publishState.running\n            val anyPaused = engine.status == com.althmany.extractor.data.EngineStatus.PAUSED || scanState.paused || publishState.paused",
    "            val anyRunning = joinState.running || extractionRunning || scanState.running || publishState.running\n            val anyPaused = joinState.paused || engine.status == com.althmany.extractor.data.EngineStatus.PAUSED || scanState.paused || publishState.paused",
    "global bar includes join"
)
s = replace_once(
    s,
    '''            val operationLabel = when {
                publishState.running || publishState.paused -> "النشر • ${publishState.info}"
                scanState.running || scanState.paused -> if (scanState.actionMode == ScanActionMode.SCAN_ONLY) "الفحص • ${scanState.message}" else "الانضمام • ${scanState.message}"
                extractionRunning || engine.status == com.althmany.extractor.data.EngineStatus.PAUSED -> "الاستخراج • ${engine.message}"
                else -> "التحكم العام • لا توجد عملية نشطة"
            }''',
    '''            val operationLabel = when {
                joinState.running || joinState.paused -> "الانضمام • ${joinState.message}"
                publishState.running || publishState.paused -> "النشر • ${publishState.info}"
                scanState.running || scanState.paused -> "الفحص • ${scanState.message}"
                extractionRunning || engine.status == com.althmany.extractor.data.EngineStatus.PAUSED -> "الاستخراج • ${engine.message}"
                else -> "التحكم العام • لا توجد عملية نشطة"
            }''',
    "global operation label"
)
# Home call: replace whole block up to EXTRACT branch for reliability.
home_call = r'''                AppScreen.HOME -> V341HomeScreen(
                    padding = zero,
                    engine = engine,
                    join = joinState,
                    scan = scanState,
                    publish = publishState,
                    onExtract = { screen = AppScreen.EXTRACT },
                    onScan = { viewModel.importScanLinksFromExtraction(); screen = AppScreen.SCAN },
                    onPublish = { viewModel.reloadPublishItems(); screen = AppScreen.PUBLISH },
                    onAutoJoin = { viewModel.importScanLinksFromExtraction(); screen = AppScreen.JOIN },
                    onDiagnostics = { viewModel.refreshDiagnostics(); screen = AppScreen.DIAGNOSTICS },
                    onStart = viewModel::startExtractionSmart,
                    onPause = viewModel::pauseActiveOperation,
                    onResume = viewModel::resumeActiveOperation,
                    onStopAll = viewModel::stopAllOperations,
                    onSettings = { screen = AppScreen.SETTINGS }
                )

'''
s = replace_regex(s, r"                AppScreen\.HOME -> V341HomeScreen\(.*?(?=                AppScreen\.EXTRACT ->)", home_call, "MainActivity HOME wiring")
join_call = r'''                AppScreen.JOIN -> V341JoinScreen(
                    padding = zero,
                    engine = engine,
                    join = joinState,
                    stagedRecords = scanItems,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onImportExtraction = viewModel::importScanLinksFromExtraction,
                    onImportFile = {
                        openScanFile.launch(
                            arrayOf(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel",
                                "text/csv",
                                "text/plain",
                                "application/octet-stream"
                            )
                        )
                    },
                    onStart = viewModel::startJoinWithInput,
                    onPause = viewModel::pauseJoin,
                    onResume = viewModel::resumeJoin,
                    onStopAll = viewModel::stopJoin,
                    onClear = viewModel::clearJoin
                )

'''
s = replace_regex(s, r"                AppScreen\.JOIN -> V341JoinScreen\(.*?(?=                AppScreen\.SCAN ->)", join_call, "MainActivity JOIN wiring")
scan_call = r'''                AppScreen.SCAN -> V341ScanScreen(
                    padding = zero,
                    engine = engine,
                    scan = scanState,
                    records = scanItems,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onAddLinks = viewModel::addScanLinks,
                    onImportExtraction = viewModel::importScanLinksFromExtraction,
                    onImportFile = {
                        openScanFile.launch(
                            arrayOf(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel",
                                "text/csv",
                                "text/plain",
                                "application/octet-stream"
                            )
                        )
                    },
                    onSpeed = viewModel::setScanSpeed,
                    onAttempts = viewModel::setScanMaxAttempts,
                    onStart = viewModel::startScanWithInput,
                    onPause = viewModel::pauseActiveOperation,
                    onResume = viewModel::resumeActiveOperation,
                    onStopAll = viewModel::stopAllOperations,
                    onClear = viewModel::clearScan,
                    onExport = { format ->
                        pendingFormat = format
                        createScanDocument.launch("AL-thmany-scan.${format.extension}")
                    }
                )

'''
s = replace_regex(s, r"                AppScreen\.SCAN -> V341ScanScreen\(.*?(?=                AppScreen\.PUBLISH ->)", scan_call, "MainActivity SCAN wiring")
# Add diagnostics branch before settings.
if "AppScreen.DIAGNOSTICS -> V341DiagnosticsScreen" not in s:
    marker = "                AppScreen.SETTINGS -> WorkspaceSettingsScreen("
    diag_branch = '''                AppScreen.DIAGNOSTICS -> V341DiagnosticsScreen(
                    padding = zero,
                    engine = engine,
                    join = joinState,
                    diagnostics = diagnostics,
                    onRefresh = viewModel::refreshDiagnostics,
                    onCopy = { report ->
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("AL-thmany diagnostics", report))
                    },
                    onExport = { report ->
                        pendingDiagnosticsText = report
                        createDiagnosticsDocument.launch("AL-thmany-runtime-diagnostics.txt")
                    },
                    onClear = viewModel::clearDiagnostics
                )

'''
    if marker not in s:
        raise SystemExit("Patch anchor not found: settings branch")
    s = s.replace(marker, diag_branch + marker, 1)
write(rel, s)

print("\nPATCH APPLICATION COMPLETE")
