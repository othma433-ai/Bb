#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import re
import shutil
import sys

BUNDLE = Path(__file__).resolve().parent
PATCH = BUNDLE / "patch"
TEMPLATES = PATCH / "templates"
ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()

def fail(message):
    raise SystemExit(f"PATCH ERROR: {message}")

def repo_file(rel):
    return ROOT / rel

def read_repo(rel):
    p = repo_file(rel)
    if not p.exists():
        fail(f"missing repository file: {rel}")
    return p.read_text(encoding="utf-8")

def write_repo(rel, value):
    p = repo_file(rel)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(value, encoding="utf-8")

def replace_once(text, old, new, label):
    if old in text:
        return text.replace(old, new, 1)
    if new in text:
        return text
    fail(f"anchor not found: {label}")

def regex_replace_once(text, pattern, replacement, label):
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count == 1:
        return updated
    fail(f"regex anchor not found: {label}")

# Validate the expected base project before touching anything.
required_base = [
    "app/src/main/java/com/althmany/extractor/MainActivity.kt",
    "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt",
    "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt",
    "app/src/main/AndroidManifest.xml",
]
for rel in required_base:
    if not repo_file(rel).exists():
        fail(f"base file missing: {rel}")

# Backup only files changed in-place.
backup = ROOT / ".althmany_backups" / datetime.now().strftime("%Y%m%d-%H%M%S")
for rel in required_base[:3]:
    src = repo_file(rel)
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

# Install additive production/test files and validator.
overlay_files = [
    "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt",
    "app/src/main/java/com/althmany/extractor/ui/LinkPreviewPolicy.kt",
    "app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt",
    "app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt",
    "app/src/test/java/com/althmany/extractor/ui/LinkPreviewPolicyTest.kt",
    "scripts/validate_professional_rebuild_3_4_1.py",
]
for rel in overlay_files:
    src = PATCH / rel
    if not src.exists():
        fail(f"bundle file missing: {rel}")
    write_repo(rel, src.read_text(encoding="utf-8"))

# Add spec/plan.
for rel in [
    "docs/superpowers/specs/2026-09-16-rtl-join-scan-diagnostics-design.md",
    "docs/superpowers/plans/2026-09-16-rtl-join-scan-diagnostics.md",
]:
    src = BUNDLE / rel
    if not src.exists():
        fail(f"bundle documentation missing: {rel}")
    write_repo(rel, src.read_text(encoding="utf-8"))

# -------------------------------------------------------------------------
# AppViewModel.kt
# -------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt"
s = read_repo(rel)

if "import com.althmany.groupmanager.model.PreferredTarget" not in s:
    s = replace_once(
        s,
        "import com.althmany.groupmanager.GroupManagerApp\n",
        "import com.althmany.groupmanager.GroupManagerApp\n"
        "import com.althmany.groupmanager.model.PreferredTarget\n"
        "import com.althmany.groupmanager.util.WhatsAppLauncher\n",
        "AppViewModel imports"
    )

s = replace_once(
    s,
    '            if (!prepareExplicitOperation("SCAN")) return@launch\n            ScanController.start()\n',
    '            if (!prepareExplicitOperation("SCAN")) return@launch\n'
    '            // 3.4.1: Scan classifies only. Membership actions belong to original Sender/Join.\n'
    '            ScanController.setActionMode(ScanActionMode.SCAN_ONLY)\n'
    '            ScanController.setRequestToJoinEnabled(false)\n'
    '            ScanController.start()\n',
    "startScanWithInput classification-only"
)

s = replace_once(
    s,
    '''            if (_scanItems.value.isNotEmpty()) {
                _message.value = "3/4 • بدء الفحص${if (scanState.value.actionMode == ScanActionMode.SCAN_AND_JOIN) " + الانضمام" else ""} • جديد $imported"
                ScanController.start()
''',
    '''            if (_scanItems.value.isNotEmpty()) {
                _message.value = "3/4 • بدء الفحص والتصنيف • جديد $imported"
                ScanController.setActionMode(ScanActionMode.SCAN_ONLY)
                ScanController.setRequestToJoinEnabled(false)
                ScanController.start()
''',
    "pipeline classification-only"
)

s = replace_once(
    s,
    "    fun setTargetWhatsApp(packageName: String) = ExtractionController.setTargetWhatsAppPackage(packageName)\n",
    '''    fun setTargetWhatsApp(packageName: String) {
        ExtractionController.setTargetWhatsAppPackage(packageName)
        val senderApp = getApplication<Application>() as? GroupManagerApp ?: return
        val discovered = WhatsAppLauncher.discoverWhatsAppApps(senderApp)
            .firstOrNull { it.packageName == packageName }
        senderApp.preferences.clearRemoteSecureTarget()
        senderApp.preferences.selectedWhatsAppPackage = packageName
        senderApp.preferences.selectedWhatsAppLabel = discovered?.label ?: packageName
        senderApp.preferences.preferredTarget = PreferredTarget.AUTO
    }
''',
    "target synchronization"
)

write_repo(rel, s)

# -------------------------------------------------------------------------
# WorkspaceV341Screens.kt: readable sizing + diagnostics bottom item.
# -------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"
s = read_repo(rel)
s = replace_once(
    s,
    '        Triple(AppScreen.SETTINGS, "الإعدادات", Icons.Default.Settings)\n',
    '        Triple(AppScreen.LOGS, "التشخيص", Icons.Default.Settings)\n',
    "diagnostics bottom navigation"
)

# Improve readability throughout the V341 screens without changing their behavior.
s = s.replace("Column(Modifier.padding(10.dp), content = content)", "Column(Modifier.padding(14.dp), content = content)")
s = s.replace("contentPadding = PaddingValues(10.dp)", "contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)")
s = s.replace("fontSize = 8.sp", "fontSize = 10.sp")
s = s.replace("fontSize = 9.sp", "fontSize = 11.sp")
s = s.replace("fontSize = 13.sp", "fontSize = 15.sp")
write_repo(rel, s)

# -------------------------------------------------------------------------
# MainActivity.kt: original Join bridge + professional Join/Scan + diagnostics.
# -------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = read_repo(rel)

if "import androidx.lifecycle.lifecycleScope" not in s:
    s = replace_once(
        s,
        "import androidx.activity.viewModels\n",
        "import androidx.activity.viewModels\nimport androidx.lifecycle.lifecycleScope\n",
        "lifecycleScope import"
    )

imports_anchor = "import com.althmany.extractor.export.ExportManager\n"
if "import com.althmany.extractor.join.OriginalJoinCoordinator" not in s:
    s = replace_once(
        s,
        imports_anchor,
        imports_anchor
        + "import com.althmany.extractor.join.OriginalJoinCoordinator\n"
        + "import com.althmany.groupmanager.GroupManagerApp\n"
        + "import com.althmany.groupmanager.ui.MainViewModel\n"
        + "import com.althmany.groupmanager.util.DocumentIO\n",
        "original join imports"
    )

if "import com.althmany.extractor.ui.ProfessionalJoinScreen" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.ui.V341PublishScreen\n",
        "import com.althmany.extractor.ui.V341PublishScreen\n"
        "import com.althmany.extractor.ui.ProfessionalJoinScreen\n"
        "import com.althmany.extractor.ui.ProfessionalScanScreen\n"
        "import com.althmany.extractor.ui.V341DiagnosticsScreen\n",
        "professional screen imports"
    )

old_class = '''class MainActivity : ComponentActivity() {
    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ExtractorFeatureRuntime.initialize(applicationContext)
        setContent {
            AlThmanyTheme { ExtractorAppUi(viewModel) }
        }
    }
'''
new_class = '''class MainActivity : ComponentActivity() {
    private val viewModel: AppViewModel by viewModels()
    private val senderViewModel: MainViewModel by viewModels {
        MainViewModel.Factory(application as GroupManagerApp)
    }
    private lateinit var joinCoordinator: OriginalJoinCoordinator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ExtractorFeatureRuntime.initialize(applicationContext)
        joinCoordinator = OriginalJoinCoordinator(
            context = this,
            app = application as GroupManagerApp,
            senderViewModel = senderViewModel,
            scope = lifecycleScope
        )
        setContent {
            AlThmanyTheme { ExtractorAppUi(viewModel, joinCoordinator) }
        }
    }
'''
s = replace_once(s, old_class, new_class, "MainActivity join coordinator")

s = replace_once(
    s,
    "private fun ExtractorAppUi(viewModel: AppViewModel) {\n",
    "private fun ExtractorAppUi(viewModel: AppViewModel, joinCoordinator: OriginalJoinCoordinator) {\n",
    "ExtractorAppUi signature"
)

s = replace_once(
    s,
    "    val engine by viewModel.engineState.collectAsState()\n",
    "    val engine by viewModel.engineState.collectAsState()\n"
    "    val joinState by joinCoordinator.state.collectAsState()\n",
    "join state collector"
)

if "val openJoinFile =" not in s:
    join_picker = '''    val openJoinFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            DocumentIO.readText(context.contentResolver, uri, 120_000)
                .onSuccess(joinCoordinator::setDraft)
        }
    }

'''
    s = replace_once(
        s,
        "    val pickPublishAttachment = rememberLauncherForActivityResult",
        join_picker + "    val pickPublishAttachment = rememberLauncherForActivityResult",
        "join file picker"
    )

s = replace_once(
    s,
    "            val anyRunning = extractionRunning || scanState.running || publishState.running\n",
    "            val anyRunning = joinState.running || extractionRunning || scanState.running || publishState.running\n",
    "global running includes join"
)
s = replace_once(
    s,
    "            val anyPaused = engine.status == com.althmany.extractor.data.EngineStatus.PAUSED || scanState.paused || publishState.paused\n",
    "            val anyPaused = joinState.paused || engine.status == com.althmany.extractor.data.EngineStatus.PAUSED || scanState.paused || publishState.paused\n",
    "global paused includes join"
)

s = replace_once(
    s,
    '''            val operationLabel = when {
                publishState.running || publishState.paused -> "النشر • ${publishState.info}"
''',
    '''            val operationLabel = when {
                joinState.running || joinState.paused -> "الانضمام • ${joinState.message}"
                publishState.running || publishState.paused -> "النشر • ${publishState.info}"
''',
    "global operation label"
)

s = replace_once(
    s,
    '''                    onStart = viewModel::startAllSmart,
                    onPause = viewModel::pauseActiveOperation,
                    onResume = viewModel::resumeActiveOperation,
                    onStopAll = viewModel::stopAllOperations
''',
    '''                    onStart = viewModel::startAllSmart,
                    onPause = {
                        if (joinState.running || joinState.paused) joinCoordinator.pause()
                        else viewModel.pauseActiveOperation()
                    },
                    onResume = {
                        if (joinState.paused) joinCoordinator.resume()
                        else viewModel.resumeActiveOperation()
                    },
                    onStopAll = {
                        if (joinState.running || joinState.paused) joinCoordinator.stop()
                        viewModel.stopAllOperations()
                    }
''',
    "global operation controls"
)

s = replace_once(
    s,
    "                        AppScreen.JOIN -> viewModel.importScanLinksFromExtraction()\n",
    "                        AppScreen.JOIN -> joinCoordinator.refresh()\n",
    "join navigation refresh"
)

s = replace_once(
    s,
    '''                    onAutoJoin = {
                        viewModel.setScanActionMode(ScanActionMode.SCAN_AND_JOIN)
                        viewModel.setScanRequestToJoinEnabled(true)
                        viewModel.importScanLinksFromExtraction()
                        screen = AppScreen.JOIN
                    },
''',
    '''                    onAutoJoin = { screen = AppScreen.JOIN },
''',
    "home join navigation"
)

join_template = (TEMPLATES / "main_join_call.txt").read_text(encoding="utf-8")
scan_template = (TEMPLATES / "main_scan_call.txt").read_text(encoding="utf-8")

s = regex_replace_once(
    s,
    r"                AppScreen\.JOIN -> V341JoinScreen\(.*?\n                \)\n\n(?=                AppScreen\.SCAN ->)",
    join_template.rstrip("\n"),
    "join screen call"
)

s = regex_replace_once(
    s,
    r"                AppScreen\.SCAN -> V341ScanScreen\(.*?\n                \)\n\n(?=                AppScreen\.PUBLISH ->)",
    scan_template.rstrip("\n"),
    "scan screen call"
)

s = replace_once(
    s,
    "                AppScreen.LOGS -> LogsScreen(zero, logs, viewModel::reloadLogs)\n",
    "                AppScreen.LOGS -> V341DiagnosticsScreen(zero) { screen = AppScreen.SETTINGS }\n",
    "diagnostics route"
)

write_repo(rel, s)

print(f"Patch installed successfully. Backup: {backup}")
