# AL-thmany Sender 3.4.1 — Professional RTL / Join / Scan / Diagnostics

هذه حزمة تعديل للفرع:
`feat/full-features-3.4.1`

## التعديلات الأساسية
- واجهة عربية RTL مع تحسين المقاسات والخطوط والمسافات.
- شاشة الانضمام الجديدة لا تستخدم ScanController للعضوية.
- الانضمام مربوط بالمحرك الأصلي:
  - MainViewModel الأصلي.
  - QuickJoinAccessibilityService.
  - ShizukuAutomationService.
  - Queue / pause / resume / stop / verification.
- اختيار نسخة واتساب في الواجهة الجديدة يزامن إعدادات Sender الأصلية.
- Work Profile / Secure Folder / Dual Messenger المتقدم يستخدم إدارة النسخ الموجودة أصلاً في Sender.
- الفحص أصبح تصنيفياً فقط:
  - بدون موافقة المشرف.
  - موافقة المشرف.
  - عضو مسبقاً.
  - طلب انضمام سابق.
  - غير صالح/منتهي.
  - ممتلئ/Removed/Account limit.
  - Network/Error/Unknown.
- اسم القروب وعدد الأعضاء يظهران عندما يقدمهما WhatsApp؛ وإلا يظهر «عدد الأعضاء غير متاح».
- حقول الروابط تعرض أول 4 روابط ثم «عرض المزيد (N)» و«عرض أقل».
- شاشة تشخيص حقيقية تجمع:
  - Accessibility.
  - Shizuku.
  - Android Profile.
  - WhatsApp target.
  - RuntimeOperation owner.
  - Automation stage/diagnostic.
  - RuntimeHealthMonitor.
  - RuntimeDiagnosticStore.
  - نسخ/تصدير/مسح.
- اختبار JUnit مستقل لسياسة أول أربعة روابط.
- Professional source contract قبل الـcommit.

## طريقة الاستخدام في Codespaces

ارفع ملف ZIP إلى جذر المستودع، ثم نفذ هذا الأمر الواحد:

```bash
cd /workspaces/Bb && rm -rf AL-thmany-3.4.1-Professional-RTL-Join-Scan-Diagnostics && unzip -q AL-thmany-3.4.1-Professional-RTL-Join-Scan-Diagnostics.zip -d . && bash AL-thmany-3.4.1-Professional-RTL-Join-Scan-Diagnostics/apply_professional_rebuild_3_4_1.sh
```

## ما يجب أن يظهر

قبل التطبيق:
`PROFESSIONAL REBUILD CONTRACT: FAIL`
ثم:
`RED CONFIRMED`

بعد التطبيق:
`PROFESSIONAL REBUILD CONTRACT: PASS`

ثم أحد الخيارين:
- `LOCAL GRADLE: PASS`
- أو `LOCAL GRADLE: NETWORK BLOCKED` فقط إذا كانت شبكة Codespaces تمنع تنزيل Gradle/dependencies.

إذا كان هناك خطأ compile/test حقيقي:
`LOCAL GRADLE: FAILED`
وفي هذه الحالة **لن يعمل السكربت commit أو push**.

عند النجاح:
`SOURCE REBUILD: PASS`
ثم:
`>>> FINISHED — TERMINAL REMAINS OPEN <<<`

## ملاحظة
GitHub Actions هو بوابة Android النهائية: unit tests + lint + assembleDebug. نجاح Source Contract وحده لا يعني أن APK اعتمد ميدانياً على الهاتف.
