#!/usr/bin/env bash
# AL-thmany 3.4.1 professional rebuild.
# Run with: bash apply_professional_rebuild_3_4_1.sh
# The work happens in a subshell, so a failure does not close the parent Codespaces terminal.

set -u

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

(
  set -e

  ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
  if [ -z "$ROOT" ]; then
    echo "ERROR: شغّل الملف من داخل مستودع Bb في Codespaces."
    false
  fi

  cd "$ROOT"

  echo "============================================================"
  echo "AL-thmany 3.4.1 — Professional RTL / Join / Scan / Diagnostics"
  echo "============================================================"
  echo "Repo: $ROOT"
  echo "Branch before: $(git branch --show-current)"
  echo "Commit before: $(git rev-parse --short HEAD)"

  if [ "$(git branch --show-current)" != "feat/full-features-3.4.1" ]; then
    echo
    echo "=== فتح فرع التطوير 3.4.1 ==="
    git checkout feat/full-features-3.4.1
  fi

  echo
  echo "=== مزامنة الفرع ==="
  git pull --ff-only origin feat/full-features-3.4.1

  echo
  echo "=== RED — التحقق قبل التطبيق ==="
  if python3 "$SELF_DIR/patch/scripts/validate_professional_rebuild_3_4_1.py" "$ROOT"; then
    echo "ملاحظة: الحزمة تبدو مطبقة مسبقاً."
  else
    echo "RED CONFIRMED: المتطلبات الجديدة غير موجودة بالكامل قبل التطبيق."
  fi

  echo
  echo "=== تطبيق التعديلات ==="
  python3 "$SELF_DIR/apply_patch.py" "$ROOT"

  echo
  echo "=== GREEN — Professional Contract ==="
  python3 "$ROOT/scripts/validate_professional_rebuild_3_4_1.py" "$ROOT"

  echo
  echo "=== اختبارات المصدر الحالية ==="
  python3 scripts/validate_source.py
  python3 scripts/validate_integrated_extractor.py

  echo
  echo "=== فحص Git ==="
  git diff --check

  echo
  echo "=== Android Unit Tests + Lint + APK Build ==="
  chmod +x gradlew
  set +e
  ./gradlew --no-daemon --stacktrace testDebugUnitTest lintDebug assembleDebug 2>&1 | tee /tmp/althmany-gradle-341.log
  GRADLE_CODE=${PIPESTATUS[0]}
  set -e

  if [ "$GRADLE_CODE" -ne 0 ]; then
    if grep -Eqi "UnknownHostException|Could not resolve host|services\.gradle\.org|Temporary failure in name resolution|Could not resolve .* from" /tmp/althmany-gradle-341.log; then
      echo
      echo "LOCAL GRADLE: NETWORK BLOCKED"
      echo "سيتم الرفع إلى الفرع لكي يقوم GitHub Actions بالبناء في بيئة CI."
    else
      echo
      echo "LOCAL GRADLE: FAILED"
      echo "لن يتم عمل commit أو push لأن هناك خطأ بناء/اختبار حقيقي."
      false
    fi
  else
    echo "LOCAL GRADLE: PASS"
  fi

  echo
  echo "=== إضافة الملفات للـcommit ==="
  git add     app/src/main/java/com/althmany/extractor/MainActivity.kt     app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt     app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt     app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt     app/src/main/java/com/althmany/extractor/ui/LinkPreviewPolicy.kt     app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt     app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt     app/src/test/java/com/althmany/extractor/ui/LinkPreviewPolicyTest.kt     scripts/validate_professional_rebuild_3_4_1.py     docs/superpowers/specs/2026-09-16-rtl-join-scan-diagnostics-design.md     docs/superpowers/plans/2026-09-16-rtl-join-scan-diagnostics.md

  if git diff --cached --quiet; then
    echo "لا توجد تغييرات جديدة لعمل commit."
  else
    git commit -m "feat: rebuild RTL join scan and runtime diagnostics"
  fi

  echo
  echo "=== Push ==="
  git push origin feat/full-features-3.4.1

  echo
  echo "============================================================"
  echo "SOURCE REBUILD: PASS"
  echo "Branch: $(git branch --show-current)"
  echo "Commit: $(git rev-parse --short HEAD)"
  echo "GitHub Actions سيقوم أيضاً بفحص unit tests + lint + assembleDebug."
  echo "============================================================"
)

CODE=$?

echo
if [ "$CODE" -eq 0 ]; then
  echo ">>> FINISHED — TERMINAL REMAINS OPEN <<<"
else
  echo ">>> STOPPED WITH CODE $CODE — TERMINAL REMAINS OPEN <<<"
fi
