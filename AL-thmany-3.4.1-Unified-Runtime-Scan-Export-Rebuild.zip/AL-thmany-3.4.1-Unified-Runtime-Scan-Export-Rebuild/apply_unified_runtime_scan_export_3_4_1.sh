#!/usr/bin/env bash
# AL-thmany 3.4.1 unified runtime / scan / export rebuild.
# Run with: bash apply_unified_runtime_scan_export_3_4_1.sh
# The script works inside a subshell so the parent Codespaces terminal remains open.

set -u

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

(
  set -e

  ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
  if [ -z "$ROOT" ]; then
    echo "ERROR: شغّل الحزمة من داخل مستودع Bb في Codespaces."
    false
  fi

  cd "$ROOT"

  echo "============================================================"
  echo "AL-thmany 3.4.1 — Unified Runtime / Scan / Export Rebuild"
  echo "============================================================"
  echo "Repo: $ROOT"
  echo "Branch before: $(git branch --show-current)"
  echo "Commit before: $(git rev-parse --short HEAD)"

  if [ "$(git branch --show-current)" != "feat/full-features-3.4.1" ]; then
    echo
    echo "=== فتح فرع التطوير ==="
    git checkout feat/full-features-3.4.1
  fi

  echo
  echo "=== مزامنة الفرع ==="
  git fetch origin feat/full-features-3.4.1
  git pull --ff-only origin feat/full-features-3.4.1

  echo
  echo "=== Base compatibility ==="
  REQUIRED_BASE="766c7d8f0572e43da5b8994040aee8c84c1c3365"
  if ! git merge-base --is-ancestor "$REQUIRED_BASE" HEAD; then
    echo "ERROR: الفرع أقدم من قاعدة الحزمة المطلوبة: $REQUIRED_BASE"
    echo "HEAD الحالي: $(git rev-parse HEAD)"
    false
  fi
  echo "BASE_COMPATIBLE: $(git rev-parse --short HEAD) includes ${REQUIRED_BASE:0:8}"

  echo
  echo "=== RED — contract before patch ==="
  if python3 "$SELF_DIR/patch/scripts/validate_unified_runtime_v341.py" "$ROOT"; then
    echo "ملاحظة: يبدو أن Unified Runtime مطبق مسبقاً."
  else
    echo "RED CONFIRMED: المعمارية الجديدة غير مكتملة قبل تطبيق الحزمة."
  fi

  echo
  echo "=== تطبيق Unified Runtime patch ==="
  python3 "$SELF_DIR/apply_patch.py" "$ROOT"

  echo
  echo "=== GREEN — Unified Runtime contract ==="
  python3 scripts/validate_unified_runtime_v341.py "$ROOT"

  echo
  echo "=== Existing source contracts ==="
  python3 scripts/validate_professional_rebuild_3_4_1.py "$ROOT"
  python3 scripts/validate_source.py
  python3 scripts/validate_integrated_extractor.py

  echo
  echo "=== Git integrity ==="
  git diff --check

  echo
  echo "=== Local Android build gate ==="
  GRADLE_BIN="/usr/local/sdkman/candidates/gradle/8.13/bin/gradle"
  SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
  JAVA_VERSION="$(java -version 2>&1 | head -n1 || true)"

  if [ -x "$GRADLE_BIN" ] && \
     echo "$JAVA_VERSION" | grep -q '"17' && \
     [ -n "$SDK_ROOT" ] && \
     [ -f "$SDK_ROOT/platforms/android-36/android.jar" ]; then

    echo "LOCAL_ANDROID_ENVIRONMENT: READY"
    "$GRADLE_BIN" \
      --no-daemon \
      --no-configuration-cache \
      --console=plain \
      testDebugUnitTest \
      lintDebug \
      assembleDebug

    APK="app/build/outputs/apk/debug/app-debug.apk"
    test -s "$APK"
    echo "LOCAL_ANDROID_BUILD: PASS"
    ls -lh "$APK"
    sha256sum "$APK"
  else
    echo "LOCAL_ANDROID_BUILD: DEFERRED_TO_GITHUB_ACTIONS"
    echo "Codespaces لا يملك بيئة Android 36/JDK17/Gradle8.13 كاملة؛ لن نعيد تثبيتها محلياً."
  fi

  echo
  echo "=== Stage exact implementation files ==="
  git add \
    app/src/main/java/com/althmany/extractor/profile/UnifiedRuntimeTarget.kt \
    app/src/main/java/com/althmany/extractor/profile/NativeProfileEngineRouter.kt \
    app/src/main/java/com/althmany/extractor/profile/EnvironmentDatabasePolicy.kt \
    app/src/main/java/com/althmany/extractor/ExtractorApp.kt \
    app/src/main/java/com/althmany/extractor/data/ExtractorDatabase.kt \
    app/src/main/java/com/althmany/extractor/shizuku/ShizukuBridge.kt \
    app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt \
    app/src/main/java/com/althmany/extractor/engine/ScanController.kt \
    app/src/main/java/com/althmany/extractor/engine/PublishController.kt \
    app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt \
    app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt \
    app/src/main/java/com/althmany/extractor/export/ExportManager.kt \
    app/src/main/java/com/althmany/extractor/export/MemberCountParser.kt \
    app/src/main/java/com/althmany/extractor/export/StructuredScanExporter.kt \
    app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt \
    app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt \
    app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt \
    app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt \
    app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt \
    app/src/main/java/com/althmany/extractor/MainActivity.kt \
    app/src/test/java/com/althmany/extractor/export/MemberCountParserTest.kt \
    app/src/test/java/com/althmany/extractor/profile/EnvironmentDatabasePolicyTest.kt \
    scripts/validate_unified_runtime_v341.py \
    docs/superpowers/specs/2026-09-16-unified-runtime-scan-export-redesign.md \
    docs/superpowers/plans/2026-09-16-unified-runtime-scan-export-implementation.md

  echo
  echo "=== Staged files ==="
  git diff --cached --name-only

  echo
  echo "=== Commit + Push ==="
  if git diff --cached --quiet; then
    echo "NO_NEW_COMMIT_NEEDED"
  else
    git commit -m "feat: unify runtime targets scan and exports"
  fi

  git push origin feat/full-features-3.4.1

  echo
  echo "=== GitHub Actions gate ==="
  CI_STATE="PENDING"
  if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
    HEAD_SHA="$(git rev-parse HEAD)"
    RUN_ID=""
    for _ in $(seq 1 18); do
      RUN_ID="$(
        gh run list \
          --workflow android-ci.yml \
          --branch feat/full-features-3.4.1 \
          --limit 10 \
          --json databaseId,headSha,status,conclusion \
          --jq ".[] | select(.headSha == \"$HEAD_SHA\") | .databaseId" \
          2>/dev/null | head -n1
      )"
      [ -n "$RUN_ID" ] && break
      sleep 5
    done

    if [ -n "$RUN_ID" ]; then
      echo "CI_RUN_ID=$RUN_ID"
      if gh run watch "$RUN_ID" --exit-status; then
        CI_STATE="PASS"
        ART_DIR="$ROOT/artifacts/3.4.1-unified-runtime"
        rm -rf "$ART_DIR"
        mkdir -p "$ART_DIR"
        if gh run download "$RUN_ID" -n al-thmany-debug-apk -D "$ART_DIR"; then
          echo "CI_ARTIFACT_DOWNLOADED=$ART_DIR"
          find "$ART_DIR" -maxdepth 2 -type f -print
        else
          echo "CI_ARTIFACT_DOWNLOAD_SKIPPED"
        fi
      else
        CI_STATE="FAIL"
      fi
    else
      echo "CI_RUN_NOT_VISIBLE_YET"
    fi
  else
    echo "GH_CLI_NOT_AUTHENTICATED: افتح GitHub Actions للتحقق من البناء."
  fi

  echo
  echo "============================================================"
  echo "UNIFIED_RUNTIME_PUSH_SUCCESS"
  echo "Branch: $(git branch --show-current)"
  echo "Commit: $(git rev-parse --short HEAD)"
  echo "CI_STATE=$CI_STATE"
  if [ "$CI_STATE" = "PASS" ]; then
    echo "ANDROID_BUILD_GATE=PASS"
  elif [ "$CI_STATE" = "FAIL" ]; then
    echo "ANDROID_BUILD_GATE=FAIL"
    echo "لا تعتبر النسخة جاهزة للتثبيت قبل إصلاح فشل GitHub Actions."
    false
  else
    echo "ANDROID_BUILD_GATE=PENDING"
    echo "GitHub Actions هو بوابة البناء الرسمية."
  fi
  echo "============================================================"
)

CODE=$?

echo
if [ "$CODE" -eq 0 ]; then
  echo ">>> FINISHED — TERMINAL REMAINS OPEN <<<"
else
  echo ">>> STOPPED WITH CODE $CODE — TERMINAL REMAINS OPEN <<<"
fi
