# AL-thmany 3.4.1 — Unified Runtime / Scan / Export Rebuild

**قاعدة الفرع المتوافقة:** `feat/full-features-3.4.1` عند أو بعد commit `766c7d8f0572e43da5b8994040aee8c84c1c3365`.

هذه الحزمة تنفذ التصميم المعتمد على الفرع:
`feat/full-features-3.4.1`

## أهم ما تنفذه

- بيئة تشغيل موحدة لكل الخصائص:
  - Join
  - Scan
  - Extraction
  - Publish
  - Group Sync
- هدف واحد: Android environment + WhatsApp + Backend.
- Backend موحد: AUTO / Accessibility / Shizuku.
- عزل بيانات البيئات:
  - البيئة المحلية تحتفظ بقاعدة `althmany_extractor.db` الحالية.
  - كل Android user بعيد عبر Shizuku يحصل على قاعدة مستقلة مثل `althmany_extractor_remote_u10.db`.
  - عند تبديل البيئة تتبدل القروبات والنتائج وScan وPublish مع قاعدة تلك البيئة، بدون خلط مع البيئة الشخصية.
- اكتشاف Dual Messenger / Work Profile / Secure Folder عبر Shizuku داخل التطبيق الجديد.
- دعم التشغيل المحلي عند تثبيت AL-thmany داخل Work Profile أو Secure Folder.
- إزالة زر إدارة البيئات الذي كان يفتح واجهة Sender القديمة.
- إصلاح Join بعد الضغط: `MULTIPLE_POSITIVE_ACTIONS` بعد الضغط يصبح مرحلة تحقق وليس فشل `ACTION_TIMEOUT` فوري.
- Scan مجبر على `SCAN_ONLY` من داخل المحرك نفسه.
- شاشة Scan تعرض حالتها ورسالة المحرك والثقة.
- Member-count parser عربي/إنجليزي.
- ترتيب نتائج الفحص: أكبر عدد أعضاء → أصغر، والعدد غير المعروف في النهاية.
- TXT مجمع حسب التصنيف.
- XLSX:
  - All Results
  - Direct Join
  - Approval Required
  - Request Pending
  - Already Member
  - Joined
  - Invalid
  - Full
  - Removed
  - Account Limit
  - Network Error
  - Action Uncertain
  - Unknown
  - وغيرها عند وجود نتائج.
- التحكم الكامل في بيئة التشغيل موجود في الرئيسية فقط؛ بقية الشاشات تعرض حالة مختصرة بدون تكرار الخيارات.
- بطاقات RTL موحدة 16dp / 20dp / 12dp.
- Diagnostics تقرأ نفس Unified Runtime الذي تستخدمه المحركات.

## الاستخدام

ارفع ZIP إلى جذر المستودع في Codespaces، ثم نفذ:

```bash
cd /workspaces/Bb && \
rm -rf AL-thmany-3.4.1-Unified-Runtime-Scan-Export-Rebuild && \
unzip -q AL-thmany-3.4.1-Unified-Runtime-Scan-Export-Rebuild.zip -d . && \
bash AL-thmany-3.4.1-Unified-Runtime-Scan-Export-Rebuild/apply_unified_runtime_scan_export_3_4_1.sh
```

## المتوقع

قبل التطبيق:

```text
UNIFIED RUNTIME 3.4.1 CONTRACT: FAIL
RED CONFIRMED
```

بعد التطبيق:

```text
UNIFIED RUNTIME 3.4.1 CONTRACT: PASS
```

ثم عقود المصدر القديمة يجب أن تبقى PASS.

إذا كانت بيئة Codespaces ناقصة Android SDK، سيظهر:

```text
LOCAL_ANDROID_BUILD: DEFERRED_TO_GITHUB_ACTIONS
```

وهذا متوقع؛ GitHub Actions هو بوابة البناء الرسمية.

بعد الـpush سيحاول السكربت انتظار GitHub Actions تلقائياً إذا كان `gh` مسجّل الدخول.

عند نجاح البناء سيظهر:

```text
CI_STATE=PASS
ANDROID_BUILD_GATE=PASS
UNIFIED_RUNTIME_PUSH_SUCCESS
>>> FINISHED — TERMINAL REMAINS OPEN <<<
```

وسيحاول تنزيل Artifact إلى:

```text
artifacts/3.4.1-unified-runtime/
```

إذا لم يكن `gh` متاحاً أو لم يظهر الـRun بعد، سيظهر:

```text
CI_STATE=PENDING
ANDROID_BUILD_GATE=PENDING
```

وفي هذه الحالة لا تعتبر النسخة نهائية حتى ينجح GitHub Actions في:
`testDebugUnitTest + lintDebug + assembleDebug`.
