#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import re
import shutil
import sys

BUNDLE = Path(__file__).resolve().parent
PATCH = BUNDLE / "patch"
ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()

def fail(message: str):
    raise SystemExit(f"PATCH ERROR: {message}")

def repo(rel: str) -> Path:
    return ROOT / rel

def read(rel: str) -> str:
    p = repo(rel)
    if not p.exists():
        fail(f"missing repository file: {rel}")
    return p.read_text(encoding="utf-8")

def write(rel: str, value: str):
    p = repo(rel)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(value, encoding="utf-8")

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if old in text:
        return text.replace(old, new, 1)
    if new in text:
        return text
    fail(f"anchor not found: {label}")

def regex_once(text: str, pattern: str, replacement: str, label: str) -> str:
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count == 1:
        return updated
    fail(f"regex anchor not found: {label}")

required = [
    "app/src/main/java/com/althmany/extractor/MainActivity.kt",
    "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt",
    "app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt",
    "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt",
    "app/src/main/java/com/althmany/extractor/engine/ScanController.kt",
    "app/src/main/java/com/althmany/extractor/engine/PublishController.kt",
    "app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt",
    "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt",
    "app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt",
    "app/src/main/java/com/althmany/extractor/export/ExportManager.kt",
    "app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt",
    "app/src/main/java/com/althmany/extractor/shizuku/ShizukuBridge.kt",
    "app/src/main/java/com/althmany/extractor/profile/NativeProfileEngineRouter.kt",
    "app/src/main/java/com/althmany/extractor/ExtractorApp.kt",
    "app/src/main/java/com/althmany/extractor/data/ExtractorDatabase.kt",
]
for rel in required:
    if not repo(rel).exists():
        fail(f"required base file not found: {rel}")

backup = ROOT / ".althmany_backups" / datetime.now().strftime("%Y%m%d-%H%M%S-unified-runtime")
for rel in required:
    src = repo(rel)
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

overlay = [
    "app/src/main/java/com/althmany/extractor/profile/UnifiedRuntimeTarget.kt",
    "app/src/main/java/com/althmany/extractor/profile/NativeProfileEngineRouter.kt",
    "app/src/main/java/com/althmany/extractor/profile/EnvironmentDatabasePolicy.kt",
    "app/src/main/java/com/althmany/extractor/ExtractorApp.kt",
    "app/src/main/java/com/althmany/extractor/export/MemberCountParser.kt",
    "app/src/main/java/com/althmany/extractor/export/StructuredScanExporter.kt",
    "app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt",
    "app/src/test/java/com/althmany/extractor/export/MemberCountParserTest.kt",
    "app/src/test/java/com/althmany/extractor/profile/EnvironmentDatabasePolicyTest.kt",
    "scripts/validate_unified_runtime_v341.py",
]
for rel in overlay:
    src = PATCH / rel
    if not src.exists():
        fail(f"bundle overlay missing: {rel}")
    write(rel, src.read_text(encoding="utf-8"))

# ---------------------------------------------------------------------------
# ExportManager
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/export/ExportManager.kt"
s = read(rel)
old = '''    fun exportScan(resolver: ContentResolver, uri: Uri, format: ExportFormat, items: List<ScanRecord>) {
        when (format) {
            ExportFormat.CSV -> exportScanCsv(resolver, uri, items)
            ExportFormat.TXT -> exportScanTxt(resolver, uri, items)
            ExportFormat.JSON -> exportScanJson(resolver, uri, items)
            ExportFormat.XLSX -> exportScanXlsx(resolver, uri, items)
        }
    }
'''
new = '''    fun exportScan(resolver: ContentResolver, uri: Uri, format: ExportFormat, items: List<ScanRecord>) {
        StructuredScanExporter.export(resolver, uri, format, items)
    }
'''
s = replace_once(s, old, new, "ExportManager structured scan routing")
write(rel, s)

# ---------------------------------------------------------------------------
# AppViewModel
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt"
s = read(rel)

if "import com.althmany.extractor.profile.RuntimeBackendPreference" not in s:
    s = replace_once(
        s,
        "import com.althmany.groupmanager.util.WhatsAppLauncher\n",
        "import com.althmany.groupmanager.util.WhatsAppLauncher\n"
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeSnapshot\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n",
        "AppViewModel unified runtime imports"
    )

anchor = '''    val publishState: StateFlow<PublishUiState> = PublishController.state
'''
insert = '''    val publishState: StateFlow<PublishUiState> = PublishController.state

    private val _runtimeTarget = MutableStateFlow(
        UnifiedRuntimeTargetStore.resolve(
            application,
            ExtractionController.state.value.selectedWhatsAppPackage
        )
    )
    val runtimeTarget: StateFlow<UnifiedRuntimeSnapshot> = _runtimeTarget.asStateFlow()
'''
s = replace_once(s, anchor, insert, "AppViewModel runtime target state")

init_anchor = '''    init {
        refresh()
'''
init_replacement = '''    init {
        viewModelScope.launch {
            engineState.collect { state ->
                _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(
                    getApplication<Application>(),
                    state.selectedWhatsAppPackage
                )
            }
        }
        refresh()
'''
s = replace_once(s, init_anchor, init_replacement, "AppViewModel runtime target collector")

old_target = '''    fun setTargetWhatsApp(packageName: String) {
        val activeSender = (getApplication<Application>() as? GroupManagerApp)
            ?.preferences?.accessibilityBatchRunning == true
        if (activeSender) {
            _message.value = "أوقف الانضمام الحالي قبل تغيير نسخة واتساب"
            return
        }
        ExtractionController.setTargetWhatsAppPackage(packageName)
        val senderApp = getApplication<Application>() as? GroupManagerApp ?: return
        val discovered = WhatsAppLauncher.discoverWhatsAppApps(senderApp)
            .firstOrNull { it.packageName == packageName }
        senderApp.preferences.clearRemoteSecureTarget()
        senderApp.preferences.selectedWhatsAppPackage = packageName
        senderApp.preferences.selectedWhatsAppLabel = discovered?.label ?: packageName
        senderApp.preferences.preferredTarget = PreferredTarget.AUTO
    }
    fun refreshRuntimeEnvironment() = ExtractionController.refreshRuntimeEnvironment()
'''
new_target = '''    fun setTargetWhatsApp(packageName: String) {
        ExtractionController.setTargetWhatsAppPackage(packageName)
        UnifiedRuntimeTargetStore.setSelectedPackage(getApplication<Application>(), packageName)
        val senderApp = getApplication<Application>() as? GroupManagerApp
        if (senderApp != null) {
            val discovered = WhatsAppLauncher.discoverWhatsAppApps(senderApp)
                .firstOrNull { it.packageName == packageName }
            senderApp.preferences.clearRemoteSecureTarget()
            senderApp.preferences.selectedWhatsAppPackage = packageName
            senderApp.preferences.selectedWhatsAppLabel = discovered?.label ?: packageName
            senderApp.preferences.preferredTarget = PreferredTarget.AUTO
        }
        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(getApplication<Application>(), packageName)
    }

    fun setRuntimeBackendPreference(value: RuntimeBackendPreference) {
        if (ExtractionController.isBusy() || ScanController.isRunning() || PublishController.isRunning()) {
            _message.value = "أوقف العملية الحالية قبل تغيير محرك التشغيل"
            return
        }
        val senderApp = getApplication<Application>() as? GroupManagerApp
        if (senderApp?.preferences?.accessibilityBatchRunning == true) {
            _message.value = "أوقف الانضمام الحالي قبل تغيير محرك التشغيل"
            return
        }
        if (_runtimeTarget.value.remoteTarget && value == RuntimeBackendPreference.ACCESSIBILITY) {
            _message.value = "الهدف في Android user آخر يحتاج Shizuku؛ Accessibility تعمل داخل الملف المحلي فقط"
            return
        }
        UnifiedRuntimeTargetStore.setPreference(getApplication<Application>(), value)
        (getApplication<Application>() as? GroupManagerApp)?.preferences?.let { prefs ->
            prefs.automationBackend = when (value) {
                RuntimeBackendPreference.AUTO -> AutomationBackend.AUTO
                RuntimeBackendPreference.ACCESSIBILITY -> AutomationBackend.ACCESSIBILITY
                RuntimeBackendPreference.SHIZUKU -> AutomationBackend.SHIZUKU
            }
        }
        ExtractionController.refreshRuntimeEnvironment()
        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(
            getApplication<Application>(),
            engineState.value.selectedWhatsAppPackage
        )
        _message.value = "تم اختيار محرك التشغيل: ${value.labelAr}"
    }

    fun refreshRuntimeEnvironment() {
        ExtractionController.refreshRuntimeEnvironment()
        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(
            getApplication<Application>(),
            engineState.value.selectedWhatsAppPackage
        )
    }
'''
s = replace_once(s, old_target, new_target, "AppViewModel target/backend controls")
write(rel, s)

# ---------------------------------------------------------------------------
# MainActivity — wire canonical runtime snapshot into Home / Join / Scan.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = read(rel)

s = replace_once(
    s,
    "    val engine by viewModel.engineState.collectAsState()\n",
    "    val engine by viewModel.engineState.collectAsState()\n"
    "    val runtimeTarget by viewModel.runtimeTarget.collectAsState()\n",
    "MainActivity runtime target collect"
)

old_home = '''                AppScreen.HOME -> V341HomeScreen(
                    padding = zero,
                    engine = engine,
                    scan = scanState,
                    publish = publishState,
'''
new_home = '''                AppScreen.HOME -> V341HomeScreen(
                    padding = zero,
                    engine = engine,
                    runtime = runtimeTarget,
                    scan = scanState,
                    publish = publishState,
'''
s = replace_once(s, old_home, new_home, "MainActivity home runtime")

s = replace_once(
    s,
    '''                    onAutoJoin = { screen = AppScreen.JOIN },
                    onStart = viewModel::startExtractionSmart,
''',
    '''                    onAutoJoin = { screen = AppScreen.JOIN },
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onBackendPreference = viewModel::setRuntimeBackendPreference,
                    onStart = viewModel::startExtractionSmart,
''',
    "MainActivity home runtime callbacks"
)

s = replace_once(
    s,
    '''                AppScreen.JOIN -> ProfessionalJoinScreen(
                    padding = zero,
                    engine = engine,
                    join = joinState,
''',
    '''                AppScreen.JOIN -> ProfessionalJoinScreen(
                    padding = zero,
                    engine = engine,
                    runtime = runtimeTarget,
                    join = joinState,
''',
    "MainActivity join runtime"
)

s = replace_once(
    s,
    '''                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onDraft = joinCoordinator::setDraft,
''',
    '''                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onBackendPreference = viewModel::setRuntimeBackendPreference,
                    onDraft = joinCoordinator::setDraft,
''',
    "MainActivity join backend callback"
)

s = replace_once(
    s,
    '''                    onResume = joinCoordinator::resume,
                    onStop = joinCoordinator::stop,
                    onAdvancedTargets = joinCoordinator::openAdvancedTargetManager
''',
    '''                    onResume = joinCoordinator::resume,
                    onStop = joinCoordinator::stop
''',
    "MainActivity remove legacy advanced target UI"
)

s = replace_once(
    s,
    '''                AppScreen.SCAN -> ProfessionalScanScreen(
                    padding = zero,
                    engine = engine,
                    scan = scanState,
''',
    '''                AppScreen.SCAN -> ProfessionalScanScreen(
                    padding = zero,
                    engine = engine,
                    runtime = runtimeTarget,
                    scan = scanState,
''',
    "MainActivity scan runtime"
)

scan_anchor = '''                    scanItems = scanItems,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onAddLinks = viewModel::addScanLinks,
'''
scan_new = '''                    scanItems = scanItems,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onBackendPreference = viewModel::setRuntimeBackendPreference,
                    onAddLinks = viewModel::addScanLinks,
'''
s = replace_once(s, scan_anchor, scan_new, "MainActivity scan backend callback")
write(rel, s)

# ---------------------------------------------------------------------------
# WorkspaceV341Screens — consistent card grid and unified runtime on Home.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"
s = read(rel)

if "import com.althmany.extractor.profile.UnifiedRuntimeSnapshot" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.export.ExportFormat\n",
        "import com.althmany.extractor.export.ExportFormat\n"
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeSnapshot\n",
        "Workspace runtime imports"
    )

s = s.replace("shape = RoundedCornerShape(18.dp)", "shape = RoundedCornerShape(20.dp)")
s = s.replace("Column(Modifier.padding(14.dp), content = content)", "Column(Modifier.padding(16.dp), content = content)")
s = s.replace(
    "contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)",
    "contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)"
)
s = s.replace(
    "verticalArrangement = Arrangement.spacedBy(9.dp)",
    "verticalArrangement = Arrangement.spacedBy(12.dp)"
)
s = s.replace(
    "modifier.height(126.dp).clickable(onClick = onClick)",
    "modifier.height(112.dp).clickable(onClick = onClick)"
)
s = s.replace("\n        VConnection(engine)\n", "\n")

old_sig = '''fun V341HomeScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    scan: ScanUiState,
    publish: PublishUiState,
    onExtract: () -> Unit,
    onScan: () -> Unit,
    onPublish: () -> Unit,
    onAutoJoin: () -> Unit,
    onStart: () -> Unit,
'''
new_sig = '''fun V341HomeScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    runtime: UnifiedRuntimeSnapshot,
    scan: ScanUiState,
    publish: PublishUiState,
    onExtract: () -> Unit,
    onScan: () -> Unit,
    onPublish: () -> Unit,
    onAutoJoin: () -> Unit,
    onTargetWhatsApp: (String) -> Unit,
    onBackendPreference: (RuntimeBackendPreference) -> Unit,
    onStart: () -> Unit,
'''
s = replace_once(s, old_sig, new_sig, "V341HomeScreen unified runtime signature")

s = replace_once(
    s,
    '''        item { VHeader("مرحباً بك", "كل ما تحتاجه لإدارة مجموعاتك في مكان واحد", engine, Icons.Default.Home) }
        item {
            Row''',
    '''        item { VHeader("مرحباً بك", "كل ما تحتاجه لإدارة مجموعاتك في مكان واحد", engine, Icons.Default.Home) }
        item {
            UnifiedRuntimeCard(
                engine = engine,
                runtime = runtime,
                onTargetWhatsApp = onTargetWhatsApp,
                onBackendPreference = onBackendPreference
            )
        }
        item {
            Row''',
    "V341HomeScreen runtime card"
)
write(rel, s)

# ---------------------------------------------------------------------------
# Professional Join / Scan UI.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt"
s = read(rel)

if "import com.althmany.extractor.profile.RuntimeBackendPreference" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.join.OriginalJoinUiState\n",
        "import com.althmany.extractor.join.OriginalJoinUiState\n"
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeSnapshot\n",
        "Professional screens runtime imports"
    )

s = s.replace("Column(Modifier.padding(14.dp), content = content)", "Column(Modifier.padding(16.dp), content = content)")
s = s.replace(
    "contentPadding = PaddingValues(horizontal = side, vertical = 10.dp)",
    "contentPadding = PaddingValues(horizontal = side, vertical = 12.dp)"
)
s = s.replace(
    "verticalArrangement = Arrangement.spacedBy(10.dp)",
    "verticalArrangement = Arrangement.spacedBy(12.dp)"
)
s = s.replace(
    "val side = if (maxWidth >= 600.dp) 28.dp else 14.dp",
    "val side = if (maxWidth >= 600.dp) 28.dp else 16.dp"
)

join_sig_old = '''fun ProfessionalJoinScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    join: OriginalJoinUiState,
    onTargetWhatsApp: (String) -> Unit,
    onDraft: (String) -> Unit,
'''
join_sig_new = '''fun ProfessionalJoinScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    runtime: UnifiedRuntimeSnapshot,
    join: OriginalJoinUiState,
    onTargetWhatsApp: (String) -> Unit,
    onBackendPreference: (RuntimeBackendPreference) -> Unit,
    onDraft: (String) -> Unit,
'''
s = replace_once(s, join_sig_old, join_sig_new, "ProfessionalJoinScreen signature")

s = replace_once(
    s,
    '''    onResume: () -> Unit,
    onStop: () -> Unit,
    onAdvancedTargets: () -> Unit
) {''',
    '''    onResume: () -> Unit,
    onStop: () -> Unit
) {''',
    "ProfessionalJoinScreen remove legacy manager callback"
)

s = replace_once(
    s,
    '''            item {
                PTargetSelector(
                    engine = engine,
                    onTargetWhatsApp = onTargetWhatsApp,
                    onAdvancedTargets = onAdvancedTargets
                )
            }
''',
    '''            item { UnifiedRuntimeStatusStrip(runtime) }
''',
    "ProfessionalJoinScreen unified runtime card"
)

scan_sig_old = '''fun ProfessionalScanScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    scan: ScanUiState,
    scanItems: List<ScanRecord>,
    onTargetWhatsApp: (String) -> Unit,
    onAddLinks: (String) -> Unit,
'''
scan_sig_new = '''fun ProfessionalScanScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    runtime: UnifiedRuntimeSnapshot,
    scan: ScanUiState,
    scanItems: List<ScanRecord>,
    onTargetWhatsApp: (String) -> Unit,
    onBackendPreference: (RuntimeBackendPreference) -> Unit,
    onAddLinks: (String) -> Unit,
'''
s = replace_once(s, scan_sig_old, scan_sig_new, "ProfessionalScanScreen signature")

s = replace_once(
    s,
    '''            item { PTargetSelector(engine, onTargetWhatsApp) }

            item {
                PCard(accent = PCyan.copy(alpha = .65f)) {''',
    '''            item { UnifiedRuntimeStatusStrip(runtime) }

            item {
                PCard(accent = PCyan.copy(alpha = .65f)) {''',
    "ProfessionalScanScreen unified runtime card"
)

status_anchor = '''            item {
                PSectionTitle("تصنيف الروابط", Icons.Default.BarChart)
'''
status_block = '''            item {
                PCard(accent = if (scan.running) PGreen.copy(alpha = .65f) else PLine) {
                    PSectionTitle("حالة الفحص", Icons.Default.Bolt, if (scan.running) PGreen else PCyan)
                    Spacer(Modifier.height(7.dp))
                    Text(
                        "${scan.status.name} • ${scan.currentIndex}/${scan.total} • ثقة ${scan.currentConfidence}%",
                        color = PMuted,
                        fontSize = 10.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        scan.message,
                        color = PText,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End
                    )
                }
            }

            item {
                PSectionTitle("تصنيف الروابط", Icons.Default.BarChart)
'''
s = replace_once(s, status_anchor, status_block, "ProfessionalScanScreen live status")
write(rel, s)

# ---------------------------------------------------------------------------
# ScanController — the selected backend is authoritative and Scan is always
# read-only even if stale preferences from older builds say otherwise.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/engine/ScanController.kt"
s = read(rel)

if "import com.althmany.extractor.profile.RuntimeBackendPreference" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.profile.WhatsAppInstanceRegistry\n",
        "import com.althmany.extractor.profile.WhatsAppInstanceRegistry\n"
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n",
        "ScanController unified runtime imports"
    )

new_scan_runtime = '''    private suspend fun ensureRuntimeReady(timeoutMs: Long = 8_500L): Boolean {
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage ?: run {
            _state.value = _state.value.copy(message = "RUNTIME_NO_TARGET: اختر نسخة واتساب أولاً")
            return false
        }
        val preference = UnifiedRuntimeTargetStore.preference(appContext)
        val sh = runCatching { ShizukuBridge.status() }.getOrNull()

        val opened = when (preference) {
            RuntimeBackendPreference.SHIZUKU -> {
                if (sh?.ready != true) {
                    _state.value = _state.value.copy(
                        message = "SHIZUKU_NOT_READY: المحرك محدد على Shizuku لكنه غير جاهز"
                    )
                    return false
                }
                ShizukuBridge.launchPackage(appContext, packageName)
            }
            RuntimeBackendPreference.ACCESSIBILITY -> ExtractionController.openWhatsApp()
            RuntimeBackendPreference.AUTO ->
                ExtractionController.openWhatsApp() ||
                    (sh?.ready == true && ShizukuBridge.launchPackage(appContext, packageName))
        }

        if (!opened) {
            _state.value = _state.value.copy(
                message = "RUNTIME_OPEN_FAILED: تعذر فتح نسخة واتساب المحددة"
            )
            return false
        }

        if (preference != RuntimeBackendPreference.SHIZUKU && !runtimeTarget.remoteTarget) {
            val accessDeadline = SystemClock.elapsedRealtime() + minOf(timeoutMs, 1_800L)
            while (SystemClock.elapsedRealtime() < accessDeadline) {
                val live = recoverLiveService()
                if (live != null && adapter.isWhatsAppRoot(live.currentRoot(), packageName)) {
                    shizukuMode = false
                    _state.value = _state.value.copy(
                        message = "READY_ACCESSIBILITY: الفحص يرى واتساب عبر Accessibility"
                    )
                    return true
                }
                withTimeoutOrNull(150L) { uiEvents.first() }
                delay(20L)
            }
            if (preference == RuntimeBackendPreference.ACCESSIBILITY) {
                shizukuMode = false
                _state.value = _state.value.copy(
                    message = "ACCESSIBILITY_ROOT_NOT_READY: Accessibility محددة لكن لا ترى واتساب المستهدف"
                )
                return false
            }
        }

        if (sh?.ready == true) {
            if (!ShizukuBridge.ensureBound(appContext, 4_500L)) {
                _state.value = _state.value.copy(
                    message = "SHIZUKU_BIND_FAILED: الإذن موجود لكن UserService لم يرتبط"
                )
                shizukuMode = false
                return false
            }

            ShizukuBridge.launchPackage(appContext, packageName)
            var lastDetail = "NO_SNAPSHOT"
            var resetTried = false
            val deadline = SystemClock.elapsedRealtime() + (timeoutMs - 1_800L).coerceAtLeast(5_000L)
            while (SystemClock.elapsedRealtime() < deadline) {
                val tree = shizukuUi.snapshot(packageName)
                lastDetail = "${tree.state}:${tree.detail.take(140)}"
                if (tree.state == "OK" && tree.nodes.isNotEmpty() && shizukuUi.isWhatsApp(tree, packageName)) {
                    shizukuMode = true
                    _state.value = _state.value.copy(
                        message = "READY_SHIZUKU: الفحص يرى واتساب عبر Shizuku (${tree.nodes.size} node)"
                    )
                    return true
                }
                if (!resetTried && tree.state in setOf("UNAVAILABLE", "ERROR", "NO_ROOT")) {
                    resetTried = true
                    ShizukuBridge.reset(appContext)
                    ShizukuBridge.launchPackage(appContext, packageName)
                }
                delay(110L)
            }
            _state.value = _state.value.copy(message = "SHIZUKU_UI_NOT_READY: $lastDetail")
        } else {
            _state.value = _state.value.copy(
                message = when {
                    sh == null || !sh.binderAlive -> "SHIZUKU_BINDER_OFF: شغّل Shizuku"
                    !sh.permissionGranted -> "SHIZUKU_PERMISSION_DENIED: امنح التطبيق إذن Shizuku"
                    else -> "RUNTIME_NO_BACKEND: لا يوجد محرك تحكم جاهز"
                }
            )
        }

        shizukuMode = false
        return false
    }

'''
s = regex_once(
    s,
    r"    private suspend fun ensureRuntimeReady\(timeoutMs: Long = 8_500L\): Boolean \{.*?\n    \}\n\n(?=    fun isRunning\(\): Boolean)",
    new_scan_runtime,
    "ScanController ensureRuntimeReady"
)

s = replace_once(
    s,
    '''    fun start() {
        if (job?.isActive == true) return
''',
    '''    fun start() {
        if (job?.isActive == true) return
        // Scan is permanently read-only in the unified 3.4.1 workspace. Older persisted
        // JOIN_ONLY / SCAN_AND_JOIN values must never leak into a Scan run.
        setActionMode(ScanActionMode.SCAN_ONLY)
        setRequestToJoinEnabled(false)
''',
    "ScanController force read-only start"
)
write(rel, s)

# ---------------------------------------------------------------------------
# PublishController — same backend preference as Join / Scan / Extraction.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/engine/PublishController.kt"
s = read(rel)

if "import com.althmany.extractor.profile.RuntimeBackendPreference" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.profile.ProfileLaunchPolicy\n",
        "import com.althmany.extractor.profile.ProfileLaunchPolicy\n"
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n",
        "PublishController unified runtime imports"
    )

new_publish_runtime = '''    private suspend fun ensureRuntimeReady(timeoutMs: Long = 8_500L): Boolean {
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage ?: run {
            _state.value = _state.value.copy(info = "RUNTIME_NO_TARGET: اختر نسخة واتساب أولاً")
            return false
        }
        val preference = UnifiedRuntimeTargetStore.preference(appContext)
        val sh = runCatching { ShizukuBridge.status() }.getOrNull()

        val opened = when (preference) {
            RuntimeBackendPreference.SHIZUKU -> {
                if (sh?.ready != true) {
                    _state.value = _state.value.copy(
                        info = "SHIZUKU_NOT_READY: المحرك محدد على Shizuku لكنه غير جاهز"
                    )
                    return false
                }
                ShizukuBridge.launchPackage(appContext, packageName)
            }
            RuntimeBackendPreference.ACCESSIBILITY -> ExtractionController.openWhatsApp()
            RuntimeBackendPreference.AUTO ->
                ExtractionController.openWhatsApp() ||
                    (sh?.ready == true && ShizukuBridge.launchPackage(appContext, packageName))
        }

        if (!opened) {
            _state.value = _state.value.copy(
                info = "RUNTIME_OPEN_FAILED: تعذر فتح نسخة واتساب المحددة"
            )
            return false
        }

        if (preference != RuntimeBackendPreference.SHIZUKU && !runtimeTarget.remoteTarget) {
            val accessDeadline = SystemClock.elapsedRealtime() + minOf(timeoutMs, 1_800L)
            while (SystemClock.elapsedRealtime() < accessDeadline) {
                val live = recoverLiveService()
                if (live != null && adapter.isWhatsAppRoot(live.currentRoot(), packageName)) {
                    shizukuMode = false
                    _state.value = _state.value.copy(
                        info = "READY_ACCESSIBILITY: النشر يرى واتساب عبر Accessibility"
                    )
                    return true
                }
                withTimeoutOrNull(150L) { uiEvents.first() }
                delay(20L)
            }
            if (preference == RuntimeBackendPreference.ACCESSIBILITY) {
                shizukuMode = false
                _state.value = _state.value.copy(
                    info = "ACCESSIBILITY_ROOT_NOT_READY: Accessibility محددة لكن لا ترى واتساب المستهدف"
                )
                return false
            }
        }

        if (sh?.ready == true) {
            if (!ShizukuBridge.ensureBound(appContext, 4_500L)) {
                _state.value = _state.value.copy(
                    info = "SHIZUKU_BIND_FAILED: الإذن موجود لكن UserService لم يرتبط"
                )
                shizukuMode = false
                return false
            }
            ShizukuBridge.launchPackage(appContext, packageName)
            var lastDetail = "NO_SNAPSHOT"
            var resetTried = false
            val deadline = SystemClock.elapsedRealtime() + (timeoutMs - 1_800L).coerceAtLeast(5_000L)
            while (SystemClock.elapsedRealtime() < deadline) {
                val tree = shizukuUi.snapshot(packageName)
                lastDetail = "${tree.state}:${tree.detail.take(140)}"
                if (tree.state == "OK" && tree.nodes.isNotEmpty() && shizukuUi.isWhatsApp(tree, packageName)) {
                    shizukuMode = true
                    _state.value = _state.value.copy(
                        info = "READY_SHIZUKU: النشر يرى واتساب عبر Shizuku (${tree.nodes.size} node)"
                    )
                    return true
                }
                if (!resetTried && tree.state in setOf("UNAVAILABLE", "ERROR", "NO_ROOT")) {
                    resetTried = true
                    ShizukuBridge.reset(appContext)
                    ShizukuBridge.launchPackage(appContext, packageName)
                }
                delay(110L)
            }
            _state.value = _state.value.copy(info = "SHIZUKU_UI_NOT_READY: $lastDetail")
        } else {
            _state.value = _state.value.copy(
                info = when {
                    sh == null || !sh.binderAlive -> "SHIZUKU_BINDER_OFF: شغّل Shizuku أو اختر Accessibility"
                    !sh.permissionGranted -> "SHIZUKU_PERMISSION_DENIED: امنح التطبيق إذن Shizuku"
                    else -> "RUNTIME_NO_BACKEND: لا يوجد محرك تحكم جاهز"
                }
            )
        }

        shizukuMode = false
        return false
    }

'''
s = regex_once(
    s,
    r"    private suspend fun ensureRuntimeReady\(timeoutMs: Long = 8_500L\): Boolean \{.*?\n    \}\n\n(?=    fun isRunning\(\): Boolean)",
    new_publish_runtime,
    "PublishController ensureRuntimeReady"
)
write(rel, s)

# ---------------------------------------------------------------------------
# ExtractionController — same target + backend preference for sync/extraction.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt"
s = read(rel)

if "import com.althmany.extractor.profile.RuntimeBackendPreference" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.profile.RuntimeBackendKind\n",
        "import com.althmany.extractor.profile.RuntimeBackendKind\n"
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n",
        "ExtractionController unified runtime imports"
    )

# Keep canonical package selection synchronized with the extraction settings store.
s = replace_once(
    s,
    '''        val selected = ProfileLaunchPolicy.resolveSelected(saved, available.map { it.packageName })
        if (selected != null && selected != saved) settingsStore.setTargetWhatsAppPackage(selected)
''',
    '''        val selected = ProfileLaunchPolicy.resolveSelected(saved, available.map { it.packageName })
        if (selected != null && selected != saved) settingsStore.setTargetWhatsAppPackage(selected)
        if (selected != null) UnifiedRuntimeTargetStore.setSelectedPackage(appContext, selected)
''',
    "ExtractionController selected package synchronization"
)

s = replace_once(
    s,
    '''        settingsStore.setTargetWhatsAppPackage(packageName)
        _state.value = _state.value.copy(
''',
    '''        settingsStore.setTargetWhatsAppPackage(packageName)
        UnifiedRuntimeTargetStore.setSelectedPackage(appContext, packageName)
        _state.value = _state.value.copy(
''',
    "ExtractionController target store"
)

# Group sync: explicit SHIZUKU goes directly through Shizuku. Explicit
# ACCESSIBILITY never silently falls back to Shizuku. AUTO keeps fallback.
old_sync_runtime = '''        if (!openWhatsApp()) throw IllegalStateException("تعذر فتح واتساب المحدد داخل البيئة الحالية")
        val svc = awaitRuntimeService(1_800L)
        if (svc == null) {
            if (ShizukuBridge.status().ready) {
                return syncGroupsViaShizuku(timing)
            }
            throw IllegalStateException("تم فتح واتساب لكن لا Accessibility محلية ولا Shizuku جاهز داخل نفس البيئة")
        }
        val syncPackage = requireSelectedPackage()
        if (!awaitWhatsAppRoot(svc, syncPackage, 5_000L)) {
            if (ShizukuBridge.status().ready) return syncGroupsViaShizuku(timing)
            throw IllegalStateException("Accessibility متصلة لكن rootInActiveWindow لم يرَ واتساب المحدد خلال مهلة التشغيل")
        }
'''
new_sync_runtime = '''        if (!openWhatsApp()) throw IllegalStateException("تعذر فتح واتساب المحدد داخل البيئة الحالية")
        val backendPreference = UnifiedRuntimeTargetStore.preference(appContext)
        val syncPackage = requireSelectedPackage()

        if (backendPreference == RuntimeBackendPreference.SHIZUKU) {
            if (!ShizukuBridge.status().ready) {
                throw IllegalStateException("Shizuku محدد كمحرك للمزامنة لكنه غير جاهز")
            }
            return syncGroupsViaShizuku(timing)
        }

        val svc = awaitRuntimeService(1_800L)
        if (svc == null) {
            if (backendPreference == RuntimeBackendPreference.AUTO && ShizukuBridge.status().ready) {
                return syncGroupsViaShizuku(timing)
            }
            throw IllegalStateException(
                if (backendPreference == RuntimeBackendPreference.ACCESSIBILITY)
                    "Accessibility محددة للمزامنة لكنها غير متصلة داخل هذه البيئة"
                else
                    "لا Accessibility محلية ولا Shizuku جاهز داخل نفس البيئة"
            )
        }
        if (!awaitWhatsAppRoot(svc, syncPackage, 5_000L)) {
            if (backendPreference == RuntimeBackendPreference.AUTO && ShizukuBridge.status().ready) {
                return syncGroupsViaShizuku(timing)
            }
            throw IllegalStateException("Accessibility متصلة لكن rootInActiveWindow لم يرَ واتساب المحدد خلال مهلة التشغيل")
        }
'''
s = replace_once(s, old_sync_runtime, new_sync_runtime, "ExtractionController sync backend policy")

old_run_runtime = '''            val liveAccessibility = awaitRuntimeService(1_500L)
            val accessibilityReady = liveAccessibility != null &&
                awaitWhatsAppRoot(liveAccessibility, targetPackage, 1_800L)

            if (!accessibilityReady) {
                if (ShizukuBridge.status().ready) {
                    _state.value = _state.value.copy(message = "Accessibility لا ترى واتساب — التحويل الفعلي إلى Shizuku")
                    runExtractionViaShizuku(groups, prefs, targetPackage)
                    return
                }
                failRun(
                    if (liveAccessibility == null)
                        "RUNTIME_NO_BACKEND: لا Accessibility محلية ولا Shizuku جاهز"
                    else
                        "ACCESSIBILITY_ROOT_NOT_READY: الخدمة متصلة لكن rootInActiveWindow لا يرى واتساب المحدد"
                )
                return
            }
'''
new_run_runtime = '''            val backendPreference = UnifiedRuntimeTargetStore.preference(appContext)

            if (backendPreference == RuntimeBackendPreference.SHIZUKU) {
                if (!ShizukuBridge.status().ready) {
                    failRun("SHIZUKU_NOT_READY: Shizuku محدد للاستخراج لكنه غير جاهز")
                    return
                }
                _state.value = _state.value.copy(message = "بدء الاستخراج عبر Shizuku حسب بيئة التشغيل الموحدة")
                runExtractionViaShizuku(groups, prefs, targetPackage)
                return
            }

            val liveAccessibility = awaitRuntimeService(1_500L)
            val accessibilityReady = liveAccessibility != null &&
                awaitWhatsAppRoot(liveAccessibility, targetPackage, 1_800L)

            if (!accessibilityReady) {
                if (backendPreference == RuntimeBackendPreference.AUTO && ShizukuBridge.status().ready) {
                    _state.value = _state.value.copy(
                        message = "AUTO: Accessibility لا ترى واتساب — التحويل إلى Shizuku"
                    )
                    runExtractionViaShizuku(groups, prefs, targetPackage)
                    return
                }
                failRun(
                    if (backendPreference == RuntimeBackendPreference.ACCESSIBILITY)
                        "ACCESSIBILITY_ROOT_NOT_READY: Accessibility محددة لكنها لا ترى واتساب المستهدف"
                    else if (liveAccessibility == null)
                        "RUNTIME_NO_BACKEND: لا Accessibility محلية ولا Shizuku جاهز"
                    else
                        "ACCESSIBILITY_ROOT_NOT_READY: الخدمة متصلة لكن rootInActiveWindow لا يرى واتساب المحدد"
                )
                return
            }
'''
s = replace_once(s, old_run_runtime, new_run_runtime, "ExtractionController extraction backend policy")
write(rel, s)

# ---------------------------------------------------------------------------
# OriginalJoinCoordinator — Join now honors the same backend selector used by
# the other engines. Remote legacy targets still require Shizuku by definition.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt"
s = read(rel)

if "import com.althmany.extractor.profile.RuntimeBackendPreference" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.engine.RuntimeOperationCoordinator\n",
        "import com.althmany.extractor.engine.RuntimeOperationCoordinator\n"
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n",
        "OriginalJoinCoordinator unified runtime imports"
    )

new_resolve_backend = '''    private fun resolveBackend(): AutomationBackend? {
        if (prefs.hasValidRemoteSecureTarget()) {
            if (runCatching { ShizukuBridge.status().ready }.getOrDefault(false)) {
                prefs.runtimeAutomationBackend = AutomationBackend.SHIZUKU
                prefs.accessibilityQuickJoin = false
                return AutomationBackend.SHIZUKU
            }
            setMessage("الهدف البعيد يحتاج Shizuku جاهزاً")
            return null
        }

        return when (UnifiedRuntimeTargetStore.preference(context)) {
            RuntimeBackendPreference.ACCESSIBILITY -> {
                if (!AccessibilityStatus.isQuickJoinServiceConnectedLocally(context)) {
                    setMessage("Accessibility محددة كمحرك لكنها غير متصلة داخل البيئة الحالية")
                    null
                } else {
                    prefs.runtimeAutomationBackend = AutomationBackend.ACCESSIBILITY
                    prefs.accessibilityQuickJoin = true
                    AutomationBackend.ACCESSIBILITY
                }
            }

            RuntimeBackendPreference.SHIZUKU -> {
                if (!runCatching { ShizukuBridge.status().ready }.getOrDefault(false)) {
                    setMessage("Shizuku محدد كمحرك لكنه غير جاهز/غير مصرح")
                    null
                } else {
                    prefs.runtimeAutomationBackend = AutomationBackend.SHIZUKU
                    prefs.accessibilityQuickJoin = false
                    AutomationBackend.SHIZUKU
                }
            }

            RuntimeBackendPreference.AUTO -> {
                val decision = NativeProfileEngineRouter.inspect(context, prefs.automationBackend).decision
                if (decision.runnable) {
                    val backend = decision.backend ?: return null
                    prefs.runtimeAutomationBackend = backend
                    prefs.accessibilityQuickJoin = backend == AutomationBackend.ACCESSIBILITY
                    backend
                } else {
                    when (decision.setupAction) {
                        NativeEngineSetupAction.ENABLE_LOCAL_ACCESSIBILITY -> {
                            setMessage("فعّل Accessibility الخاصة بالتطبيق ثم أعد المحاولة")
                            runCatching {
                                context.startActivity(
                                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        }
                        NativeEngineSetupAction.START_OR_AUTHORIZE_SHIZUKU ->
                            setMessage("شغّل Shizuku وامنح التطبيق الإذن ثم أعد المحاولة")
                        NativeEngineSetupAction.APPLY_WORK_ACCESSIBILITY_POLICY ->
                            setMessage("بيئة العمل تحتاج Accessibility محلية أو Shizuku جاهز")
                        NativeEngineSetupAction.BLOCKED_BY_PROFILE_POLICY ->
                            setMessage("سياسة Android Profile تمنع محرك التحكم")
                        NativeEngineSetupAction.NONE ->
                            setMessage("لا يوجد محرك تحكم جاهز")
                    }
                    null
                }
            }
        }
    }

'''
s = regex_once(
    s,
    r"    private fun resolveBackend\(\): AutomationBackend\? \{.*?\n    \}\n\n(?=    private fun validateAndLockTarget)",
    new_resolve_backend,
    "OriginalJoinCoordinator resolveBackend"
)
write(rel, s)

# ---------------------------------------------------------------------------
# QuickJoinAccessibilityService — after a JOIN/REQUEST click, a transient
# MULTIPLE_POSITIVE_ACTIONS frame is verification evidence, not a reason to
# immediately retry the same action and mark ACTION_TIMEOUT.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt"
s = read(rel)

conflict_anchor = '''                inspection?.action == action -> {
                    val retry = app.preferences.incrementAutomationRetry()
'''
conflict_replacement = '''                inspection?.evidenceConflict == ScreenEvidenceConflict.MULTIPLE_POSITIVE_ACTIONS -> {
                    app.preferences.transitionAutomation(
                        AutomationStage.VERIFYING_RESULT,
                        "Post-action WhatsApp controls are transitioning; holding instead of re-clicking",
                        resetRetries = false
                    )
                    runtimeDiagnostic(
                        current,
                        "POST_ACTION_CONFLICT_HOLD",
                        "action=${action.name}; conflict=${inspection.evidenceConflict.name}; waiting for stable success/pending evidence"
                    )
                    requestScan()
                }
                inspection?.action == action -> {
                    val retry = app.preferences.incrementAutomationRetry()
'''
s = replace_once(
    s,
    conflict_anchor,
    conflict_replacement,
    "QuickJoin post-action conflict hold"
)
write(rel, s)

# ---------------------------------------------------------------------------
# Complete runtime-card coverage: Extraction and Publish use the same target
# state as Home / Join / Scan.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = read(rel)

s = replace_once(
    s,
    '''                AppScreen.EXTRACT -> V341ExtractionScreen(
                    padding = zero,
                    engine = engine,
                    groups = groups,
''',
    '''                AppScreen.EXTRACT -> V341ExtractionScreen(
                    padding = zero,
                    engine = engine,
                    runtime = runtimeTarget,
                    groups = groups,
''',
    "MainActivity extraction runtime"
)

s = replace_once(
    s,
    '''                    accessibilityEnabled = isAccessibilityServiceEnabled(context),
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onMode = viewModel::setMode,
''',
    '''                    accessibilityEnabled = isAccessibilityServiceEnabled(context),
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onBackendPreference = viewModel::setRuntimeBackendPreference,
                    onMode = viewModel::setMode,
''',
    "MainActivity extraction backend callback"
)

s = replace_once(
    s,
    '''                AppScreen.PUBLISH -> V341PublishScreen(
                    padding = zero,
                    engine = engine,
                    publish = publishState,
''',
    '''                AppScreen.PUBLISH -> V341PublishScreen(
                    padding = zero,
                    engine = engine,
                    runtime = runtimeTarget,
                    publish = publishState,
''',
    "MainActivity publish runtime"
)

s = replace_once(
    s,
    '''                    groups = groups,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onGroups = { screen = AppScreen.GROUPS },
''',
    '''                    groups = groups,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onBackendPreference = viewModel::setRuntimeBackendPreference,
                    onGroups = { screen = AppScreen.GROUPS },
''',
    "MainActivity publish backend callback"
)
write(rel, s)

rel = "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"
s = read(rel)

extract_sig_old = '''fun V341ExtractionScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    groups: List<TargetGroup>,
    accessibilityEnabled: Boolean,
    onTargetWhatsApp: (String) -> Unit,
    onMode: (ExtractionMode) -> Unit,
'''
extract_sig_new = '''fun V341ExtractionScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    runtime: UnifiedRuntimeSnapshot,
    groups: List<TargetGroup>,
    accessibilityEnabled: Boolean,
    onTargetWhatsApp: (String) -> Unit,
    onBackendPreference: (RuntimeBackendPreference) -> Unit,
    onMode: (ExtractionMode) -> Unit,
'''
s = replace_once(s, extract_sig_old, extract_sig_new, "V341ExtractionScreen runtime signature")

s = replace_once(
    s,
    '''        item { VHeader("الاستخراج", "استخراج الروابط من القروبات والمحادثات", engine, Icons.Default.Link) }
        item {
            Row''',
    '''        item { VHeader("الاستخراج", "استخراج الروابط من القروبات والمحادثات", engine, Icons.Default.Link) }
        item { UnifiedRuntimeStatusStrip(runtime) }
        item {
            Row''',
    "V341ExtractionScreen runtime card"
)

publish_sig_old = '''fun V341PublishScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    publish: PublishUiState,
    groups: List<TargetGroup>,
    onTargetWhatsApp: (String) -> Unit,
    onGroups: () -> Unit,
'''
publish_sig_new = '''fun V341PublishScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    runtime: UnifiedRuntimeSnapshot,
    publish: PublishUiState,
    groups: List<TargetGroup>,
    onTargetWhatsApp: (String) -> Unit,
    onBackendPreference: (RuntimeBackendPreference) -> Unit,
    onGroups: () -> Unit,
'''
s = replace_once(s, publish_sig_old, publish_sig_new, "V341PublishScreen runtime signature")

s = replace_once(
    s,
    '''        item { VHeader("النشر", "إرسال الرسائل إلى القروبات المحددة", engine, Icons.Default.Send) }
        item {
            VCard {''',
    '''        item { VHeader("النشر", "إرسال الرسائل إلى القروبات المحددة", engine, Icons.Default.Send) }
        item { UnifiedRuntimeStatusStrip(runtime) }
        item {
            VCard {''',
    "V341PublishScreen runtime card"
)
write(rel, s)

# ---------------------------------------------------------------------------
# Diagnostics — report the same unified target/backend that the engines use.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt"
s = read(rel)

if "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.engine.RuntimeOperationCoordinator\n",
        "import com.althmany.extractor.engine.RuntimeOperationCoordinator\n"
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n",
        "Diagnostics unified runtime import"
    )

s = replace_once(
    s,
    '''    val profile = ProfileEnvironment.current(context)
    val prefs = app.preferences

    return V341DiagnosticSnapshot(
''',
    '''    val profile = ProfileEnvironment.current(context)
    val prefs = app.preferences
    val unified = UnifiedRuntimeTargetStore.resolve(
        context,
        UnifiedRuntimeTargetStore.selectedPackage(context) ?: prefs.selectedWhatsAppPackage
    )

    return V341DiagnosticSnapshot(
''',
    "Diagnostics unified runtime snapshot"
)

s = replace_once(
    s,
    '''        androidProfile = profile.profileKey,
        selectedWhatsApp = prefs.selectedWhatsAppLabel
            ?: prefs.selectedWhatsAppPackage
            ?: "غير محدد",
        runtimeBackend = prefs.runtimeAutomationBackend.name,
''',
    '''        androidProfile = if (unified.remoteTarget) "${unified.environmentLabel} (user ${unified.targetAndroidUserId})" else unified.profileInfo.profileKey,
        selectedWhatsApp = unified.selectedWhatsAppLabel,
        runtimeBackend = "${unified.preference.name} -> ${unified.effectiveBackend.name}",
''',
    "Diagnostics unified runtime fields"
)

s = s.replace("val side = if (maxWidth >= 600.dp) 28.dp else 14.dp", "val side = if (maxWidth >= 600.dp) 28.dp else 16.dp")
s = s.replace(
    "contentPadding = PaddingValues(horizontal = side, vertical = 10.dp)",
    "contentPadding = PaddingValues(horizontal = side, vertical = 12.dp)"
)
s = s.replace(
    "verticalArrangement = Arrangement.spacedBy(10.dp)",
    "verticalArrangement = Arrangement.spacedBy(12.dp)"
)
write(rel, s)

# ---------------------------------------------------------------------------
# Cleanup legacy advanced-target UI path and sort visible Scan results by
# member count descending, matching the export contract.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt"
s = read(rel)

if "import com.althmany.extractor.export.ScanResultOrganizer" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.export.ExportFormat\n",
        "import com.althmany.extractor.export.ExportFormat\n"
        "import com.althmany.extractor.export.ScanResultOrganizer\n",
        "Professional screens organizer import"
    )

s = regex_once(
    s,
    r"@Composable\nprivate fun PTargetSelector\(.*?\n\}\n\n(?=@Composable\nprivate fun PCompactLinkEditor)",
    "",
    "remove unused legacy PTargetSelector"
)

s = replace_once(
    s,
    "                        scanItems.take(20).forEach { record ->\n",
    "                        ScanResultOrganizer.sorted(scanItems).take(20).forEach { record ->\n",
    "sort visible scan results"
)
write(rel, s)

rel = "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt"
s = read(rel)
s = s.replace("import com.althmany.groupmanager.ui.MainActivity as SenderMainActivity\n", "")
s = regex_once(
    s,
    r"    /\*\*\n     \* Advanced Work/Secure/Dual targeting.*?\n    fun openAdvancedTargetManager\(\) \{.*?\n    \}\n\n",
    "",
    "remove legacy Sender target manager method"
)
write(rel, s)

# The feature branch now needs one canonical source contract.
print(f"Patch installed. Backup: {backup}")

# ---------------------------------------------------------------------------
# Remote Shizuku environments (Dual Messenger / Work / Secure Folder) become
# first-class targets in the new workspace instead of opening legacy Sender UI.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt"
s = read(rel)

if "import com.althmany.extractor.profile.UnifiedRemoteTarget" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n",
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRemoteTarget\n",
        "AppViewModel remote target import"
    )
if "import com.althmany.groupmanager.model.AutomationBackend" not in s:
    s = replace_once(
        s,
        "import com.althmany.groupmanager.model.PreferredTarget\n",
        "import com.althmany.groupmanager.model.PreferredTarget\n"
        "import com.althmany.groupmanager.model.AutomationBackend\n",
        "AppViewModel automation backend import"
    )

runtime_state_anchor = '''    val runtimeTarget: StateFlow<UnifiedRuntimeSnapshot> = _runtimeTarget.asStateFlow()
'''
runtime_state_new = '''    val runtimeTarget: StateFlow<UnifiedRuntimeSnapshot> = _runtimeTarget.asStateFlow()

    private val _remoteRuntimeTargets = MutableStateFlow<List<UnifiedRemoteTarget>>(emptyList())
    val remoteRuntimeTargets: StateFlow<List<UnifiedRemoteTarget>> = _remoteRuntimeTargets.asStateFlow()
'''
s = replace_once(s, runtime_state_anchor, runtime_state_new, "AppViewModel remote target state")

s = s.replace(
    "UnifiedRuntimeTargetStore.setSelectedPackage(getApplication<Application>(), packageName)",
    "UnifiedRuntimeTargetStore.setLocalTarget(getApplication<Application>(), packageName)"
)

backend_method_anchor = '''    fun setRuntimeBackendPreference(value: RuntimeBackendPreference) {
'''
remote_methods = '''    fun discoverRemoteRuntimeTargets() {
        if (ExtractionController.isBusy() || ScanController.isRunning() || PublishController.isRunning()) {
            _message.value = "أوقف العملية الحالية قبل اكتشاف بيئات Android الأخرى"
            return
        }
        viewModelScope.launch {
            _message.value = "جارٍ اكتشاف Dual Messenger / Work Profile / Secure Folder عبر Shizuku…"
            val result = runCatching {
                UnifiedRuntimeTargetStore.discoverRemoteTargets(getApplication<Application>())
            }
            val targets = result.getOrElse {
                _message.value = "فشل اكتشاف البيئات: ${it.message.orEmpty()}"
                emptyList()
            }
            _remoteRuntimeTargets.value = targets
            _message.value = if (targets.isEmpty()) {
                "لم يجد Shizuku بيئة واتساب أخرى قابلة للتحقق"
            } else {
                "تم اكتشاف ${targets.size} هدف واتساب في بيئات Android أخرى"
            }
        }
    }

    fun setRemoteRuntimeTarget(target: UnifiedRemoteTarget) {
        if (ExtractionController.isBusy() || ScanController.isRunning() || PublishController.isRunning()) {
            _message.value = "أوقف العملية الحالية قبل تغيير بيئة التشغيل"
            return
        }
        val senderAppBeforeSwitch = getApplication<Application>() as? GroupManagerApp
        if (senderAppBeforeSwitch?.preferences?.accessibilityBatchRunning == true) {
            _message.value = "أوقف الانضمام الحالي قبل تغيير بيئة التشغيل"
            return
        }
        UnifiedRuntimeTargetStore.setRemoteTarget(getApplication<Application>(), target)
        ExtractionController.refreshRuntimeEnvironment()

        val senderApp = getApplication<Application>() as? GroupManagerApp
        if (senderApp != null) {
            senderApp.preferences.setRemoteSecureTarget(
                target.androidUserId,
                target.packageName,
                target.environmentLabel
            )
            senderApp.preferences.automationBackend = AutomationBackend.SHIZUKU
            senderApp.preferences.runtimeAutomationBackend = AutomationBackend.SHIZUKU
            senderApp.preferences.selectedWhatsAppPackage = target.packageName
            senderApp.preferences.selectedWhatsAppLabel = target.whatsappLabel
            senderApp.preferences.preferredTarget = PreferredTarget.AUTO
        }

        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(getApplication<Application>())
        _message.value = "تم اختيار ${target.environmentLabel} • ${target.whatsappLabel} عبر Shizuku"
    }

'''
s = replace_once(
    s,
    backend_method_anchor,
    remote_methods + backend_method_anchor,
    "AppViewModel remote target methods"
)
write(rel, s)

rel = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = read(rel)

s = replace_once(
    s,
    "    val runtimeTarget by viewModel.runtimeTarget.collectAsState()\n",
    "    val runtimeTarget by viewModel.runtimeTarget.collectAsState()\n"
    "    val remoteRuntimeTargets by viewModel.remoteRuntimeTargets.collectAsState()\n",
    "MainActivity remote targets collect"
)

s = replace_once(
    s,
    '''                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onBackendPreference = viewModel::setRuntimeBackendPreference,
                    onStart = viewModel::startExtractionSmart,
''',
    '''                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onBackendPreference = viewModel::setRuntimeBackendPreference,
                    remoteTargets = remoteRuntimeTargets,
                    onDiscoverRemoteTargets = viewModel::discoverRemoteRuntimeTargets,
                    onRemoteTarget = viewModel::setRemoteRuntimeTarget,
                    onStart = viewModel::startExtractionSmart,
''',
    "MainActivity Home remote target callbacks"
)
write(rel, s)

rel = "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"
s = read(rel)

if "import com.althmany.extractor.profile.UnifiedRemoteTarget" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n",
        "import com.althmany.extractor.profile.RuntimeBackendPreference\n"
        "import com.althmany.extractor.profile.UnifiedRemoteTarget\n",
        "Workspace remote target import"
    )

home_remote_sig_anchor = '''    onTargetWhatsApp: (String) -> Unit,
    onBackendPreference: (RuntimeBackendPreference) -> Unit,
    onStart: () -> Unit,
'''
home_remote_sig_new = '''    onTargetWhatsApp: (String) -> Unit,
    onBackendPreference: (RuntimeBackendPreference) -> Unit,
    remoteTargets: List<UnifiedRemoteTarget>,
    onDiscoverRemoteTargets: () -> Unit,
    onRemoteTarget: (UnifiedRemoteTarget) -> Unit,
    onStart: () -> Unit,
'''
s = replace_once(
    s,
    home_remote_sig_anchor,
    home_remote_sig_new,
    "V341HomeScreen remote target signature"
)

s = replace_once(
    s,
    '''                onTargetWhatsApp = onTargetWhatsApp,
                onBackendPreference = onBackendPreference
            )
''',
    '''                onTargetWhatsApp = onTargetWhatsApp,
                onBackendPreference = onBackendPreference,
                remoteTargets = remoteTargets,
                onDiscoverRemoteTargets = onDiscoverRemoteTargets,
                onRemoteTarget = onRemoteTarget
            )
''',
    "V341HomeScreen remote target card"
)
write(rel, s)

# ---------------------------------------------------------------------------
# Shizuku remote-user launch support. This is the replacement for the old
# legacy Dual/Secure manager: the new workspace stores an Android user id and
# every Shizuku-capable feature launches the same target user/package.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/shizuku/ShizukuBridge.kt"
s = read(rel)

old_launch = '''    suspend fun launchPackage(context:Context,targetPackage:String):Boolean{if(!Regex("[A-Za-z0-9_.]+").matches(targetPackage))return false;val cmd="monkey -p '$targetPackage' -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1";return execute(context,cmd,4000).success}
'''
new_launch = '''    suspend fun launchPackage(
        context: Context,
        targetPackage: String,
        androidUserId: Int? = null
    ): Boolean {
        if (!Regex("[A-Za-z0-9_.]+").matches(targetPackage)) return false
        val userId = androidUserId?.takeIf { it >= 0 }
        if (userId == null) {
            val cmd = "monkey -p '$targetPackage' -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1"
            return execute(context, cmd, 4_000).success
        }

        val resolved = execute(
            context,
            "cmd package resolve-activity --brief --user $userId -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p '$targetPackage' 2>/dev/null | tail -n 1",
            3_000
        )
        val component = resolved.output.lineSequence()
            .map(String::trim)
            .lastOrNull { it.contains('/') && it.startsWith(targetPackage) }

        if (!component.isNullOrBlank()) {
            val started = execute(
                context,
                "am start --user $userId -n '$component' >/dev/null 2>&1",
                4_000
            )
            if (started.success) return true
        }

        return execute(
            context,
            "am start --user $userId -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p '$targetPackage' >/dev/null 2>&1",
            4_000
        ).success
    }

    suspend fun launchUrl(
        context: Context,
        targetPackage: String,
        url: String,
        androidUserId: Int? = null
    ): Boolean {
        if (!Regex("[A-Za-z0-9_.]+").matches(targetPackage)) return false
        if (!url.startsWith("https://chat.whatsapp.com/")) return false
        val safeUrl = url.replace("'", "%27")
        val userId = androidUserId?.takeIf { it >= 0 }
        val user = if (userId == null) "" else "--user $userId "
        return execute(
            context,
            "am start ${user}-a android.intent.action.VIEW -d '$safeUrl' -p '$targetPackage' >/dev/null 2>&1",
            5_000
        ).success
    }
'''
s = replace_once(s, old_launch, new_launch, "ShizukuBridge remote launch support")
write(rel, s)

# ---------------------------------------------------------------------------
# ExtractionController remote target awareness.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt"
s = read(rel)

if "import com.althmany.extractor.profile.WhatsAppInstance\n" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.profile.WhatsAppInstanceRegistry\n",
        "import com.althmany.extractor.profile.WhatsAppInstanceRegistry\n"
        "import com.althmany.extractor.profile.WhatsAppInstance\n"
        "import com.althmany.extractor.profile.WhatsAppInstanceKind\n",
        "ExtractionController WhatsApp instance imports"
    )

old_refresh_target = '''        val profile = RuntimeProfileDetector.detect(appContext)
        val available = WhatsAppInstanceRegistry.launchable(appContext, forceRefresh = true)
        val saved = settingsStore.get().targetWhatsAppPackage
        val selected = ProfileLaunchPolicy.resolveSelected(saved, available.map { it.packageName })
        if (selected != null && selected != saved) settingsStore.setTargetWhatsAppPackage(selected)
        if (selected != null) UnifiedRuntimeTargetStore.setSelectedPackage(appContext, selected)
'''
new_refresh_target = '''        val profile = RuntimeProfileDetector.detect(appContext)
        val localAvailable = WhatsAppInstanceRegistry.launchable(appContext, forceRefresh = true)
        val remote = UnifiedRuntimeTargetStore.isRemoteTarget(appContext)
        val remotePackage = UnifiedRuntimeTargetStore.selectedPackage(appContext)
        val remoteUserId = UnifiedRuntimeTargetStore.selectedAndroidUserId(appContext)
        val runtimeSnapshot = UnifiedRuntimeTargetStore.resolve(appContext)

        val available = if (remote && !remotePackage.isNullOrBlank()) {
            (
                localAvailable + WhatsAppInstance(
                    packageName = remotePackage,
                    labelAr = runtimeSnapshot.selectedWhatsAppLabel,
                    installed = true,
                    launchable = true,
                    kind = WhatsAppInstanceKind.DISCOVERED,
                    official = remotePackage in setOf(
                        WhatsAppInstanceRegistry.WHATSAPP,
                        WhatsAppInstanceRegistry.WHATSAPP_BUSINESS
                    ),
                    canHandleInvite = true,
                    profileKey = "REMOTE:$remoteUserId"
                )
            ).distinctBy { "${it.profileKey}:${it.packageName}" }
        } else {
            localAvailable
        }

        val saved = settingsStore.get().targetWhatsAppPackage
        val selected = if (remote) {
            remotePackage
        } else {
            ProfileLaunchPolicy.resolveSelected(saved, available.map { it.packageName })
        }
        if (selected != null && selected != saved) settingsStore.setTargetWhatsAppPackage(selected)
        if (selected != null && !remote) UnifiedRuntimeTargetStore.setLocalTarget(appContext, selected)
'''
s = replace_once(
    s,
    old_refresh_target,
    new_refresh_target,
    "ExtractionController remote-aware refresh"
)

# Local WhatsApp selection explicitly exits any remote-user target.
s = s.replace(
    "UnifiedRuntimeTargetStore.setSelectedPackage(appContext, packageName)",
    "UnifiedRuntimeTargetStore.setLocalTarget(appContext, packageName)"
)

# openWhatsApp must never accidentally open the Owner copy when a remote
# Shizuku target is locked.
s = replace_once(
    s,
    '''    fun openWhatsApp(): Boolean {
        recoverLiveService()
        refreshRuntimeEnvironment()
''',
    '''    fun openWhatsApp(): Boolean {
        recoverLiveService()
        refreshRuntimeEnvironment()
        if (UnifiedRuntimeTargetStore.isRemoteTarget(appContext)) return false
''',
    "ExtractionController prevent local launch for remote target"
)

# The earlier unified sync patch opens WhatsApp before reading the preference.
old_sync_open = '''        if (!openWhatsApp()) throw IllegalStateException("تعذر فتح واتساب المحدد داخل البيئة الحالية")
        val backendPreference = UnifiedRuntimeTargetStore.preference(appContext)
        val syncPackage = requireSelectedPackage()

        if (backendPreference == RuntimeBackendPreference.SHIZUKU) {
'''
new_sync_open = '''        val backendPreference = UnifiedRuntimeTargetStore.preference(appContext)
        val runtimeTarget = UnifiedRuntimeTargetStore.resolve(appContext)
        val syncPackage = requireSelectedPackage()
        val opened = if (runtimeTarget.remoteTarget) {
            if (backendPreference == RuntimeBackendPreference.ACCESSIBILITY) false
            else ShizukuBridge.launchPackage(
                appContext,
                syncPackage,
                runtimeTarget.targetAndroidUserId
            )
        } else {
            openWhatsApp()
        }
        if (!opened) {
            throw IllegalStateException(
                if (runtimeTarget.remoteTarget)
                    "تعذر فتح واتساب في ${runtimeTarget.environmentLabel} عبر Shizuku"
                else
                    "تعذر فتح واتساب المحدد داخل البيئة الحالية"
            )
        }

        if (backendPreference == RuntimeBackendPreference.SHIZUKU) {
'''
s = replace_once(s, old_sync_open, new_sync_open, "ExtractionController remote sync launch")

old_run_open = '''            if (!openWhatsApp()) {
                failRun("لم يتم اختيار/العثور على نسخة واتساب قابلة للتشغيل داخل ${_state.value.profileInfo.labelAr}")
                return
            }
            _state.value = _state.value.copy(status = EngineStatus.OPENING_WHATSAPP, message = "فتح ${WhatsAppInstanceRegistry.labelFor(requireSelectedPackage())} داخل ${_state.value.profileInfo.labelAr}")
            val backendPreference = UnifiedRuntimeTargetStore.preference(appContext)

            if (backendPreference == RuntimeBackendPreference.SHIZUKU) {
'''
new_run_open = '''            val backendPreference = UnifiedRuntimeTargetStore.preference(appContext)
            val runtimeTarget = UnifiedRuntimeTargetStore.resolve(appContext, targetPackage)
            val opened = if (runtimeTarget.remoteTarget) {
                if (backendPreference == RuntimeBackendPreference.ACCESSIBILITY) false
                else ShizukuBridge.launchPackage(
                    appContext,
                    targetPackage,
                    runtimeTarget.targetAndroidUserId
                )
            } else {
                openWhatsApp()
            }
            if (!opened) {
                failRun(
                    if (runtimeTarget.remoteTarget)
                        "تعذر فتح واتساب في ${runtimeTarget.environmentLabel} عبر Shizuku"
                    else
                        "لم يتم اختيار/العثور على نسخة واتساب قابلة للتشغيل داخل ${_state.value.profileInfo.labelAr}"
                )
                return
            }
            _state.value = _state.value.copy(
                status = EngineStatus.OPENING_WHATSAPP,
                message = "فتح ${runtimeTarget.selectedWhatsAppLabel} داخل ${runtimeTarget.environmentLabel}"
            )

            if (backendPreference == RuntimeBackendPreference.SHIZUKU) {
'''
s = replace_once(s, old_run_open, new_run_open, "ExtractionController remote extraction launch")

# All internal Shizuku relaunches use the locked Android user as well.
s = s.replace(
    "ShizukuBridge.launchPackage(appContext, targetPackage)",
    "ShizukuBridge.launchPackage(appContext, targetPackage, UnifiedRuntimeTargetStore.resolve(appContext, targetPackage).targetAndroidUserId)"
)
s = s.replace(
    "ShizukuBridge.launchPackage(appContext, syncPackage)",
    "ShizukuBridge.launchPackage(appContext, syncPackage, UnifiedRuntimeTargetStore.resolve(appContext, syncPackage).targetAndroidUserId)"
)
s = s.replace(
    "ShizukuBridge.launchPackage(appContext, packageName)",
    "ShizukuBridge.launchPackage(appContext, packageName, UnifiedRuntimeTargetStore.resolve(appContext, packageName).targetAndroidUserId)"
)
write(rel, s)

# ---------------------------------------------------------------------------
# ScanController remote-user deep links and relaunches.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/engine/ScanController.kt"
s = read(rel)

s = replace_once(
    s,
    '''        val preference = UnifiedRuntimeTargetStore.preference(appContext)
        val sh = runCatching { ShizukuBridge.status() }.getOrNull()
''',
    '''        val preference = UnifiedRuntimeTargetStore.preference(appContext)
        val runtimeTarget = UnifiedRuntimeTargetStore.resolve(appContext, packageName)
        val sh = runCatching { ShizukuBridge.status() }.getOrNull()
''',
    "ScanController runtime target snapshot"
)

s = s.replace(
    "ShizukuBridge.launchPackage(appContext, packageName)",
    "ShizukuBridge.launchPackage(appContext, packageName, runtimeTarget.targetAndroidUserId)"
)

old_open_invite = '''    private fun openInvite(url: String, packageName: String): Boolean = runCatching {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            setPackage(packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        appContext.startActivity(intent)
        true
    }.getOrDefault(false)
'''
new_open_invite = '''    private suspend fun openInvite(url: String, packageName: String): Boolean {
        val runtimeTarget = UnifiedRuntimeTargetStore.resolve(appContext, packageName)
        if (runtimeTarget.remoteTarget) {
            if (runtimeTarget.effectiveBackend != com.althmany.extractor.profile.RuntimeBackendKind.SHIZUKU) {
                return false
            }
            return ShizukuBridge.launchUrl(
                appContext,
                packageName,
                url,
                runtimeTarget.targetAndroidUserId
            )
        }

        return runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage(packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            }
            appContext.startActivity(intent)
            true
        }.getOrDefault(false)
    }
'''
s = replace_once(s, old_open_invite, new_open_invite, "ScanController remote invite launch")

# The safe-return helper is outside ensureRuntimeReady and therefore needs its
# own runtime snapshot for a possible Shizuku relaunch.
s = replace_once(
    s,
    '''    private suspend fun safelyReturnFromInvite(speed: ScanSpeedProfile) {
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage ?: return
        if (shizukuMode) {
''',
    '''    private suspend fun safelyReturnFromInvite(speed: ScanSpeedProfile) {
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage ?: return
        val runtimeTarget = UnifiedRuntimeTargetStore.resolve(appContext, packageName)
        if (shizukuMode) {
''',
    "ScanController safe return runtime target"
)
write(rel, s)

# ---------------------------------------------------------------------------
# PublishController remote-user launch.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/engine/PublishController.kt"
s = read(rel)

s = replace_once(
    s,
    '''        val preference = UnifiedRuntimeTargetStore.preference(appContext)
        val sh = runCatching { ShizukuBridge.status() }.getOrNull()
''',
    '''        val preference = UnifiedRuntimeTargetStore.preference(appContext)
        val runtimeTarget = UnifiedRuntimeTargetStore.resolve(appContext, packageName)
        val sh = runCatching { ShizukuBridge.status() }.getOrNull()
''',
    "PublishController runtime target snapshot"
)
s = s.replace(
    "ShizukuBridge.launchPackage(appContext, packageName)",
    "ShizukuBridge.launchPackage(appContext, packageName, runtimeTarget.targetAndroidUserId)"
)
write(rel, s)


# Install the approved design and implementation plan into the repository.
for rel in [
    "docs/superpowers/specs/2026-09-16-unified-runtime-scan-export-redesign.md",
    "docs/superpowers/plans/2026-09-16-unified-runtime-scan-export-implementation.md",
]:
    src = BUNDLE / rel
    if not src.exists():
        fail(f"bundle documentation missing: {rel}")
    write(rel, src.read_text(encoding="utf-8"))

print("Unified runtime redesign documentation installed.")

# Reinforce the same post-action hold in the main Accessibility scan loop.
rel = "app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt"
s = read(rel)
handle_action_anchor = '''            RuntimeDirective.HANDLE_ACTION -> {
                val action = screen.action ?: return
                val actionNode = screen.actionNode ?: return
                resetOutcomeEvidence()
'''
handle_action_new = '''            RuntimeDirective.HANDLE_ACTION -> {
                val action = screen.action ?: return
                val actionNode = screen.actionNode ?: return
                val pendingAction = readPendingAction(current)
                if (pendingAction != null &&
                    screen.evidenceConflict == ScreenEvidenceConflict.MULTIPLE_POSITIVE_ACTIONS
                ) {
                    app.preferences.transitionAutomation(
                        AutomationStage.VERIFYING_RESULT,
                        "Post-action conflict is stable; suppressing duplicate membership click and verifying result",
                        resetRetries = false
                    )
                    runtimeDiagnostic(
                        current,
                        "POST_ACTION_DUPLICATE_SUPPRESSED",
                        "pending=${pendingAction.name}; visible=${action.name}; conflict=${screen.evidenceConflict.name}"
                    )
                    return
                }
                resetOutcomeEvidence()
'''
s = replace_once(
    s,
    handle_action_anchor,
    handle_action_new,
    "QuickJoin suppress duplicate action during post-action conflict"
)
write(rel, s)

# ---------------------------------------------------------------------------
# Physical SQLite isolation per Android environment.
# Local execution preserves the historic DB name; verified remote Android
# users receive their own DB file so groups/results cannot leak between users.
# ---------------------------------------------------------------------------
rel = "app/src/main/java/com/althmany/extractor/data/ExtractorDatabase.kt"
s = read(rel)
s = replace_once(
    s,
    "class ExtractorDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {",
    "class ExtractorDatabase(context: Context, databaseName: String = DB_NAME) : SQLiteOpenHelper(context, databaseName, null, DB_VERSION) {",
    "ExtractorDatabase configurable database name"
)
write(rel, s)

rel = "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt"
s = read(rel)

s = replace_once(
    s,
    "    private val repo = ExtractorFeatureRuntime.repository\n",
    "    private val repo get() = ExtractorFeatureRuntime.repository\n",
    "AppViewModel dynamic repository binding"
)

# Switching the local package may also mean returning from a remote-user
# database to this profile's historic local database.
local_runtime_anchor = '''        UnifiedRuntimeTargetStore.setLocalTarget(getApplication<Application>(), packageName)
        val senderApp = getApplication<Application>() as? GroupManagerApp
'''
local_runtime_repl = '''        UnifiedRuntimeTargetStore.setLocalTarget(getApplication<Application>(), packageName)
        if (!ExtractorFeatureRuntime.switchRuntimeEnvironment(getApplication<Application>())) {
            _message.value = "تعذر تبديل بيئة البيانات أثناء وجود عملية نشطة"
            return
        }
        val senderApp = getApplication<Application>() as? GroupManagerApp
'''
s = replace_once(
    s,
    local_runtime_anchor,
    local_runtime_repl,
    "AppViewModel local environment database switch"
)

remote_runtime_anchor = '''        UnifiedRuntimeTargetStore.setRemoteTarget(getApplication<Application>(), target)
        ExtractionController.refreshRuntimeEnvironment()

        val senderApp = getApplication<Application>() as? GroupManagerApp
'''
remote_runtime_repl = '''        UnifiedRuntimeTargetStore.setRemoteTarget(getApplication<Application>(), target)
        if (!ExtractorFeatureRuntime.switchRuntimeEnvironment(getApplication<Application>())) {
            _message.value = "تعذر تبديل بيئة البيانات أثناء وجود عملية نشطة"
            return
        }
        ExtractionController.refreshRuntimeEnvironment()

        val senderApp = getApplication<Application>() as? GroupManagerApp
'''
s = replace_once(
    s,
    remote_runtime_anchor,
    remote_runtime_repl,
    "AppViewModel remote environment database switch"
)

# Refresh UI lists from the newly selected physical DB.
remote_message_anchor = '''        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(getApplication<Application>())
        _message.value = "تم اختيار ${target.environmentLabel} • ${target.whatsappLabel} عبر Shizuku"
    }
'''
remote_message_repl = '''        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(getApplication<Application>())
        refresh()
        _message.value = "تم اختيار ${target.environmentLabel} • ${target.whatsappLabel} عبر Shizuku"
    }
'''
s = replace_once(
    s,
    remote_message_anchor,
    remote_message_repl,
    "AppViewModel refresh remote database UI"
)

local_message_anchor = '''        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(getApplication<Application>(), packageName)
    }

    fun discoverRemoteRuntimeTargets() {
'''
local_message_repl = '''        _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(getApplication<Application>(), packageName)
        refresh()
    }

    fun discoverRemoteRuntimeTargets() {
'''
s = replace_once(
    s,
    local_message_anchor,
    local_message_repl,
    "AppViewModel refresh local database UI"
)
write(rel, s)
