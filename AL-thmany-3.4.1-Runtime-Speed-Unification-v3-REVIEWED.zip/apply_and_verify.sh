#!/usr/bin/env bash
REPO="${1:-/workspaces/Bb}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO" 2>/dev/null || { echo "STOP: repository path not found"; true; }

echo "=== SAFE PRECHECK + APPLY ==="
echo "Branch: $(git branch --show-current 2>/dev/null)"
if [ "$(git branch --show-current 2>/dev/null)" != "feat/full-features-3.4.1" ]; then
  echo "STOP: expected branch feat/full-features-3.4.1"
  echo "NO FILE WAS MODIFIED"
else
  python3 "$HERE/apply_patch.py" "$REPO"
  PATCH_CODE=$?
  if [ "$PATCH_CODE" -ne 0 ]; then
    echo "STOP: patch precheck failed; repository was not partially modified."
  else
    python3 "$HERE/verify_source.py" "$REPO"
    VERIFY_CODE=$?
    git diff --check
    DIFF_CODE=$?

    python3 scripts/validate_professional_rebuild_3_4_1.py
    PROF_CODE=$?
    python3 scripts/validate_integrated_extractor.py
    INT_CODE=$?

    if [ "$VERIFY_CODE" -ne 0 ] || [ "$DIFF_CODE" -ne 0 ] || [ "$PROF_CODE" -ne 0 ] || [ "$INT_CODE" -ne 0 ]; then
      echo
      echo "VALIDATION_FAIL: restoring exactly the pre-patch files..."
      python3 "$HERE/rollback.py" "$REPO"
      echo "ROLLBACK COMPLETED — your previous files were restored."
    else
      echo
      echo "SOURCE_REVIEW_GATE: PASS"
      echo "No rollback was needed."
    fi
  fi
fi
echo ">>> TERMINAL REMAINS OPEN <<<"
true
