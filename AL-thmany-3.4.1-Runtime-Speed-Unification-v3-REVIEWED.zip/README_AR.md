# AL-thmany 3.4.1 — Reviewed v3

هذه النسخة أُعيدت بعد مراجعة v2 وليست مجرد إعادة تسمية.

## تغييرات المراجعة
- أضيف الاستيراد الناقص `CompositionLocalProvider` الذي كان سيؤدي إلى Compile error.
- لم نعد نعطّل `autoPauseOutsideWhatsApp`; أمان خروج المستخدم محفوظ.
- لم نعد نغيّر الاختيار الصريح Accessibility إلى Shizuku من خلف المستخدم.
- لم نعد نقلل post-action verification بشكل عدواني.
- خفضنا cooldown الخاص بـ `uiautomator exit=137` من 4 ثوانٍ إلى 1 ثانية بدل 550ms لتجنب hammering.
- Accessibility يحتفظ بمحاولتين transport بدل محاولة واحدة هشة.
- Extraction وPublish يحتفظان بسياسة retry الأصلية؛ فقط السرعة تصبح الأعلى.
- Scan وحده single-pass لأن المطلوب ألا يعيد فتح الرابط.
- التطبيق Transactional: يفحص كل anchors قبل كتابة أي ملف.
- إذا فشل أي Validator بعد التطبيق، تُستعاد الملفات السابقة تلقائيًا.
- لا يوجد `set -e` في سكربتات التشغيل، ويُطبع دائمًا `TERMINAL REMAINS OPEN`.

## الترتيب
الترتيب الأفقي يصبح LTR في الأزرار/Navigation/Runtime choices، بينما النص العربي يبقى مصممًا بالعربية ومحاذاته الأصلية.

## مهم
لا نعتبر النسخة جاهزة للرفع إلى GitHub إلا بعد:
1. SOURCE_REVIEW_GATE: PASS
2. ANDROID_BUILD: PASS
3. ثم CI على GitHub بعد push.
