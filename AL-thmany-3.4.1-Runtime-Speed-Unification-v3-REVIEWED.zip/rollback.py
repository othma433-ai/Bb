#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys

repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
marker = repo / ".althmany_backups" / "last_runtime_speed_v3_backup.txt"
if not marker.exists():
    print("ROLLBACK_SKIP: no v3 backup marker found")
    raise SystemExit(0)

backup = Path(marker.read_text(encoding="utf-8").strip())
manifest_file = backup / "manifest.json"
if not manifest_file.exists():
    print("ROLLBACK_FAIL: manifest missing:", manifest_file)
    raise SystemExit(2)

manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
for rel in manifest.get("files", []):
    src = backup / rel
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
print("ROLLBACK_PASS:", len(manifest.get("files", [])), "files restored")
