# Reviewed Runtime-Speed Design v3

Principles:
1. Speed optimizations must not disable user-exit safety.
2. Semantic correctness after Join/Request is more important than shaving a few hundred ms.
3. The 4s command-dump kill cooldown is the primary proven latency target; reduce to 1s, not to an aggressive sub-second loop.
4. Scan is read-only and one-pass per explicit run.
5. Extraction/Publish keep their engine-owned retry/recovery rules and only use fastest pacing.
6. Target discovery accepts safe dynamically discovered WhatsApp package IDs and remains userId-aware.
7. All patching is transactional and rollback-safe.
8. No push/merge until full Android test/lint/build passes.
