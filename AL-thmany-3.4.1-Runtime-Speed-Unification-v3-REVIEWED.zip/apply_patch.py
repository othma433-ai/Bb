#!/usr/bin/env python3
from pathlib import Path
import json, sys, shutil, datetime, hashlib

repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
here = Path(__file__).resolve().parent
patches = json.loads((here / "patches.json").read_text(encoding="utf-8"))

if not (repo / "app/src/main/java").exists():
    print("PRECHECK_FAIL: repository structure not found:", repo)
    raise SystemExit(2)

# Transactional preflight: build all resulting files in memory first.
working = {}
original = {}
errors = []
status = []

for item in patches:
    rel, old, new, label = item["file"], item["old"], item["new"], item["label"]
    p = repo / rel
    if not p.exists():
        errors.append(f"{label}: missing {rel}")
        continue
    if rel not in working:
        text = p.read_text(encoding="utf-8")
        original[rel] = text
        working[rel] = text
    text = working[rel]
    if new in text:
        status.append(("SKIP", label))
        continue
    count = text.count(old)
    if count != 1:
        errors.append(f"{label}: expected anchor once, found {count} in {rel}")
        continue
    working[rel] = text.replace(old, new, 1)
    status.append(("READY", label))

print("=== TRANSACTIONAL PRECHECK ===")
for state, label in status:
    print(f"{state} | {label}")

if errors:
    print()
    print("PRECHECK_FAIL: NO FILE WAS MODIFIED")
    for e in errors:
        print(" -", e)
    raise SystemExit(3)

changed = [rel for rel in working if working[rel] != original[rel]]
stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
backup = repo / ".althmany_backups" / f"runtime-speed-v3-{stamp}"
backup.mkdir(parents=True, exist_ok=True)

manifest = {"backup": str(backup), "files": [], "original_sha256": {}}
for rel in changed:
    src = repo / rel
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    manifest["files"].append(rel)
    manifest["original_sha256"][rel] = hashlib.sha256(original[rel].encode("utf-8")).hexdigest()

for rel in changed:
    (repo / rel).write_text(working[rel], encoding="utf-8")

(backup / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
(repo / ".althmany_backups" / "last_runtime_speed_v3_backup.txt").write_text(str(backup), encoding="utf-8")

print()
print("PATCH_APPLIED")
print("Backup:", backup)
print("Changed files:", len(changed))
