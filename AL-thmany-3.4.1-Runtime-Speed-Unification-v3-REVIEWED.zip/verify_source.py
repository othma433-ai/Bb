#!/usr/bin/env python3
from pathlib import Path
import sys

repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
checks = [
("Join MAX speed", "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt", "runtimeSpeedMode = RuntimeSpeedMode.MAX"),
("Join user-exit safety preserved", "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt", "autoPauseOutsideWhatsApp = true"),
("Shizuku cooldown 1000ms", "app/src/main/java/com/althmany/groupmanager/shizuku/ShizukuAutomationService.kt", "COMMAND_DUMP_KILL_COOLDOWN_MS = 1_000L"),
("Shizuku bounded dead-tree recovery", "app/src/main/java/com/althmany/groupmanager/shizuku/ShizukuAutomationService.kt", "UI_TREE_FAILURE_MAX = 4"),
("Accessibility bounded click retries", "app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt", "MAX_CLICK_RETRIES = 2"),
("Scan no second attempt", "app/src/main/java/com/althmany/extractor/engine/ScanRetryPolicy.kt", "Boolean = false"),
("Scan HYPER", "app/src/main/java/com/althmany/extractor/engine/ScanController.kt", "setSpeed(ScanSpeedProfile.HYPER)"),
("Scan max attempts one", "app/src/main/java/com/althmany/extractor/engine/ScanController.kt", "setMaxAttempts(1)"),
("Scan resolved backend fast path", "app/src/main/java/com/althmany/extractor/engine/ScanController.kt", "runtimeTarget.effectiveBackend =="),
("Unified performance function", "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt", "applyUnifiedPerformanceProfile"),
("Scan results first four", "app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt", "ordered.take(4)"),
("Diagnostics first four", "app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt", "lines.take(4)"),
("Runtime CompositionLocalProvider imported", "app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt", "import androidx.compose.runtime.CompositionLocalProvider"),
("Runtime choices LTR", "app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt", "LocalLayoutDirection provides LayoutDirection.Ltr"),
("Bottom navigation LTR", "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt", "LocalLayoutDirection provides LayoutDirection.Ltr"),
("Dynamic remote package safety", "app/src/main/java/com/althmany/groupmanager/data/AppPreferences.kt", "Unsafe Android package name."),
]
bad = False
print("AL-thmany 3.4.1 REVIEWED Runtime-Speed Contract")
print("=" * 64)
for name, rel, token in checks:
    p = repo / rel
    ok = p.exists() and token in p.read_text(encoding="utf-8")
    print(("PASS" if ok else "FAIL") + " | " + name)
    bad |= not ok
print("=" * 64)
print("REVIEWED_CONTRACT:", "FAIL" if bad else "PASS")
raise SystemExit(1 if bad else 0)
