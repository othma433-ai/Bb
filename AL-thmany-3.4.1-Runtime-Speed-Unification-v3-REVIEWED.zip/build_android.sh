#!/usr/bin/env bash
REPO="${1:-/workspaces/Bb}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO" 2>/dev/null || { echo "BUILD_STOP: repository path not found"; true; }

JAVA17=""
for CAND in /usr/local/sdkman/candidates/java/17*/bin/java /usr/lib/jvm/java-17*/bin/java /opt/java/17*/bin/java; do
  if [ -x "$CAND" ]; then JAVA17="$CAND"; break; fi
done

GRADLE="/usr/local/sdkman/candidates/gradle/8.13/bin/gradle"

if [ -z "$JAVA17" ]; then
  echo "BUILD_STOP: JDK 17 not found. No source change was made by this build script."
elif [ ! -x "$GRADLE" ]; then
  echo "BUILD_STOP: Gradle 8.13 not found. No source change was made by this build script."
else
  export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$JAVA17")")")"
  export PATH="$JAVA_HOME/bin:$PATH"
  echo "=== ENVIRONMENT ==="
  java -version 2>&1 | head -n 2
  "$GRADLE" --version | grep -E 'Gradle|Launcher JVM|Daemon JVM' | head -n 5

  python3 "$HERE/verify_source.py" "$REPO"
  PRE_CODE=$?

  if [ "$PRE_CODE" -ne 0 ]; then
    echo "BUILD_STOP: source contract is not valid."
  else
    LOG=/tmp/althmany-v3-reviewed-build.log
    rm -f "$LOG"
    "$GRADLE" --no-daemon --no-configuration-cache --console=plain testDebugUnitTest lintDebug assembleDebug 2>&1 | tee "$LOG"
    CODE=${PIPESTATUS[0]}

    if [ "$CODE" -eq 0 ] && [ -s app/build/outputs/apk/debug/app-debug.apk ]; then
      echo
      echo "ANDROID_BUILD: PASS"
      ls -lh app/build/outputs/apk/debug/app-debug.apk
      sha256sum app/build/outputs/apk/debug/app-debug.apk
      echo "APK=app/build/outputs/apk/debug/app-debug.apk"
    else
      echo
      echo "ANDROID_BUILD: FAIL (code=$CODE)"
      echo "No commit/push should be done."
      echo "=== FIRST REAL FAILURE ==="
      awk '/^\* What went wrong:/{p=1} p{print} /^\* Try:/{if(p) q=1} q{exit}' "$LOG" | head -n 80
      grep -n -m 20 -E '(^e: |^error:|Caused by:|Execution failed for task|Could not resolve|Unresolved reference)' "$LOG" || true
      echo "Full log: $LOG"
    fi
  fi
fi
echo ">>> TERMINAL REMAINS OPEN <<<"
true
