# AL-thmany 3.4.1 — Performance / All WhatsApp / Professional RTL

هذه الحزمة مبنية على الفرع المستقر:
`feat/full-features-3.4.1`

والـbase الذي نجح في GitHub Actions:
`dc88f3c893fc253023a1353e0d25f239b311d89b`

## ما الذي تعالجه؟

### الأداء
- توقف `UnifiedRuntimeTarget.resolve()` عن إجبار PackageManager على إعادة الاكتشاف مع كل State update.
- `ExtractionController.refreshRuntimeEnvironment()` أصبح cache-first افتراضيًا.
- SQLite list/stat queries المهمة نُقلت إلى `Dispatchers.IO`.
- Scan/Publish لا يعيدان تحميل الجداول بسبب كل رسالة أو stats update.
- MainActivity لم تعد تجمع groups/links/scanItems/publishItems كلها على مستوى التطبيق.
- تم تقليل polling الخاص بواجهة Join فقط من 350ms إلى 700ms، بدون تغيير توقيت محرك الأتمتة.

### جميع نسخ واتساب
Selector واحد في الصفحة الرئيسية يعرض:
- Personal
- Business
- Dual/Clone
- vendor/discovered WhatsApp
- Work Profile targets المكتشفة
- Secure Folder targets المكتشفة
- Android-user targets التي يثبتها Shizuku

زر **تحديث النسخ** يقوم بتحديث المحلي، ثم Shizuku في الخلفية عندما يكون جاهزًا.

### التصميم
- Typography عربية موحدة عبر Material3.
- لا توجد 9sp/10sp في شاشات 3.4.1 الرئيسية الجديدة.
- العناوين والـbody والlabels لها hierarchy ثابتة.
- Touch targets الرئيسية 48dp أو أكبر.
- Dark navy + cyan/teal مع green/orange/red semantics.

## أمر التشغيل بعد وضع ZIP في المستودع

استخدم الأمر الذي يعطيه ChatGPT بعد رفع الحزمة إلى `main`.

## علامة النجاح النهائية

```text
PERFORMANCE / TARGETS / RTL 3.4.1 CONTRACT: PASS
...
CI_STATE=PASS
ANDROID_BUILD_GATE=PASS
PERFORMANCE_TARGETS_RTL_PUSH_SUCCESS
```

إذا ظهر `CI_STATE=FAIL` لا تعتبر النسخة جاهزة؛ آخر أخطاء GitHub Actions ستُطبع في الطرفية.
