#!/usr/bin/env bash
# AL-thmany 3.4.1 — performance + all WhatsApp targets + professional RTL UI.
# Runs only on feat/full-features-3.4.1. Does not merge to main.

set -u

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_SHA="dc88f3c893fc253023a1353e0d25f239b311d89b"
BRANCH="feat/full-features-3.4.1"

(
  set -e

  ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
  if [ -z "$ROOT" ]; then
    echo "ERROR: شغّل الحزمة من داخل مستودع Bb في Codespaces."
    false
  fi

  cd "$ROOT"

  echo "============================================================"
  echo "AL-thmany 3.4.1 — Performance / All WhatsApp / RTL"
  echo "============================================================"

  echo
  echo "=== 1/8 PREPARE FEATURE BRANCH ==="

  git fetch origin "$BRANCH"

  if [ "$(git branch --show-current)" != "$BRANCH" ]; then
    if [ -n "$(git status --porcelain)" ]; then
      git stash push -u -m "pre-performance-ui-$(date +%Y%m%d-%H%M%S)"
    fi
    git checkout "$BRANCH"
  fi

  git pull --ff-only origin "$BRANCH"

  HEAD_SHA="$(git rev-parse HEAD)"
  echo "Branch: $(git branch --show-current)"
  echo "HEAD: $HEAD_SHA"

  if ! git merge-base --is-ancestor "$BASE_SHA" HEAD; then
    echo "ERROR: الفرع الحالي أقدم/مختلف عن قاعدة الأداء المعتمدة."
    echo "Expected ancestor: $BASE_SHA"
    false
  fi

  if [ -n "$(git status --porcelain)" ]; then
    echo "وجدت تعديلات محلية؛ سيتم حفظها قبل تطبيق الحزمة."
    git stash push -u -m "pre-performance-ui-$(date +%Y%m%d-%H%M%S)"
  fi

  echo
  echo "=== 2/8 RED CONTRACT BEFORE PATCH ==="

  if python3 "$SELF_DIR/overlay/scripts/validate_performance_targets_ui_v341.py" "$ROOT"; then
    echo "PERFORMANCE_CONTRACT_ALREADY_PRESENT"
  else
    echo "RED_CONFIRMED: المشاكل المعمارية المطلوبة موجودة قبل التعديل."
  fi

  echo
  echo "=== 3/8 APPLY PATCH ==="

  python3 "$SELF_DIR/apply_patch.py" "$ROOT"

  echo
  echo "=== 4/8 GREEN CONTRACTS ==="

  python3 scripts/validate_performance_targets_ui_v341.py "$ROOT"

  if [ -f scripts/validate_unified_runtime_v341.py ]; then
    python3 scripts/validate_unified_runtime_v341.py "$ROOT"
  fi

  if [ -f scripts/validate_professional_rebuild_3_4_1.py ]; then
    python3 scripts/validate_professional_rebuild_3_4_1.py "$ROOT"
  fi

  python3 scripts/validate_source.py
  python3 scripts/validate_integrated_extractor.py

  git diff --check

  echo
  echo "=== 5/8 LOCAL BUILD GATE WHEN AVAILABLE ==="

  GRADLE="/usr/local/sdkman/candidates/gradle/8.13/bin/gradle"
  SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
  JAVA_LINE="$(java -version 2>&1 | head -n1 || true)"

  if [ -x "$GRADLE" ] && \
     echo "$JAVA_LINE" | grep -q '"17' && \
     [ -n "$SDK_ROOT" ] && \
     [ -f "$SDK_ROOT/platforms/android-36/android.jar" ]; then

    echo "LOCAL_ANDROID_ENVIRONMENT=READY"

    "$GRADLE" \
      --no-daemon \
      --no-configuration-cache \
      --console=plain \
      testDebugUnitTest \
      lintDebug \
      assembleDebug

    APK="app/build/outputs/apk/debug/app-debug.apk"
    test -s "$APK"

    echo "LOCAL_ANDROID_BUILD=PASS"
    ls -lh "$APK"
    sha256sum "$APK"
  else
    echo "LOCAL_ANDROID_BUILD=DEFERRED_TO_GITHUB_ACTIONS"
  fi

  echo
  echo "=== 6/8 STAGE + COMMIT ==="

  git add \
    app/src/main/java/com/althmany/extractor/profile/UnifiedRuntimeTarget.kt \
    app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt \
    app/src/main/java/com/althmany/extractor/engine/ScanController.kt \
    app/src/main/java/com/althmany/extractor/engine/PublishController.kt \
    app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt \
    app/src/main/java/com/althmany/extractor/MainActivity.kt \
    app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt \
    app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt \
    app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt \
    app/src/main/java/com/althmany/extractor/ui/Theme.kt \
    app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt \
    scripts/validate_performance_targets_ui_v341.py \
    docs/superpowers/specs/2026-09-16-performance-targets-rtl-design.md \
    docs/superpowers/plans/2026-09-16-performance-targets-rtl-ui-implementation.md

  git diff --cached --check

  echo "Staged files:"
  git diff --cached --name-only

  if git diff --cached --quiet; then
    echo "NO_NEW_COMMIT_NEEDED"
  else
    git commit -m "perf: optimize runtime targets and RTL UI"
  fi

  echo
  echo "=== 7/8 PUSH FEATURE BRANCH ==="

  OLD_RUN=""
  if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
    OLD_RUN="$(
      gh run list \
        --workflow android-ci.yml \
        --branch "$BRANCH" \
        --event pull_request \
        --limit 1 \
        --json databaseId \
        --jq '.[0].databaseId' 2>/dev/null || true
    )"
  fi

  git push origin "$BRANCH"

  NEW_SHA="$(git rev-parse HEAD)"
  echo "PUSH_SUCCESS"
  echo "Commit: $NEW_SHA"

  echo
  echo "=== 8/8 GITHUB ACTIONS BUILD GATE ==="

  CI_STATE="PENDING"

  if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
    RUN_ID=""

    for i in $(seq 1 36); do
      CANDIDATE="$(
        gh run list \
          --workflow android-ci.yml \
          --branch "$BRANCH" \
          --event pull_request \
          --limit 4 \
          --json databaseId,headSha \
          --jq ".[] | select(.headSha == \"$NEW_SHA\") | .databaseId" \
          2>/dev/null | head -n1
      )"

      if [ -n "$CANDIDATE" ] && [ "$CANDIDATE" != "$OLD_RUN" ]; then
        RUN_ID="$CANDIDATE"
        break
      fi

      echo "Waiting for CI run... $i/36"
      sleep 5
    done

    if [ -n "$RUN_ID" ]; then
      echo "CI_RUN_ID=$RUN_ID"

      set +e
      gh run watch "$RUN_ID" --exit-status
      CI_CODE=$?
      set -e

      if [ "$CI_CODE" -eq 0 ]; then
        CI_STATE="PASS"

        ART_DIR="$ROOT/artifacts/3.4.1-performance-rtl"
        rm -rf "$ART_DIR"
        mkdir -p "$ART_DIR"

        gh run download \
          "$RUN_ID" \
          -n al-thmany-debug-apk \
          -D "$ART_DIR" || true

        echo "APK_ARTIFACTS:"
        find "$ART_DIR" -maxdepth 3 -type f -print -exec ls -lh {} \; || true
      else
        CI_STATE="FAIL"

        echo
        echo "=== FAILED CI LINES ==="

        gh run view "$RUN_ID" --log-failed 2>/dev/null \
          | grep -E \
          '(^|[[:space:]])e: |error:|FAILURE:|What went wrong|Execution failed|Unresolved reference|Syntax error|Compilation error' \
          | tail -n 140 || true
      fi
    else
      echo "CI_RUN_NOT_VISIBLE_YET"
    fi
  else
    echo "GH_CLI_NOT_AUTHENTICATED"
  fi

  echo
  echo "============================================================"
  echo "PERFORMANCE_TARGETS_RTL_PUSH_SUCCESS"
  echo "Branch: $(git branch --show-current)"
  echo "Commit: $(git rev-parse --short HEAD)"
  echo "CI_STATE=$CI_STATE"

  if [ "$CI_STATE" = "PASS" ]; then
    echo "ANDROID_BUILD_GATE=PASS"
  elif [ "$CI_STATE" = "FAIL" ]; then
    echo "ANDROID_BUILD_GATE=FAIL"
    false
  else
    echo "ANDROID_BUILD_GATE=PENDING"
  fi

  echo "============================================================"
)

CODE=$?

echo
echo "============================================================"
if [ "$CODE" -eq 0 ]; then
  echo ">>> PROCESS FINISHED WITH CODE 0 <<<"
else
  echo ">>> PROCESS STOPPED WITH CODE $CODE <<<"
fi
echo ">>> TERMINAL REMAINS OPEN <<<"
echo "============================================================"
