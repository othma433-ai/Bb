#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import re
import shutil
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
BUNDLE = Path(__file__).resolve().parent
OVERLAY = BUNDLE / "overlay"

def fail(msg: str):
    raise SystemExit(f"PATCH ERROR: {msg}")

def rp(rel: str) -> Path:
    return ROOT / rel

def read(rel: str) -> str:
    p = rp(rel)
    if not p.exists():
        fail(f"missing repository file: {rel}")
    return p.read_text(encoding="utf-8")

def write(rel: str, text: str):
    p = rp(rel)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if old in text:
        return text.replace(old, new, 1)
    if new in text:
        return text
    fail(f"anchor not found: {label}")

required = [
    "app/src/main/java/com/althmany/extractor/profile/UnifiedRuntimeTarget.kt",
    "app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt",
    "app/src/main/java/com/althmany/extractor/engine/ScanController.kt",
    "app/src/main/java/com/althmany/extractor/engine/PublishController.kt",
    "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt",
    "app/src/main/java/com/althmany/extractor/MainActivity.kt",
    "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt",
    "app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt",
    "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt",
    "app/src/main/java/com/althmany/extractor/ui/Theme.kt",
    "app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt",
]

backup = ROOT / ".althmany_backups" / datetime.now().strftime("%Y%m%d-%H%M%S-performance-ui")
for rel in required:
    src = rp(rel)
    if not src.exists():
        fail(f"required file missing: {rel}")
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

# 1) Runtime resolution must be cache-first.
rel = "app/src/main/java/com/althmany/extractor/profile/UnifiedRuntimeTarget.kt"
s = read(rel)
s = replace_once(
    s,
    "val available = WhatsAppInstanceRegistry.available(appContext, forceRefresh = true)",
    "val available = WhatsAppInstanceRegistry.available(appContext, forceRefresh = false)",
    "UnifiedRuntimeTarget cache-first resolve"
)
# Remote discovery: one package-list query per Android user, including vendor clones whose
# package name contains "whatsapp", instead of probing only three hard-coded packages.
s = replace_once(
    s,
    '''        val packages = listOf(
            WhatsAppInstanceRegistry.WHATSAPP,
            WhatsAppInstanceRegistry.WHATSAPP_BUSINESS,
            WhatsAppInstanceRegistry.WHATSAPP_CLONED
        )
''',
    '''        val knownPackages = setOf(
            WhatsAppInstanceRegistry.WHATSAPP,
            WhatsAppInstanceRegistry.WHATSAPP_BUSINESS,
            WhatsAppInstanceRegistry.WHATSAPP_CLONED
        )
''',
    "remote known package set"
)
s = replace_once(
    s,
    '''            for (packageName in packages) {
                val packageResult = ShizukuBridge.execute(
                    appContext,
                    "{ pm list packages --user $userId $packageName 2>/dev/null; " +
                        "cmd package list packages --user $userId $packageName 2>/dev/null; }",
                    2_500
                )
                val exactPresent = packageResult.output.lineSequence()
                    .map(String::trim)
                    .any { it == "package:$packageName" }

                if (exactPresent) {
                    found += UnifiedRemoteTarget(
                        androidUserId = userId,
                        environmentLabel = environment,
                        packageName = packageName,
                        whatsappLabel = WhatsAppInstanceRegistry.labelFor(packageName)
                    )
                }
            }
''',
    '''            val packageListResult = ShizukuBridge.execute(
                appContext,
                "{ pm list packages --user $userId 2>/dev/null; " +
                    "cmd package list packages --user $userId 2>/dev/null; }",
                3_500
            )
            val remotePackages = packageListResult.output.lineSequence()
                .map(String::trim)
                .mapNotNull { line ->
                    line.takeIf { it.startsWith("package:") }
                        ?.removePrefix("package:")
                        ?.substringBefore(' ')
                        ?.trim()
                        ?.takeIf(String::isNotBlank)
                }
                .filter { packageName ->
                    packageName in knownPackages ||
                        packageName.contains("whatsapp", ignoreCase = true)
                }
                .distinct()
                .toList()

            for (packageName in remotePackages) {
                found += UnifiedRemoteTarget(
                    androidUserId = userId,
                    environmentLabel = environment,
                    packageName = packageName,
                    whatsappLabel = WhatsAppInstanceRegistry.labelFor(packageName)
                )
            }
''',
    "remote all WhatsApp package discovery"
)
write(rel, s)

# 2) ExtractionController: explicit heavy discovery only when requested.
rel = "app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt"
s = read(rel)
s = replace_once(
    s,
    "        refreshRuntimeEnvironment()\n        refreshStats()\n",
    "        refreshRuntimeEnvironment(forceDiscovery = true)\n        refreshStats()\n",
    "ExtractionController one-time startup discovery"
)
s = replace_once(
    s,
    "    fun refreshRuntimeEnvironment() {\n",
    "    fun refreshRuntimeEnvironment(forceDiscovery: Boolean = false) {\n",
    "ExtractionController refresh signature"
)
s = replace_once(
    s,
    "val localAvailable = WhatsAppInstanceRegistry.launchable(appContext, forceRefresh = true)",
    "val localAvailable = WhatsAppInstanceRegistry.launchable(appContext, forceRefresh = forceDiscovery)",
    "ExtractionController cached package discovery"
)
write(rel, s)

# SQLite-backed stats must not block the main UI dispatcher.
rel = "app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt"
s = read(rel)
s = replace_once(
    s,
    '''    fun refreshStats() {
        if (!::repository.isInitialized) return
        scope.launch { _state.value = _state.value.copy(stats = repository.stats()) }
    }
''',
    '''    fun refreshStats() {
        if (!::repository.isInitialized) return
        scope.launch {
            val stats = kotlinx.coroutines.withContext(Dispatchers.IO) { repository.stats() }
            _state.value = _state.value.copy(stats = stats)
        }
    }
''',
    "ExtractionController stats IO"
)
write(rel, s)

rel = "app/src/main/java/com/althmany/extractor/engine/ScanController.kt"
s = read(rel)
s = replace_once(
    s,
    '''    fun refreshStats() {
        if (!::repository.isInitialized) return
        scope.launch { _state.value = _state.value.copy(stats = repository.scanStats()) }
    }
''',
    '''    fun refreshStats() {
        if (!::repository.isInitialized) return
        scope.launch {
            val stats = kotlinx.coroutines.withContext(Dispatchers.IO) { repository.scanStats() }
            _state.value = _state.value.copy(stats = stats)
        }
    }
''',
    "ScanController stats IO"
)
write(rel, s)

rel = "app/src/main/java/com/althmany/extractor/engine/PublishController.kt"
s = read(rel)
s = replace_once(
    s,
    '''    fun refreshStats(runId: Long? = _state.value.activeRunId) {
        if (runId == null) return
        scope.launch { _state.value = _state.value.copy(stats = repository.publishStats(runId)) }
    }
''',
    '''    fun refreshStats(runId: Long? = _state.value.activeRunId) {
        if (runId == null) return
        scope.launch {
            val stats = kotlinx.coroutines.withContext(Dispatchers.IO) { repository.publishStats(runId) }
            _state.value = _state.value.copy(stats = stats)
        }
    }
''',
    "PublishController stats IO"
)
write(rel, s)

# 3) AppViewModel.
rel = "app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt"
s = read(rel)

if "import com.althmany.extractor.profile.WhatsAppInstanceRegistry" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n",
        "import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n"
        "import com.althmany.extractor.profile.WhatsAppInstanceRegistry\n",
        "AppViewModel registry import"
    )
if "import kotlinx.coroutines.Dispatchers" not in s:
    s = replace_once(
        s,
        "import kotlinx.coroutines.Job\n",
        "import kotlinx.coroutines.Job\nimport kotlinx.coroutines.Dispatchers\n",
        "AppViewModel Dispatchers import"
    )
if "import kotlinx.coroutines.withContext" not in s:
    s = replace_once(
        s,
        "import kotlinx.coroutines.launch\n",
        "import kotlinx.coroutines.launch\nimport kotlinx.coroutines.withContext\n",
        "AppViewModel withContext import"
    )
if "import kotlinx.coroutines.flow.map" not in s:
    s = replace_once(
        s,
        "import kotlinx.coroutines.flow.asStateFlow\n",
        "import kotlinx.coroutines.flow.asStateFlow\n"
        "import kotlinx.coroutines.flow.map\n"
        "import kotlinx.coroutines.flow.distinctUntilChanged\n",
        "AppViewModel flow map imports"
    )

s = replace_once(
    s,
    "    private var globalJob: Job? = null\n\n    init {\n",
    "    private var globalJob: Job? = null\n"
    "    private var targetDiscoveryJob: Job? = null\n\n"
    "    private suspend fun <T> queryIo(block: () -> T): T =\n"
    "        withContext(Dispatchers.IO) { block() }\n\n"
    "    init {\n",
    "AppViewModel IO helper"
)

old_engine_collector = '''        viewModelScope.launch {
            engineState.collect { state ->
                _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(
                    getApplication<Application>(),
                    state.selectedWhatsAppPackage
                )
            }
        }
'''
new_engine_collector = '''        viewModelScope.launch {
            engineState
                .map { it.selectedWhatsAppPackage }
                .distinctUntilChanged()
                .collect { packageName ->
                    _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(
                        getApplication<Application>(),
                        packageName
                    )
                }
        }
        viewModelScope.launch {
            engineState
                .map { it.shizukuReady }
                .distinctUntilChanged()
                .collect { ready ->
                    if (ready && _remoteRuntimeTargets.value.isEmpty()) {
                        refreshRemoteTargetsInternal(silent = true)
                    }
                }
        }
'''
s = replace_once(s, old_engine_collector, new_engine_collector, "AppViewModel runtime collector")

old_scan_collector = '''        viewModelScope.launch {
            var lastIndex = -1
            var lastStatus = ""
            var lastStatsHash = 0
            ScanController.state.collect { state ->
                val key = state.status.name
                val statsHash = state.stats.hashCode()
                if (state.currentIndex != lastIndex || key != lastStatus || statsHash != lastStatsHash) {
                    lastIndex = state.currentIndex
                    lastStatus = key
                    lastStatsHash = statsHash
                    _scanItems.value = repo.scanItems()
                }
            }
        }
'''
new_scan_collector = '''        viewModelScope.launch {
            var lastIndex = -1
            var lastTerminal = false
            ScanController.state.collect { state ->
                val terminal = state.status.name in setOf("COMPLETED", "ERROR", "STOPPED")
                if (state.currentIndex != lastIndex || terminal != lastTerminal) {
                    lastIndex = state.currentIndex
                    lastTerminal = terminal
                    _scanItems.value = queryIo { repo.scanItems() }
                }
            }
        }
'''
s = replace_once(s, old_scan_collector, new_scan_collector, "AppViewModel scan refresh throttling")

old_publish_collector = '''        viewModelScope.launch {
            var lastIndex = -1
            var lastStatus = ""
            PublishController.state.collect { state ->
                if (state.currentIndex != lastIndex || state.status.name != lastStatus) {
                    lastIndex = state.currentIndex
                    lastStatus = state.status.name
                    val runId = state.activeRunId
                    _publishItems.value = if (runId == null) emptyList() else repo.publishItems(runId)
                }
            }
        }
'''
new_publish_collector = '''        viewModelScope.launch {
            var lastIndex = -1
            var lastRunId: Long? = null
            var lastTerminal = false
            PublishController.state.collect { state ->
                val terminal = state.status.name in setOf("COMPLETED", "ERROR", "STOPPED")
                val runId = state.activeRunId
                if (state.currentIndex != lastIndex || runId != lastRunId || terminal != lastTerminal) {
                    lastIndex = state.currentIndex
                    lastRunId = runId
                    lastTerminal = terminal
                    _publishItems.value = if (runId == null) emptyList()
                    else queryIo { repo.publishItems(runId) }
                }
            }
        }
'''
s = replace_once(s, old_publish_collector, new_publish_collector, "AppViewModel publish refresh throttling")

old_refresh = '''    fun refresh() {
        viewModelScope.launch {
            _groups.value = repo.groups()
            _links.value = repo.links()
            _logs.value = repo.logs()
            _scanItems.value = repo.scanItems()
            val publishRunId = PublishController.state.value.activeRunId
            _publishItems.value = if (publishRunId == null) emptyList() else repo.publishItems(publishRunId)
            ExtractionController.refreshStats()
            ScanController.refreshStats()
            PublishController.refreshStats()
        }
    }
'''
new_refresh = '''    fun refresh() {
        viewModelScope.launch {
            val publishRunId = PublishController.state.value.activeRunId
            val groups = queryIo { repo.groups() }
            val links = queryIo { repo.links() }
            val logs = queryIo { repo.logs() }
            val scanItems = queryIo { repo.scanItems() }
            val publishItems = if (publishRunId == null) emptyList()
            else queryIo { repo.publishItems(publishRunId) }

            _groups.value = groups
            _links.value = links
            _logs.value = logs
            _scanItems.value = scanItems
            _publishItems.value = publishItems

            ExtractionController.refreshStats()
            ScanController.refreshStats()
            PublishController.refreshStats()
        }
    }
'''
s = replace_once(s, old_refresh, new_refresh, "AppViewModel refresh IO")

s = replace_once(
    s,
    '''            if (input.isNotBlank()) {
                val added = repo.addScanLinksFromText(input)
                _message.value = "تمت إضافة $added رابط جديد — بدء الفحص"
            }
            _scanItems.value = repo.scanItems()
''',
    '''            if (input.isNotBlank()) {
                val added = queryIo { repo.addScanLinksFromText(input) }
                _message.value = "تمت إضافة $added رابط جديد — بدء الفحص"
            }
            _scanItems.value = queryIo { repo.scanItems() }
''',
    "AppViewModel start scan IO"
)

s = replace_once(
    s,
    '''            val imported = repo.importInviteLinksFromExtraction()
            _scanItems.value = repo.scanItems()
''',
    '''            val imported = queryIo { repo.importInviteLinksFromExtraction() }
            _scanItems.value = queryIo { repo.scanItems() }
''',
    "AppViewModel pipeline scan import IO"
)

s = replace_once(
    s,
    '''            val discovered = WhatsAppLauncher.discoverWhatsAppApps(senderApp)
                .firstOrNull { it.packageName == packageName }
            senderApp.preferences.clearRemoteSecureTarget()
            senderApp.preferences.selectedWhatsAppPackage = packageName
            senderApp.preferences.selectedWhatsAppLabel = discovered?.label ?: packageName
''',
    '''            val selectedLabel = engineState.value.availableWhatsApp
                .firstOrNull { it.packageName == packageName }
                ?.labelAr
                ?: WhatsAppInstanceRegistry.labelFor(packageName)
            senderApp.preferences.clearRemoteSecureTarget()
            senderApp.preferences.selectedWhatsAppPackage = packageName
            senderApp.preferences.selectedWhatsAppLabel = selectedLabel
''',
    "AppViewModel target tap avoids package rescan"
)

old_discover = '''    fun discoverRemoteRuntimeTargets() {
        if (ExtractionController.isBusy() || ScanController.isRunning() || PublishController.isRunning()) {
            _message.value = "أوقف العملية الحالية قبل اكتشاف بيئات Android الأخرى"
            return
        }
        viewModelScope.launch {
            _message.value = "جارٍ اكتشاف Dual Messenger / Work Profile / Secure Folder عبر Shizuku…"
            val result = runCatching {
                UnifiedRuntimeTargetStore.discoverRemoteTargets(getApplication<Application>())
            }
            val targets = result.getOrElse {
                _message.value = "فشل اكتشاف البيئات: ${it.message.orEmpty()}"
                emptyList()
            }
            _remoteRuntimeTargets.value = targets
            _message.value = if (targets.isEmpty()) {
                "لم يجد Shizuku بيئة واتساب أخرى قابلة للتحقق"
            } else {
                "تم اكتشاف ${targets.size} هدف واتساب في بيئات Android أخرى"
            }
        }
    }
'''
new_discover = '''    private suspend fun refreshRemoteTargetsInternal(silent: Boolean) {
        if (!engineState.value.shizukuReady) {
            if (!silent) _message.value = "Shizuku غير جاهز لاكتشاف Dual / Work / Secure"
            return
        }
        if (!silent) {
            _message.value = "جارٍ اكتشاف جميع بيئات واتساب عبر Shizuku…"
        }
        val result = runCatching {
            withContext(Dispatchers.IO) {
                UnifiedRuntimeTargetStore.discoverRemoteTargets(getApplication<Application>())
            }
        }
        val targets = result.getOrElse {
            if (!silent) _message.value = "فشل اكتشاف البيئات: ${it.message.orEmpty()}"
            emptyList()
        }
        _remoteRuntimeTargets.value = targets
        if (!silent) {
            _message.value = if (targets.isEmpty()) {
                "لم يجد Shizuku نسخة واتساب إضافية قابلة للتحقق"
            } else {
                "تم اكتشاف ${targets.size} نسخة واتساب إضافية"
            }
        }
    }

    fun discoverRemoteRuntimeTargets() {
        if (ExtractionController.isBusy() || ScanController.isRunning() || PublishController.isRunning()) {
            _message.value = "أوقف العملية الحالية قبل تحديث نسخ واتساب"
            return
        }
        if (targetDiscoveryJob?.isActive == true) return
        targetDiscoveryJob = viewModelScope.launch {
            refreshRemoteTargetsInternal(silent = false)
        }
    }

    fun refreshTargetCatalog() {
        if (ExtractionController.isBusy() || ScanController.isRunning() || PublishController.isRunning()) {
            _message.value = "أوقف العملية الحالية قبل تحديث نسخ واتساب"
            return
        }
        if (targetDiscoveryJob?.isActive == true) return
        targetDiscoveryJob = viewModelScope.launch {
            _message.value = "جارٍ تحديث جميع نسخ واتساب…"
            runCatching {
                withContext(Dispatchers.IO) {
                    WhatsAppInstanceRegistry.available(getApplication<Application>(), forceRefresh = true)
                }
            }
            ExtractionController.refreshRuntimeEnvironment()
            _runtimeTarget.value = UnifiedRuntimeTargetStore.resolve(
                getApplication<Application>(),
                engineState.value.selectedWhatsAppPackage
            )
            if (engineState.value.shizukuReady) {
                refreshRemoteTargetsInternal(silent = true)
            }
            _message.value = "اكتمل تحديث نسخ واتساب"
        }
    }
'''
s = replace_once(s, old_discover, new_discover, "AppViewModel background target discovery")

# Common DB mutation/read paths off Main.
replacements = [
    (
        '''            repo.setSelected(id, selected)
            _groups.value = repo.groups()
''',
        '''            queryIo { repo.setSelected(id, selected) }
            _groups.value = queryIo { repo.groups() }
''',
        "setSelected IO"
    ),
    (
        '''            repo.setAllSelected(selected)
            _groups.value = repo.groups()
''',
        '''            queryIo { repo.setAllSelected(selected) }
            _groups.value = queryIo { repo.groups() }
''',
        "setAllSelected IO"
    ),
    (
        '''            repo.setSelectionPreset(preset, engineState.value.selectedWhatsAppPackage)
            _groups.value = repo.groups()
''',
        '''            queryIo { repo.setSelectionPreset(preset, engineState.value.selectedWhatsAppPackage) }
            _groups.value = queryIo { repo.groups() }
''',
        "selection preset IO"
    ),
    (
        '''            val added = repo.addScanLinksFromText(text)
            _scanItems.value = repo.scanItems()
''',
        '''            val added = queryIo { repo.addScanLinksFromText(text) }
            _scanItems.value = queryIo { repo.scanItems() }
''',
        "add scan IO"
    ),
    (
        '''            val added = repo.addScanLinksFromText(links.joinToString("\\n"))
            _scanItems.value = repo.scanItems()
''',
        '''            val added = queryIo { repo.addScanLinksFromText(links.joinToString("\\n")) }
            _scanItems.value = queryIo { repo.scanItems() }
''',
        "scan file import IO"
    ),
    (
        '''            val added = repo.importInviteLinksFromExtraction()
            _scanItems.value = repo.scanItems()
''',
        '''            val added = queryIo { repo.importInviteLinksFromExtraction() }
            _scanItems.value = queryIo { repo.scanItems() }
''',
        "scan extraction import IO"
    ),
    (
        '''            _scanItems.value = repo.scanItems()
            ScanController.refreshStats()
''',
        '''            _scanItems.value = queryIo { repo.scanItems() }
            ScanController.refreshStats()
''',
        "reload scan IO"
    ),
    (
        '''            repo.clearScan()
            _scanItems.value = emptyList()
''',
        '''            queryIo { repo.clearScan() }
            _scanItems.value = emptyList()
''',
        "clear scan IO"
    ),
    (
        '''            val runId = PublishController.state.value.activeRunId
            _publishItems.value = if (runId == null) emptyList() else repo.publishItems(runId)
''',
        '''            val runId = PublishController.state.value.activeRunId
            _publishItems.value = if (runId == null) emptyList() else queryIo { repo.publishItems(runId) }
''',
        "reload publish IO"
    ),
    (
        '''            repo.clearAll()
            refresh()
''',
        '''            queryIo { repo.clearAll() }
            refresh()
''',
        "clear all IO"
    ),
    (
        '''    fun reloadLinks() { viewModelScope.launch { _links.value = repo.links() } }
    fun reloadLogs() { viewModelScope.launch { _logs.value = repo.logs() } }
''',
        '''    fun reloadLinks() { viewModelScope.launch { _links.value = queryIo { repo.links() } } }
    fun reloadLogs() { viewModelScope.launch { _logs.value = queryIo { repo.logs() } } }
''',
        "reload lists IO"
    ),
]
for old, new, label in replacements:
    if old in s:
        s = s.replace(old, new, 1)
    elif new not in s:
        fail(f"anchor not found: {label}")

write(rel, s)

# 4) MainActivity.
rel = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = read(rel)

for line in [
    "    val groups by viewModel.groups.collectAsState()\n",
    "    val links by viewModel.links.collectAsState()\n",
    "    val logs by viewModel.logs.collectAsState()\n",
    "    val scanItems by viewModel.scanItems.collectAsState()\n",
    "    val publishItems by viewModel.publishItems.collectAsState()\n",
]:
    s = s.replace(line, "")

s = replace_once(
    s,
    "ExportManager.export(context.contentResolver, uri, pendingFormat, links)",
    "ExportManager.export(context.contentResolver, uri, pendingFormat, viewModel.links.value)",
    "MainActivity export links snapshot"
)
s = replace_once(
    s,
    "ExportManager.exportScan(context.contentResolver, uri, pendingFormat, scanItems)",
    "ExportManager.exportScan(context.contentResolver, uri, pendingFormat, viewModel.scanItems.value)",
    "MainActivity export scan snapshot"
)
s = replace_once(
    s,
    "ExportManager.exportPublish(context.contentResolver, uri, pendingFormat, publishItems)",
    "ExportManager.exportPublish(context.contentResolver, uri, pendingFormat, viewModel.publishItems.value)",
    "MainActivity export publish snapshot"
)

old_poll = '''    LaunchedEffect(engine.accessibilityEnabledInSettings, engine.serviceConnected) {
        if (engine.accessibilityEnabledInSettings && !engine.serviceConnected) {
            repeat(20) {
                delay(400L)
                viewModel.refreshRuntimeEnvironment()
                if (viewModel.engineState.value.serviceConnected) return@LaunchedEffect
            }
        }
    }
'''
new_poll = '''    LaunchedEffect(engine.accessibilityEnabledInSettings, engine.serviceConnected) {
        if (engine.accessibilityEnabledInSettings && !engine.serviceConnected) {
            repeat(4) {
                delay(1_000L)
                viewModel.refreshRuntimeEnvironment()
                if (viewModel.engineState.value.serviceConnected) return@LaunchedEffect
            }
        }
    }
'''
s = replace_once(s, old_poll, new_poll, "MainActivity bounded accessibility polling")

s = replace_once(
    s,
    '''                    onDiscoverRemoteTargets = viewModel::discoverRemoteRuntimeTargets,
                    onRemoteTarget = viewModel::setRemoteRuntimeTarget,
''',
    '''                    onDiscoverRemoteTargets = viewModel::discoverRemoteRuntimeTargets,
                    onRefreshTargets = viewModel::refreshTargetCatalog,
                    onRemoteTarget = viewModel::setRemoteRuntimeTarget,
''',
    "MainActivity home target refresh"
)

def wrap_branch(text: str, screen: str, next_screen: str, declaration: str) -> str:
    start_marker = f"                AppScreen.{screen} -> "
    next_marker = f"\n\n                AppScreen.{next_screen} -> "
    start = text.find(start_marker)
    if start < 0:
        fail(f"branch start missing: {screen}")
    next_pos = text.find(next_marker, start)
    if next_pos < 0:
        fail(f"next branch missing after: {screen}")
    branch = text[start:next_pos]
    if branch.startswith(start_marker + "{"):
        return text
    expr = branch[len(start_marker):]
    indented = "\n".join("    " + line if line else line for line in expr.splitlines())
    replacement = (
        f"                AppScreen.{screen} -> {{\n"
        f"                    {declaration}\n"
        f"{indented}\n"
        f"                }}"
    )
    return text[:start] + replacement + text[next_pos:]

s = wrap_branch(s, "EXTRACT", "JOIN", "val groups by viewModel.groups.collectAsState()")
s = wrap_branch(s, "SCAN", "PUBLISH", "val scanItems by viewModel.scanItems.collectAsState()")
s = wrap_branch(s, "PUBLISH", "GROUPS", "val groups by viewModel.groups.collectAsState()")
s = wrap_branch(s, "GROUPS", "RESULTS", "val groups by viewModel.groups.collectAsState()")
s = wrap_branch(s, "RESULTS", "LOGS", "val links by viewModel.links.collectAsState()")

write(rel, s)

# 5) Workspace home + typography.
rel = "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"
s = read(rel)
s = replace_once(
    s,
    '''    remoteTargets: List<UnifiedRemoteTarget>,
    onDiscoverRemoteTargets: () -> Unit,
    onRemoteTarget: (UnifiedRemoteTarget) -> Unit,
''',
    '''    remoteTargets: List<UnifiedRemoteTarget>,
    onDiscoverRemoteTargets: () -> Unit,
    onRefreshTargets: () -> Unit,
    onRemoteTarget: (UnifiedRemoteTarget) -> Unit,
''',
    "V341HomeScreen refresh callback signature"
)
s = replace_once(
    s,
    '''                onBackendPreference = onBackendPreference,
                remoteTargets = remoteTargets,
                onDiscoverRemoteTargets = onDiscoverRemoteTargets,
                onRemoteTarget = onRemoteTarget
''',
    '''                onBackendPreference = onBackendPreference,
                onRefresh = onRefreshTargets,
                remoteTargets = remoteTargets,
                onDiscoverRemoteTargets = onDiscoverRemoteTargets,
                onRemoteTarget = onRemoteTarget
''',
    "V341HomeScreen runtime refresh wiring"
)
for old, new in [
    ("fontSize = 9.sp", "fontSize = 12.sp"),
    ("fontSize = 10.sp", "fontSize = 12.sp"),
    ("fontSize = 11.sp", "fontSize = 13.sp"),
    ("fontSize = 15.sp", "fontSize = 18.sp"),
]:
    s = s.replace(old, new)
write(rel, s)

# 6) Join/Scan professional screens typography.
rel = "app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt"
s = read(rel)
for old, new in [
    ("fontSize = 9.sp", "fontSize = 12.sp"),
    ("fontSize = 10.sp", "fontSize = 12.sp"),
    ("fontSize = 11.sp", "fontSize = 13.sp"),
    ("fontSize = 15.sp", "fontSize = 18.sp"),
]:
    s = s.replace(old, new)
write(rel, s)

# 7) Original Join UI bridge update rate only.
rel = "app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt"
s = read(rel)
s = replace_once(
    s,
    "                delay(350L)\n",
    "                delay(700L)\n",
    "OriginalJoinCoordinator UI polling"
)
write(rel, s)

# 8) Overlay approved design-system files and validator/docs.
for rel in [
    "app/src/main/java/com/althmany/extractor/ui/Theme.kt",
    "app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt",
    "scripts/validate_performance_targets_ui_v341.py",
]:
    src = OVERLAY / rel
    if not src.exists():
        fail(f"overlay missing: {rel}")
    write(rel, src.read_text(encoding="utf-8"))

for rel in [
    "docs/superpowers/specs/2026-09-16-performance-targets-rtl-design.md",
    "docs/superpowers/plans/2026-09-16-performance-targets-rtl-ui-implementation.md",
]:
    src = BUNDLE / rel
    if not src.exists():
        fail(f"documentation missing: {rel}")
    write(rel, src.read_text(encoding="utf-8"))

print("PATCH_APPLIED_OK")
print(f"Backup: {backup}")
