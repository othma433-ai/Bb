
from pathlib import Path
import re
import sys

ROOT = Path.cwd()

def read(rel):
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f"MISSING: {rel}")
    return p.read_text(encoding="utf-8")

def write(rel, text):
    (ROOT / rel).write_text(text, encoding="utf-8")

def replace_once(text, old, new, label):
    if new in text:
        return text
    if old not in text:
        raise SystemExit(f"PATCH ERROR [{label}]: expected source block not found")
    return text.replace(old, new, 1)

# Version
p = "app/build.gradle.kts"
s = read(p)
s = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 341', s, count=1)
s = re.sub(r'versionName\s*=\s*"[^"]+"', 'versionName = "3.4.1"', s, count=1)
write(p, s)

# AppScreen.JOIN
p = "app/src/main/java/com/althmany/extractor/ui/Screens.kt"
s = read(p)
old_enum = "enum class AppScreen { HOME, EXTRACT, SCAN, PUBLISH, GROUPS, RESULTS, LOGS, SETTINGS }"
new_enum = "enum class AppScreen { HOME, JOIN, EXTRACT, SCAN, PUBLISH, GROUPS, RESULTS, LOGS, SETTINGS }"
if old_enum in s:
    s = s.replace(old_enum, new_enum, 1)
elif new_enum not in s:
    raise SystemExit("PATCH ERROR [AppScreen enum]")
write(p, s)

# Sender route isolation compile fix
p = "app/src/main/java/com/althmany/extractor/accessibility/WhatsAppAccessibilityService.kt"
s = read(p)
if "RuntimeOperation.SENDER -> Unit" not in s:
    old = '''        when (RuntimeOperationCoordinator.current()) {
            RuntimeOperation.EXTRACTION -> ExtractionController.notifyUiEvent(packageName)
'''
    new = '''        when (RuntimeOperationCoordinator.current()) {
            // Sender owns WhatsApp UI independently; extractor engines must ignore its events.
            RuntimeOperation.SENDER -> Unit
            RuntimeOperation.EXTRACTION -> ExtractionController.notifyUiEvent(packageName)
'''
    s = replace_once(s, old, new, "Sender route isolation")
write(p, s)

# SmartWorkspaceScreens
p = "app/src/main/java/com/althmany/extractor/ui/SmartWorkspaceScreens.kt"
s = read(p)

s = s.replace(
    'Text("AL-thmany", color = WsGreen, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)',
    'Text("Al-othmany Sender 3.4.1", color = WsText, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)'
)

if 'AppScreen.JOIN -> Triple(AppScreen.JOIN, "الانضمام", Icons.Default.Groups)' not in s:
    s = replace_once(
        s,
        '        AppScreen.EXTRACT -> Triple(AppScreen.EXTRACT, "الاستخراج", Icons.Default.Download)\n',
        '        AppScreen.JOIN -> Triple(AppScreen.JOIN, "الانضمام", Icons.Default.Groups)\n'
        '        AppScreen.EXTRACT -> Triple(AppScreen.EXTRACT, "الاستخراج", Icons.Default.Download)\n',
        "JOIN bottom nav"
    )

s = s.replace('selectedIconColor = WsGreen,', 'selectedIconColor = WsCyan,')
s = s.replace('selectedTextColor = WsGreen,', 'selectedTextColor = WsCyan,')
s = s.replace('indicatorColor = WsGreen.copy(alpha = 0.12f),', 'indicatorColor = WsCyan.copy(alpha = 0.14f),')
s = s.replace(
    'ControlButton("إيقاف الكل", Icons.Default.Stop, WsDanger, running || paused, Modifier.weight(1f), onStopAll)',
    'ControlButton("إيقاف نهائي", Icons.Default.Stop, WsDanger, running || paused, Modifier.weight(1f), onStopAll)'
)
s = s.replace(
    'ControlButton("بدء", Icons.Default.PlayArrow, WsGreen, startEnabled && !running, Modifier.weight(1f), onStart)',
    'ControlButton("بدء", Icons.Default.PlayArrow, WsCyan, startEnabled && !running, Modifier.weight(1f), onStart)'
)

old = '''    onSpeed: (SpeedProfile) -> Unit,
    onRounds: (Int) -> Unit,
    onGroups: () -> Unit,
'''
new = '''    onSpeed: (SpeedProfile) -> Unit,
    onRounds: (Int) -> Unit,
    onSync: () -> Unit,
    onSelected: (Long, Boolean) -> Unit,
    onPreset: (GroupSelectionPreset) -> Unit,
    onGroups: () -> Unit,
'''
s = replace_once(s, old, new, "Extraction callbacks")

old = '''    val running = extractionRunning(engine)
    val paused = engine.status == EngineStatus.PAUSED
    LazyColumn('''
new = '''    val running = extractionRunning(engine)
    val paused = engine.status == EngineStatus.PAUSED
    var groupQuery by remember { mutableStateOf("") }
    val visibleGroups = if (groupQuery.isBlank()) groups else groups.filter {
        it.name.contains(groupQuery, ignoreCase = true)
    }
    LazyColumn('''
s = replace_once(s, old, new, "Extraction inline group state")

group_block = r'''
        item {
            WsCard(accent = WsCyan.copy(alpha = 0.62f)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    WsSectionTitle("اختيار القروبات", Icons.Default.Groups, WsCyan)

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Button(
                            onClick = onSync,
                            enabled = !running,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WsBlue.copy(alpha = 0.85f),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.Sync, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("مزامنة القروبات", fontSize = 9.sp)
                        }
                        Button(
                            onClick = onStart,
                            enabled = engine.selectedWhatsAppPackage != null && groups.any { it.selected },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WsCyan,
                                contentColor = Color(0xFF00131A)
                            )
                        ) {
                            Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("بدء الاستخراج", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item { WsChoice("تحديد الكل", false, WsCyan, Modifier.width(112.dp)) { onPreset(GroupSelectionPreset.ALL) } }
                        item { WsChoice("إلغاء التحديد", false, WsDanger, Modifier.width(112.dp)) { onPreset(GroupSelectionPreset.NONE) } }
                        item { WsChoice("غير المقروءة", false, WsPurple, Modifier.width(112.dp)) { onPreset(GroupSelectionPreset.UNREAD) } }
                        item { WsChoice("النشطة", false, WsGreen, Modifier.width(112.dp)) { onPreset(GroupSelectionPreset.ACTIVE) } }
                    }

                    OutlinedTextField(
                        value = groupQuery,
                        onValueChange = { groupQuery = it.take(80) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("البحث في القروبات...", color = WsMuted, fontSize = 10.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = WsCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WsCyan,
                            unfocusedBorderColor = WsLine,
                            focusedTextColor = WsText,
                            unfocusedTextColor = WsText
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )

                    Text(
                        "المحدد ${groups.count { it.selected }} من ${groups.size}",
                        color = WsMuted,
                        fontSize = 9.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End
                    )

                    visibleGroups.take(14).forEach { group ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelected(group.id, !group.selected) },
                            color = if (group.selected) WsCyan.copy(alpha = 0.08f) else Color.Transparent,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                1.dp,
                                if (group.selected) WsCyan.copy(alpha = 0.45f) else WsLine.copy(alpha = 0.65f)
                            )
                        ) {
                            Row(
                                Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = group.selected,
                                    onCheckedChange = { onSelected(group.id, it) }
                                )
                                Spacer(Modifier.width(6.dp))
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                    Text(
                                        group.name,
                                        color = WsText,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val meta = buildList {
                                        if (group.unreadCount > 0) add("${group.unreadCount} غير مقروء")
                                        if (group.active) add("نشط")
                                        if (group.activityText?.isNotBlank() == true) add(group.activityText!!)
                                    }.joinToString(" • ")
                                    if (meta.isNotBlank()) {
                                        Text(
                                            meta,
                                            color = WsMuted,
                                            fontSize = 8.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (visibleGroups.size > 14) {
                        TextButton(onClick = onGroups, modifier = Modifier.fillMaxWidth()) {
                            Text("عرض جميع القروبات (${visibleGroups.size})", color = WsCyan)
                        }
                    }
                }
            }
        }
'''

extract_start = s.find("fun WorkspaceExtractionScreen(")
extract_end = s.find("fun WorkspaceScanScreen(")
extract_slice = s[extract_start:extract_end] if extract_start >= 0 and extract_end >= 0 else ""
marker = '''        item {
            WsSectionTitle("حالة الاستخراج", Icons.Default.BarChart)
'''
if '"تحديد الكل"' not in extract_slice:
    if marker not in s:
        raise SystemExit("PATCH ERROR [Extraction controls marker]")
    s = s.replace(marker, group_block + "\n" + marker, 1)

join_screen = r'''
@Composable
fun WorkspaceJoinScreen(
    padding: PaddingValues,
    engine: ExtractionUiState,
    scan: ScanUiState,
    items: List<ScanRecord>,
    onTargetWhatsApp: (String) -> Unit,
    onAddLinks: (String) -> Unit,
    onAction: (ScanActionMode) -> Unit,
    onRequestToJoin: (Boolean) -> Unit,
    onSpeed: (ScanSpeedProfile) -> Unit,
    onStart: (String) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStopAll: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    val running = scan.running
    val paused = scan.paused
    val failed = scan.stats.invalid + scan.stats.network + scan.stats.other
    val startEnabled = (items.isNotEmpty() || text.isNotBlank()) &&
        engine.selectedWhatsAppPackage != null

    LazyColumn(
        Modifier.fillMaxSize().background(workspaceBrush()).padding(padding),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item { WsHeader("", "الانضمام التلقائي • 3.4.1", engine) }

        item {
            WsCard(accent = WsCyan.copy(alpha = 0.7f)) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = WsCyan.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, WsCyan),
                        modifier = Modifier.size(60.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Groups, null, tint = WsCyan, modifier = Modifier.size(31.dp))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                        Text("الانضمام", color = WsText, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "الانضمام التلقائي إلى القروبات والروابط المحددة",
                            color = WsMuted,
                            fontSize = 10.sp,
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }

        item {
            WsCard {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    WsSectionTitle("تطبيق الهدف", Icons.Default.Chat, WsCyan)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(engine.availableWhatsApp.filter { it.launchable }, key = { it.packageName }) { instance ->
                            WsChoice(
                                "${instance.labelAr}\n${instance.packageName}",
                                engine.selectedWhatsAppPackage == instance.packageName,
                                WsCyan,
                                Modifier.width(150.dp)
                            ) { onTargetWhatsApp(instance.packageName) }
                        }
                    }
                }
            }
        }

        item {
            WsCard(accent = WsCyan.copy(alpha = 0.55f)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    WsSectionTitle("روابط الدعوة", Icons.Default.Link, WsCyan)
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.take(16000) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        placeholder = {
                            Text(
                                "الصق روابط دعوات واتساب هنا...\nرابط واحد في كل سطر",
                                color = WsMuted,
                                fontSize = 10.sp
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WsCyan,
                            unfocusedBorderColor = WsLine,
                            focusedTextColor = WsText,
                            unfocusedTextColor = WsText
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        OutlinedButton(
                            onClick = {
                                if (text.isNotBlank()) {
                                    onAddLinks(text)
                                    text = ""
                                }
                            },
                            enabled = text.isNotBlank(),
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, WsCyan)
                        ) {
                            Icon(Icons.Default.Add, null, tint = WsCyan)
                            Spacer(Modifier.width(4.dp))
                            Text("إضافة الروابط", color = WsText, fontSize = 9.sp)
                        }
                        WsStat("قائمة الانضمام", scan.stats.total.toString(), WsPurple, Modifier.weight(1f))
                    }
                }
            }
        }

        item {
            WsCard {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    WsSectionTitle("وضع الانضمام", Icons.Default.Groups, WsCyan)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        WsChoice(
                            "انضمام مباشر",
                            scan.actionMode == ScanActionMode.JOIN_ONLY && !scan.requestToJoinEnabled,
                            WsCyan,
                            Modifier.weight(1f)
                        ) {
                            onAction(ScanActionMode.JOIN_ONLY)
                            onRequestToJoin(false)
                        }
                        WsChoice(
                            "طلب انضمام",
                            scan.actionMode == ScanActionMode.JOIN_ONLY && scan.requestToJoinEnabled,
                            WsOrange,
                            Modifier.weight(1f)
                        ) {
                            onAction(ScanActionMode.JOIN_ONLY)
                            onRequestToJoin(true)
                        }
                        WsChoice(
                            "ذكي",
                            scan.actionMode == ScanActionMode.SCAN_AND_JOIN,
                            WsPurple,
                            Modifier.weight(1f)
                        ) {
                            onAction(ScanActionMode.SCAN_AND_JOIN)
                            onRequestToJoin(true)
                        }
                    }

                    WsSectionTitle("سرعة التنفيذ", Icons.Default.Speed, WsCyan)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ScanSpeedProfile.entries.forEach { speed ->
                            WsChoice(
                                speed.labelAr,
                                scan.speed == speed,
                                WsCyan,
                                Modifier.weight(1f)
                            ) { onSpeed(speed) }
                        }
                    }
                }
            }
        }

        item {
            WsSectionTitle("ملخص الجلسة", Icons.Default.BarChart, WsCyan)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                WsStat("تم الانضمام", scan.stats.joined.toString(), WsGreen, Modifier.weight(1f))
                WsStat("طلب انضمام", scan.stats.requestPending.toString(), WsOrange, Modifier.weight(1f))
                WsStat("فشل", failed.toString(), WsDanger, Modifier.weight(1f))
                WsStat("متبقي", scan.stats.pending.toString(), WsCyan, Modifier.weight(1f))
            }
        }

        item {
            WsCard {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    WsSectionTitle("آخر الأنشطة", Icons.Default.Timeline, WsCyan)
                    if (items.isEmpty()) {
                        Text(
                            "لا توجد عمليات انضمام بعد",
                            color = WsMuted,
                            fontSize = 9.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.End
                        )
                    } else {
                        items.take(3).forEach { record ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    when (record.status) {
                                        ScanStatus.JOINED -> Icons.Default.CheckCircle
                                        ScanStatus.REQUEST_PENDING -> Icons.Default.Schedule
                                        else -> Icons.Default.Link
                                    },
                                    null,
                                    tint = when (record.status) {
                                        ScanStatus.JOINED -> WsGreen
                                        ScanStatus.REQUEST_PENDING -> WsOrange
                                        ScanStatus.INVALID, ScanStatus.ERROR -> WsDanger
                                        else -> WsCyan
                                    },
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(7.dp))
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                    Text(record.status.labelAr, color = WsText, fontSize = 9.sp)
                                    Text(
                                        record.groupName ?: record.url,
                                        color = WsMuted,
                                        fontSize = 8.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .clickable(enabled = startEnabled && !running) {
                        val pending = text
                        text = ""
                        onStart(pending)
                    },
                shape = RoundedCornerShape(17.dp),
                color = WsCyan.copy(alpha = 0.22f),
                border = BorderStroke(1.dp, WsCyan)
            ) {
                Row(
                    Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.PlayArrow, null, tint = WsCyan)
                    Spacer(Modifier.width(7.dp))
                    Text("بدء الانضمام", color = WsText, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }

        item {
            WsGlobalControls(
                running = running,
                paused = paused,
                startEnabled = startEnabled,
                onStart = {
                    val pending = text
                    text = ""
                    onStart(pending)
                },
                onPause = onPause,
                onResume = onResume,
                onStopAll = onStopAll
            )
        }
    }
}

'''

join_marker = "@Composable\nfun WorkspaceGroupsScreen("
if "fun WorkspaceJoinScreen(" not in s:
    if join_marker not in s:
        raise SystemExit("PATCH ERROR [Join screen marker]")
    s = s.replace(join_marker, join_screen + join_marker, 1)

write(p, s)

# MainActivity wiring
p = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = read(p)

if "import com.althmany.extractor.ui.WorkspaceJoinScreen" not in s:
    s = replace_once(
        s,
        "import com.althmany.extractor.ui.WorkspaceHomeScreen\n",
        "import com.althmany.extractor.ui.WorkspaceHomeScreen\n"
        "import com.althmany.extractor.ui.WorkspaceJoinScreen\n",
        "Join import"
    )

old = '''                    onAutoJoin = {
                        viewModel.setScanActionMode(ScanActionMode.SCAN_AND_JOIN)
                        viewModel.setScanRequestToJoinEnabled(true)
                        viewModel.importScanLinksFromExtraction()
                        screen = AppScreen.SCAN
                    },
'''
new = '''                    onAutoJoin = {
                        viewModel.setScanActionMode(ScanActionMode.SCAN_AND_JOIN)
                        viewModel.setScanRequestToJoinEnabled(true)
                        viewModel.importScanLinksFromExtraction()
                        screen = AppScreen.JOIN
                    },
'''
s = replace_once(s, old, new, "Home join route")

old = '''                    onSpeed = viewModel::setSpeed,
                    onRounds = viewModel::setMaxRounds,
                    onGroups = { screen = AppScreen.GROUPS },
'''
new = '''                    onSpeed = viewModel::setSpeed,
                    onRounds = viewModel::setMaxRounds,
                    onSync = viewModel::syncGroups,
                    onSelected = viewModel::setSelected,
                    onPreset = viewModel::applyGroupSelectionPreset,
                    onGroups = { screen = AppScreen.GROUPS },
'''
s = replace_once(s, old, new, "Extraction wiring")

old = '''                        AppScreen.PUBLISH -> viewModel.reloadPublishItems()
                        AppScreen.SCAN -> viewModel.importScanLinksFromExtraction()
                        AppScreen.LOGS -> viewModel.reloadLogs()
'''
new = '''                        AppScreen.PUBLISH -> viewModel.reloadPublishItems()
                        AppScreen.SCAN -> viewModel.importScanLinksFromExtraction()
                        AppScreen.JOIN -> viewModel.importScanLinksFromExtraction()
                        AppScreen.LOGS -> viewModel.reloadLogs()
'''
s = replace_once(s, old, new, "JOIN bottom action")

s = s.replace(
    'scanState.running || scanState.paused -> "الفحص • ${scanState.message}"',
    'scanState.running || scanState.paused -> if (scanState.actionMode == ScanActionMode.SCAN_ONLY) "الفحص • ${scanState.message}" else "الانضمام • ${scanState.message}"'
)

join_route = r'''
                AppScreen.JOIN -> WorkspaceJoinScreen(
                    padding = zero,
                    engine = engine,
                    scan = scanState,
                    items = scanItems,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onAddLinks = viewModel::addScanLinks,
                    onAction = viewModel::setScanActionMode,
                    onRequestToJoin = viewModel::setScanRequestToJoinEnabled,
                    onSpeed = viewModel::setScanSpeed,
                    onStart = viewModel::startScanWithInput,
                    onPause = viewModel::pauseActiveOperation,
                    onResume = viewModel::resumeActiveOperation,
                    onStopAll = viewModel::stopAllOperations
                )

'''
route_marker = "                AppScreen.SCAN -> WorkspaceScanScreen(\n"
if "AppScreen.JOIN -> WorkspaceJoinScreen(" not in s:
    if route_marker not in s:
        raise SystemExit("PATCH ERROR [Join route marker]")
    s = s.replace(route_marker, join_route + route_marker, 1)

write(p, s)

# UI regression validator
validator = r'''#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def text(rel):
    p = ROOT / rel
    if not p.exists():
        errors.append(f"MISSING: {rel}")
        return ""
    return p.read_text(encoding="utf-8", errors="ignore")

build = text("app/build.gradle.kts")
screens = text("app/src/main/java/com/althmany/extractor/ui/Screens.kt")
smart = text("app/src/main/java/com/althmany/extractor/ui/SmartWorkspaceScreens.kt")
main = text("app/src/main/java/com/althmany/extractor/MainActivity.kt")
service = text("app/src/main/java/com/althmany/extractor/accessibility/WhatsAppAccessibilityService.kt")

checks = {
    "versionName 3.4.1": 'versionName = "3.4.1"' in build,
    "versionCode 341": "versionCode = 341" in build,
    "JOIN AppScreen": "HOME, JOIN, EXTRACT" in screens,
    "dedicated Join screen": "fun WorkspaceJoinScreen(" in smart,
    "MainActivity Join route": "AppScreen.JOIN -> WorkspaceJoinScreen(" in main,
    "approved brand": "Al-othmany Sender 3.4.1" in smart,
    "Select all": '"تحديد الكل"' in smart,
    "Clear selection": '"إلغاء التحديد"' in smart,
    "Unread selection": '"غير المقروءة"' in smart,
    "Active selection": '"النشطة"' in smart,
    "ALL preset": "GroupSelectionPreset.ALL" in smart,
    "NONE preset": "GroupSelectionPreset.NONE" in smart,
    "UNREAD preset": "GroupSelectionPreset.UNREAD" in smart,
    "ACTIVE preset": "GroupSelectionPreset.ACTIVE" in smart,
    "Pause visible": '"إيقاف مؤقت"' in smart,
    "Resume visible": '"استئناف"' in smart,
    "Final stop visible": '"إيقاف نهائي"' in smart,
    "Sender route isolation": "RuntimeOperation.SENDER -> Unit" in service,
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
    if not ok:
        errors.append(label)

if errors:
    print("\nUI 3.4.1 CONTRACT FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("\nAL-thmany Sender 3.4.1 UI CONTRACT: PASS")
'''
vp = ROOT / "scripts/validate_ui_3_4_1.py"
vp.write_text(validator, encoding="utf-8")
vp.chmod(0o755)

print("PATCH_APPLIED_OK")
