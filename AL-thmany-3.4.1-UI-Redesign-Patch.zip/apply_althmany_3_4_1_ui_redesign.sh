#!/usr/bin/env bash
set -Eeuo pipefail

echo "============================================================"
echo " AL-thmany Sender 3.4.1 — UI REDESIGN INSTALLER"
echo "============================================================"

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$ROOT" ]; then
  echo "ERROR: شغّل الأمر داخل Codespace الخاص بمستودع Bb."
  exit 1
fi

cd "$ROOT"

PATCHER="$ROOT/althmany_ui_patch.py"
PLAN_SOURCE="$ROOT/AL-thmany-3.4.1-UI-Redesign-Implementation-Plan.md"
BRANCH="feat/ui-redesign-3.4.1"

test -f "$PATCHER" || {
  echo "ERROR: لم أجد althmany_ui_patch.py في جذر المستودع."
  exit 1
}

if [ -n "$(git status --porcelain --untracked-files=no)" ]; then
  echo "ERROR: توجد تعديلات tracked غير محفوظة. اعمل commit أو reset قبل تشغيل الحزمة."
  git status --short
  exit 1
fi

echo
echo "=== 1) Create isolated branch ==="
git fetch origin main
git checkout -B "$BRANCH" origin/main

echo
echo "=== 2) Save implementation plan ==="
mkdir -p docs/superpowers/plans
if [ -f "$PLAN_SOURCE" ]; then
  cp "$PLAN_SOURCE" docs/superpowers/plans/2026-09-16-ui-redesign-3.4.1.md
fi

echo
echo "=== 3) Apply approved UI patch ==="
python3 "$PATCHER"

echo
echo "=== 4) UI 3.4.1 contract ==="
python3 scripts/validate_ui_3_4_1.py

echo
echo "=== 5) Existing project validators ==="
python3 scripts/validate_source.py
python3 scripts/validate_integrated_extractor.py

echo
echo "=== 6) Android XML parse ==="
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET

files = list(Path("app/src").rglob("*.xml"))
errors = []

for f in files:
    try:
        ET.parse(f)
    except Exception as exc:
        errors.append((f, exc))

if errors:
    print("XML VALIDATION FAILED")
    for f, exc in errors:
        print(f" - {f}: {exc}")
    raise SystemExit(1)

print(f"XML PASS — {len(files)} XML files")
PY

echo
echo "=== 7) Focused pure Kotlin checks (when available) ==="
if command -v kotlinc >/dev/null 2>&1; then
  SKIP_LEGACY=1 bash scripts/run_stability_4_0_checks.sh
else
  echo "kotlinc غير موجود في Codespace؛ GitHub Actions سيجري هذه الفحوصات."
fi

echo
echo "=== 8) Review changed files ==="
git status --short
git diff --stat

echo
echo "=== 9) Commit isolated redesign ==="
git add \
  app/build.gradle.kts \
  app/src/main/java/com/althmany/extractor/MainActivity.kt \
  app/src/main/java/com/althmany/extractor/ui/Screens.kt \
  app/src/main/java/com/althmany/extractor/ui/SmartWorkspaceScreens.kt \
  app/src/main/java/com/althmany/extractor/accessibility/WhatsAppAccessibilityService.kt \
  scripts/validate_ui_3_4_1.py \
  docs/superpowers/plans/2026-09-16-ui-redesign-3.4.1.md

if git diff --cached --quiet; then
  echo "ERROR: لم تنتج الحزمة أي تغييرات قابلة للـcommit."
  exit 1
fi

git commit -m "feat: approved AL-thmany Sender 3.4.1 UI redesign"
git push -u origin "$BRANCH"

HEAD_SHA="$(git rev-parse HEAD)"

echo
echo "============================================================"
echo " PUSHED SAFELY — MAIN WAS NOT MODIFIED"
echo " Branch: $BRANCH"
echo " Commit: $HEAD_SHA"
echo "============================================================"

if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
  echo
  echo "=== 10) Trigger Android CI on the redesign branch ==="

  # workflow_dispatch is intentionally used so CI can run on a feature branch.
  gh workflow run android-ci.yml --ref "$BRANCH" || true

  RUN_ID=""
  for i in $(seq 1 45); do
    RUN_ID="$(
      gh run list \
        --workflow android-ci.yml \
        --branch "$BRANCH" \
        --limit 20 \
        --json databaseId,headSha,headBranch,event \
        --jq ".[] | select(.headSha == \"$HEAD_SHA\" or .headBranch == \"$BRANCH\") | .databaseId" \
        2>/dev/null | head -n1 || true
    )"
    [ -n "$RUN_ID" ] && break
    echo "Waiting for CI... $i/45"
    sleep 4
  done

  if [ -n "$RUN_ID" ]; then
    echo "CI RUN ID: $RUN_ID"
    set +e
    gh run watch "$RUN_ID" --exit-status
    RESULT=$?
    set -e

    if [ "$RESULT" -eq 0 ]; then
      echo
      echo "============================================================"
      echo " FULL CI PASSED"
      echo "============================================================"

      rm -rf AL-thmany-3.4.1-APK
      mkdir -p AL-thmany-3.4.1-APK

      gh run download "$RUN_ID" \
        --name "al-thmany-debug-apk" \
        --dir AL-thmany-3.4.1-APK || true

      find AL-thmany-3.4.1-APK -type f -maxdepth 2 -print -exec ls -lh {} \; || true

      echo
      echo "الفرع نجح. لا تدمجه إلى main قبل مراجعة شكل الواجهات على جهازك."
    else
      echo
      echo "============================================================"
      echo " CI FAILED — REAL ERROR BELOW"
      echo "============================================================"
      gh run view "$RUN_ID" --log-failed || true
      echo
      echo "لا تدمج الفرع. أرسل لي آخر الخطأ الظاهر."
      exit 2
    fi
  else
    echo
    echo "تم رفع الفرع، لكن لم أجد CI Run تلقائياً."
    echo "افتح Actions > AL-thmany Android CI واختر Run workflow على الفرع $BRANCH."
  fi
else
  echo
  echo "GitHub CLI غير متصل."
  echo "تم رفع الفرع فقط؛ شغّل Android CI يدويًا على $BRANCH."
fi

echo
echo "============================================================"
echo " REDESIGN INSTALLER FINISHED"
echo "============================================================"
