# AL-thmany Sender 3.4.1 UI Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use an isolated branch/worktree and execute task-by-task with verification after every change.

**Goal:** Apply the approved dark/cyan RTL design to the app, introduce a dedicated Join screen, expose the required extraction selection presets, and provide Pause / Resume / Final Stop controls in every operational screen while preserving the current automation engines.

**Architecture:** Keep the existing ExtractionController / ScanController / PublishController and repository logic unchanged. Modify only presentation/navigation wiring and reuse AppViewModel callbacks so the redesign does not fork engine state. The Join screen is a dedicated UI over the existing ScanController join modes.

**Tech Stack:** Android, Kotlin, Jetpack Compose Material 3, StateFlow, GitHub Actions.

**Global Constraints**
- Official user-facing version: 3.4.1.
- Preserve existing extraction, scan/join, publish, Shizuku, Accessibility, repository, and export engines.
- Arabic RTL.
- Approved deep navy background + cyan primary accent + green success + amber pending + red failure + purple secondary.
- Extraction must expose: Select All, Clear Selection, Unread, Active.
- Every operational module must expose: Pause, Resume, Final Stop.
- Implement on a separate branch first; do not merge to main until CI passes.

---

### Task 1: Version and navigation contract
- Update `app/build.gradle.kts` to `versionName = "3.4.1"` and `versionCode = 341`.
- Add `JOIN` to `AppScreen`.
- Add a dedicated Join route in `MainActivity`.
- Verify all `when(AppScreen)` expressions remain exhaustive or have an `else`.

### Task 2: Approved visual system
- Update `SmartWorkspaceScreens.kt` header branding to `Al-othmany Sender 3.4.1`.
- Use cyan as the primary interactive accent while retaining green for success.
- Keep the approved dark navy panels, rounded corners, and RTL spacing.
- Rename global destructive control to `إيقاف نهائي`.

### Task 3: Dedicated Join screen
- Add `WorkspaceJoinScreen`.
- Use the existing `ScanController` via `ScanActionMode.JOIN_ONLY` / `SCAN_AND_JOIN`.
- Add target WhatsApp selector, invite link input, join mode selector, speed selector, session summary, and session controls.
- Wire pause/resume/final-stop through `AppViewModel`.

### Task 4: Extraction group controls
- Extend `WorkspaceExtractionScreen` with:
  - `تحديد الكل`
  - `إلغاء التحديد`
  - `غير المقروءة`
  - `النشطة`
- Wire the buttons to the existing `GroupSelectionPreset` values.
- Add inline group search and selection without removing the existing Groups screen.
- Add sync button and preserve extraction modes/speeds.

### Task 5: Scan and Publish controls
- Keep their existing engine wiring.
- Ensure both screens visibly expose Pause / Resume / Final Stop.
- Preserve import/export and attachment workflows.

### Task 6: Regression validation
- Add `scripts/validate_ui_3_4_1.py`.
- Validate version, JOIN route, required group presets, and session-control labels.
- Run:
  - `python3 scripts/validate_source.py`
  - `python3 scripts/validate_integrated_extractor.py`
  - `python3 scripts/validate_ui_3_4_1.py`
  - `SKIP_LEGACY=1 bash scripts/run_stability_4_0_checks.sh` when Kotlin CLI is available.
- Push the isolated branch.
- Trigger `android-ci.yml` using workflow_dispatch on that branch.
- Merge only after CI passes.
