# AL-thmany Sender 3.4.1 — Full Feature Build Patch

This package applies the complete requested primary workspace over the current `Bb` source while preserving the existing automation engines.

## Built scope

- New approved dark/cyan RTL workspace.
- Home dashboard.
- Dedicated Join screen.
- Dedicated Extraction screen.
- Dedicated Scan screen.
- Dedicated Publish screen.
- Extraction selection controls:
  - تحديد الكل
  - إلغاء التحديد
  - غير المقروءة
  - النشطة
- Inline group search and manual selection.
- Pause / Resume / Final Stop in every operational module.
- Join modes: direct, request-to-join, smart scan+join.
- Existing target WhatsApp selection.
- Existing file import/export.
- Existing publish attachments/content modes.
- Existing Accessibility/Shizuku engines.
- Visible version: `3.4.1`.
- Internal Android versionCode: `401` so Android can install it over the prior internal 4.0 test build.

## Apply

Upload the ZIP into `/workspaces/Bb`, then:

```bash
cd /workspaces/Bb
unzip -o AL-thmany-3.4.1-Full-Feature-Build-Patch.zip
bash althmany_3_4_1_full_features/apply_full_features_3_4_1.sh
```

The script creates `feat/full-features-3.4.1`, runs a RED/GREEN feature-contract check, runs the existing validators, pushes the branch, and triggers Android CI when GitHub CLI is authenticated.

Do not merge into `main` until CI is green and the APK has been tested on the device.
