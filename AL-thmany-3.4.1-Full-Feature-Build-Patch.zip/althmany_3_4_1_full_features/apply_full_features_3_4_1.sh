#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$ROOT" ]; then
  echo "ERROR: شغّل هذا الملف داخل Codespace الخاص بمستودع Bb."
  exit 1
fi
cd "$ROOT"

BRANCH="feat/full-features-3.4.1"
PATCH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_FILES="$PATCH_ROOT/patch"

echo "============================================================"
echo " AL-thmany Sender 3.4.1 — FULL FEATURE BUILD"
echo "============================================================"

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: توجد تعديلات غير محفوظة."
  git status --short
  exit 1
fi

git fetch origin main
git checkout -B "$BRANCH" origin/main
mkdir -p app/src/main/java/com/althmany/extractor/ui scripts

cp "$PATCH_FILES/validate_full_features_3_4_1.py" scripts/validate_full_features_3_4_1.py
chmod +x scripts/validate_full_features_3_4_1.py

echo
echo "=== RED: contract before implementation ==="
set +e
python3 scripts/validate_full_features_3_4_1.py
RED=$?
set -e
if [ "$RED" -ne 0 ]; then
  echo "RED confirmed."
else
  echo "Contract already satisfied; patch is idempotent."
fi

cp "$PATCH_FILES/WorkspaceV341Screens.kt" \
  app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt

python3 "$PATCH_FILES/apply_patch.py"

echo
echo "=== GREEN: full feature contract ==="
python3 scripts/validate_full_features_3_4_1.py

echo
echo "=== Existing source validation ==="
python3 scripts/validate_source.py

echo
echo "=== Integrated extractor validation ==="
python3 scripts/validate_integrated_extractor.py

echo
echo "=== XML parse validation ==="
python3 -c 'from pathlib import Path; import xml.etree.ElementTree as ET; fs=list(Path("app/src").rglob("*.xml")); [ET.parse(f) for f in fs]; print("XML PASS:",len(fs))'

echo
echo "=== Git changes ==="
git status --short
git diff --stat

git add -A
git commit -m "feat: complete AL-thmany Sender 3.4.1 feature workspace"
git push -u origin "$BRANCH"

if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
  echo
  echo "=== Triggering Android CI ==="
  gh workflow run android-ci.yml --ref "$BRANCH" || true
  sleep 6

  RUN_ID="$(
    gh run list \
      --workflow android-ci.yml \
      --branch "$BRANCH" \
      --limit 20 \
      --json databaseId,headBranch \
      --jq '.[] | select(.headBranch == "'"$BRANCH"'") | .databaseId' \
      | head -n1
  )"

  if [ -n "$RUN_ID" ]; then
    echo "CI RUN ID: $RUN_ID"
    set +e
    gh run watch "$RUN_ID" --exit-status
    STATUS=$?
    set -e

    if [ "$STATUS" -eq 0 ]; then
      echo "FULL CI PASSED"
      rm -rf AL-thmany-3.4.1-APK
      mkdir -p AL-thmany-3.4.1-APK
      gh run download "$RUN_ID" \
        --name "al-thmany-debug-apk" \
        --dir AL-thmany-3.4.1-APK || true
      find AL-thmany-3.4.1-APK -type f -maxdepth 2 -print -exec ls -lh {} \; || true
    else
      echo "CI FAILED — showing real failure:"
      gh run view "$RUN_ID" --log-failed || true
      exit 2
    fi
  fi
fi

echo
echo "============================================================"
echo " DONE — main was not modified"
echo "============================================================"
echo "Branch: $(git branch --show-current)"
echo "Commit: $(git rev-parse --short HEAD)"
