#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path.cwd()

def rd(path):
    return (ROOT / path).read_text(encoding="utf-8")

def wr(path, text):
    (ROOT / path).write_text(text, encoding="utf-8")

def once(text, old, new, label):
    if new in text:
        return text
    if old not in text:
        raise SystemExit(f"PATCH ERROR [{label}]")
    return text.replace(old, new, 1)

# 1) Adopt visible release 3.4.1 while keeping Android versionCode monotonic.
p = "app/build.gradle.kts"
s = rd(p)
s = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 401', s, count=1)
s = re.sub(r'versionName\s*=\s*"[^"]+"', 'versionName = "3.4.1"', s, count=1)
wr(p, s)

# 2) Keep the project's own source validator aligned with the adopted release.
p = "scripts/validate_source.py"
s = rd(p)
s = s.replace(
    '"versionCode 400": "versionCode = 400" in build,',
    '"versionCode 401": "versionCode = 401" in build,'
)
s = s.replace(
    '"versionName 4.0.0": \'versionName = "4.0.0"\' in build,',
    '"versionName 3.4.1": \'versionName = "3.4.1"\' in build,'
)
wr(p, s)

# 3) Dedicated JOIN navigation target.
p = "app/src/main/java/com/althmany/extractor/ui/Screens.kt"
s = rd(p)
old_enum = "enum class AppScreen { HOME, EXTRACT, SCAN, PUBLISH, GROUPS, RESULTS, LOGS, SETTINGS }"
new_enum = "enum class AppScreen { HOME, JOIN, EXTRACT, SCAN, PUBLISH, GROUPS, RESULTS, LOGS, SETTINGS }"
if old_enum in s:
    s = s.replace(old_enum, new_enum, 1)
elif new_enum not in s:
    raise SystemExit("PATCH ERROR [AppScreen]")
wr(p, s)

# 4) Sender and Extractor must never route the same accessibility event.
p = "app/src/main/java/com/althmany/extractor/accessibility/WhatsAppAccessibilityService.kt"
s = rd(p)
if "RuntimeOperation.SENDER -> Unit" not in s:
    old = """        when (RuntimeOperationCoordinator.current()) {
            RuntimeOperation.EXTRACTION -> ExtractionController.notifyUiEvent(packageName)
"""
    new = """        when (RuntimeOperationCoordinator.current()) {
            RuntimeOperation.SENDER -> Unit
            RuntimeOperation.EXTRACTION -> ExtractionController.notifyUiEvent(packageName)
"""
    s = once(s, old, new, "Sender isolation")
wr(p, s)

# 5) Wire the complete 3.4.1 workspace into MainActivity.
p = "app/src/main/java/com/althmany/extractor/MainActivity.kt"
s = rd(p)

anchor = "import com.althmany.extractor.ui.WorkspaceSettingsScreen\n"
imports = """import com.althmany.extractor.ui.WorkspaceSettingsScreen
import com.althmany.extractor.ui.V341BottomBar
import com.althmany.extractor.ui.V341HomeScreen
import com.althmany.extractor.ui.V341JoinScreen
import com.althmany.extractor.ui.V341ExtractionScreen
import com.althmany.extractor.ui.V341ScanScreen
import com.althmany.extractor.ui.V341PublishScreen
"""
s = once(s, anchor, imports, "V341 imports")

s = s.replace(
    "WorkspaceBottomBar(current = screen) { target ->",
    "V341BottomBar(current = screen) { target ->"
)

s = once(
    s,
    """                        AppScreen.PUBLISH -> viewModel.reloadPublishItems()
                        AppScreen.SCAN -> viewModel.importScanLinksFromExtraction()
                        AppScreen.LOGS -> viewModel.reloadLogs()
""",
    """                        AppScreen.PUBLISH -> viewModel.reloadPublishItems()
                        AppScreen.SCAN -> viewModel.importScanLinksFromExtraction()
                        AppScreen.JOIN -> viewModel.importScanLinksFromExtraction()
                        AppScreen.LOGS -> viewModel.reloadLogs()
""",
    "bottom JOIN action"
)

s = s.replace(
    'scanState.running || scanState.paused -> "الفحص • ${scanState.message}"',
    'scanState.running || scanState.paused -> if (scanState.actionMode == ScanActionMode.SCAN_ONLY) "الفحص • ${scanState.message}" else "الانضمام • ${scanState.message}"'
)

s = s.replace(
    "AppScreen.HOME -> WorkspaceHomeScreen(",
    "AppScreen.HOME -> V341HomeScreen("
)

s = once(
    s,
    """                    onAutoJoin = {
                        viewModel.setScanActionMode(ScanActionMode.SCAN_AND_JOIN)
                        viewModel.setScanRequestToJoinEnabled(true)
                        viewModel.importScanLinksFromExtraction()
                        screen = AppScreen.SCAN
                    },
""",
    """                    onAutoJoin = {
                        viewModel.setScanActionMode(ScanActionMode.SCAN_AND_JOIN)
                        viewModel.setScanRequestToJoinEnabled(true)
                        viewModel.importScanLinksFromExtraction()
                        screen = AppScreen.JOIN
                    },
""",
    "home JOIN route"
)

s = s.replace(
    "AppScreen.EXTRACT -> WorkspaceExtractionScreen(",
    "AppScreen.EXTRACT -> V341ExtractionScreen("
)
s = s.replace(
    "AppScreen.SCAN -> WorkspaceScanScreen(",
    "AppScreen.SCAN -> V341ScanScreen("
)
s = s.replace(
    "AppScreen.PUBLISH -> WorkspacePublishScreen(",
    "AppScreen.PUBLISH -> V341PublishScreen("
)

s = once(
    s,
    """                    onSpeed = viewModel::setSpeed,
                    onRounds = viewModel::setMaxRounds,
                    onGroups = { screen = AppScreen.GROUPS },
""",
    """                    onSpeed = viewModel::setSpeed,
                    onRounds = viewModel::setMaxRounds,
                    onSync = viewModel::syncGroups,
                    onSelected = viewModel::setSelected,
                    onPreset = viewModel::applyGroupSelectionPreset,
                    onGroups = { screen = AppScreen.GROUPS },
""",
    "extraction selection wiring"
)

join_case = """                AppScreen.JOIN -> V341JoinScreen(
                    padding = zero,
                    engine = engine,
                    scan = scanState,
                    items = scanItems,
                    onTargetWhatsApp = viewModel::setTargetWhatsApp,
                    onAddLinks = viewModel::addScanLinks,
                    onImportExtraction = viewModel::importScanLinksFromExtraction,
                    onImportFile = {
                        openScanFile.launch(
                            arrayOf(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel",
                                "text/csv",
                                "text/plain",
                                "application/octet-stream"
                            )
                        )
                    },
                    onAction = viewModel::setScanActionMode,
                    onRequestToJoin = viewModel::setScanRequestToJoinEnabled,
                    onSpeed = viewModel::setScanSpeed,
                    onAttempts = viewModel::setScanMaxAttempts,
                    onStart = viewModel::startScanWithInput,
                    onPause = viewModel::pauseActiveOperation,
                    onResume = viewModel::resumeActiveOperation,
                    onStopAll = viewModel::stopAllOperations,
                    onClear = viewModel::clearScan
                )

"""
marker = "                AppScreen.SCAN -> V341ScanScreen(\n"
if "AppScreen.JOIN -> V341JoinScreen(" not in s:
    if marker not in s:
        raise SystemExit("PATCH ERROR [JOIN case]")
    s = s.replace(marker, join_case + marker, 1)

wr(p, s)
print("Production patch applied.")
